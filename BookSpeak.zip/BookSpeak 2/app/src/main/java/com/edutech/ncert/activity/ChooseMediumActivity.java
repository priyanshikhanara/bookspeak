package com.edutech.ncert.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewpager.widget.ViewPager;
import android.os.Handler;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.adapter.MediumListAdapter;
import com.edutech.ncert.adapter.Sliding_adapter;
import com.edutech.ncert.databinding.ActivityChooseMediumBinding;
import com.edutech.ncert.databinding.ActivityHeaderLayoutBinding;
import com.edutech.ncert.model.MediumModel.Medium;
import com.edutech.ncert.model.MediumModel.MediumParaRes;
import com.edutech.ncert.model.MediumModel.MediumRes;
import com.edutech.ncert.model.MediumModel.Mediumbanner;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChooseMediumActivity extends AppCompatActivity implements View.OnClickListener {
    Context context;
    private ActivityChooseMediumBinding binding;
    private ActivityHeaderLayoutBinding headerBinding;

    String title;
    String class_id;
    LayoutInflater mInflater;
    private PopupWindow mDropdown = null;
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private MySharedPref mySharedPref;
    private String device_id = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChooseMediumBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.progressBar.setVisibility(View.VISIBLE);
        binding.rvMedium.setVisibility(View.VISIBLE);
        headerBinding = binding.bindingHeader;

        init();
        onclicks();
    }




    public void init() {
        context = ChooseMediumActivity.this;
        jsonPlaceHolderApi = ApiUtils.getAPIService();
        mySharedPref = new MySharedPref(context);
        device_id = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);

        new Handler().postDelayed(() -> {
            MobileAds.initialize(context, initializationStatus -> {});
            AdRequest adRequest = new AdRequest.Builder().build();
            binding.adView.loadAd(adRequest);
        }, 100);


        if ("Yes".equalsIgnoreCase(mySharedPref.getSavedBannerAddsStatus())) {
            binding.btnAdsShow.setVisibility(View.VISIBLE);
            binding.adView.setVisibility(View.VISIBLE);
        } else {
            binding.progressBar.setVisibility(View.GONE);      // Stop loading
            binding.rvMedium.setVisibility(View.GONE);         // Hide list
            binding.llNoData.setVisibility(View.VISIBLE);      // Show 'No Data Found' view
        }

        Intent intent = getIntent();
        if (intent != null) {
            title = intent.getStringExtra("title");
            class_id = intent.getStringExtra("class_id");
            Log.d("TAG", title);
        }

        headerBinding.tvTitle.setText(title);
        binding.llNoData.setVisibility(View.GONE);
        binding.rvMedium.setVisibility(View.GONE);

        new Handler().postDelayed(() -> {
            if (Constants.isInternetConnected(context)) {
                GetMediumAPI();
            } else {
                Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            }
        }, 100);

    }

    public void onclicks() {
        headerBinding.llBack.setOnClickListener(this);
        headerBinding.llEdit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llBack:
                onBackPressed();
                break;
            case R.id.llEdit:
                initiatePopupWindow();
                break;
        }
    }

    private PopupWindow initiatePopupWindow() {
        try {
            mInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View layout = mInflater.inflate(R.layout.custom_popup_rate_share, null);

            final TextView menu_share = layout.findViewById(R.id.menu_share);
            final TextView menu_rate = layout.findViewById(R.id.menu_rate);

            menu_share.setOnClickListener(view -> mDropdown.dismiss());
            menu_rate.setOnClickListener(view -> mDropdown.dismiss());

            layout.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            mDropdown = new PopupWindow(layout, FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT, true);
            Drawable background = getResources().getDrawable(android.R.drawable.alert_light_frame);
            mDropdown.setBackgroundDrawable(background);
            mDropdown.showAsDropDown(headerBinding.llEdit, 5, 5);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return mDropdown;
    }

    public void GetMediumAPI() {
        Customprogress.showPopupProgressSpinner(context, false);

        MediumParaRes mediumParaRes = new MediumParaRes();
        mediumParaRes.setClassId(class_id);
        mediumParaRes.setUserId(mySharedPref.getSavedUserid());
        mediumParaRes.setFcmToken(mySharedPref.getFcmToken());
        mediumParaRes.setDeviceId(device_id);

        jsonPlaceHolderApi.GetMediumAPI("application/json", "application/json", mediumParaRes)
                .enqueue(new Callback<MediumRes>() {
                    @Override
                    public void onResponse(Call<MediumRes> call, Response<MediumRes> response) {
                        Customprogress.showPopupProgressSpinner(context, false);

                        if (response.isSuccessful() && response.body().getStatus()) {
                            List<Mediumbanner> banners = response.body().getData().getMediumbanner();

                            if (banners != null && !banners.isEmpty()) {
                                List<String> image = new ArrayList<>();
                                for (Mediumbanner banner : banners) {
                                    image.add(banner.getImage());
                                }
                                binding.layoutBannerContainer.setVisibility(View.VISIBLE);
                                SetSliderData(binding.imgViewPager, image, banners);
                            } else {
                                binding.layoutBannerContainer.setVisibility(View.GONE);
                            }

                            setMediumData(response.body().getData().getMedium());
                        } else {
                            Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<MediumRes> call, Throwable t) {
                        Customprogress.showPopupProgressSpinner(context, false);
                        Log.e("TAG", t.getMessage());
                    }
                });
    }


    private void setMediumData(List<Medium> mediumList) {
        binding.progressBar.setVisibility(View.GONE);  // Always hide loader after response

        if (mediumList != null && !mediumList.isEmpty()) {
            binding.llNoData.setVisibility(View.GONE);
            binding.rvMedium.setVisibility(View.VISIBLE);

            binding.rvMedium.setHasFixedSize(true);
            binding.rvMedium.setLayoutManager(Constants.showInGrid
                    ? new GridLayoutManager(context, 2)
                    : new LinearLayoutManager(context));

            MediumListAdapter adapter = new MediumListAdapter(context, mediumList, (position, type) -> {
                Intent intent = new Intent(context, ChooseSubjectActivity.class);
                intent.putExtra("title", mediumList.get(position).getMedium());
                intent.putExtra("class_id", class_id);
                intent.putExtra("medium_id", mediumList.get(position).getId().toString());
                startActivity(intent);
            });

            binding.rvMedium.setAdapter(adapter);

        } else {
            binding.rvMedium.setVisibility(View.GONE);
            binding.llNoData.setVisibility(View.VISIBLE); // Show message if no data
        }
    }


    public void SetSliderData(ViewPager viewPager, List<String> image, List<Mediumbanner> mediumbanner) {
        try {
            viewPager.setAdapter(new Sliding_adapter(context, viewPager, image, new ItemClick() {
                @Override
                public void onItemClick(int position, String type) {
                    if (mediumbanner.get(position).getUrl() != null && !mediumbanner.get(position).getUrl().trim().isEmpty()) {
                        String url = mediumbanner.get(position).getUrl().startsWith("http") ?
                                mediumbanner.get(position).getUrl() :
                                "https://" + mediumbanner.get(position).getUrl();
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    }
                }
            }));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

package com.edutech.ncert.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.activity.ChooseChapterActivity;
import com.edutech.ncert.adapter.TabLikesListAdapter;
import com.edutech.ncert.databinding.FragmentTabLikesBinding;
import com.edutech.ncert.model.BookModel.BookRes;
import com.edutech.ncert.model.BookModel.Datum;
import com.edutech.ncert.model.BookModel.OtherDetail;
import com.edutech.ncert.model.LikeModel.LikeParaRes;
import com.edutech.ncert.model.LikeModel.LikeRes;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TabLikesFragment extends Fragment {
    Context context;
    private FragmentTabLikesBinding binding;
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private MySharedPref mySharedPref;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentTabLikesBinding.inflate(inflater, container, false);
        init();
        return binding.getRoot();
    }
    public void init() {
        context = binding.getRoot().getContext();

        jsonPlaceHolderApi = ApiUtils.getAPIService();
        mySharedPref = new MySharedPref(context);

        if (Constants.isInternetConnected(context)) {
            GetLikesAPI();
        } else {
            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
        }
    }
    private void setLikesListData(List<Datum> likesList, OtherDetail otherDetail) {
        if (likesList.size() != 0) {
            binding.rvLikes.setVisibility(View.VISIBLE);
            binding.llNoData.setVisibility(View.GONE);
            TabLikesListAdapter adapter = new TabLikesListAdapter(context, likesList, new ItemClick() {
                @Override
                public void onItemClick(int position, String type) {
                    if(type.equals("likeUnlike")){
                        if (Constants.isInternetConnected(context)) {
                            LikeAPI(likesList.get(position).getId().toString());
                        } else {
                            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        startActivity(new Intent(context, ChooseChapterActivity.class)
                                .putExtra("title",likesList.get(position).getName())
                                .putExtra("class_id", likesList.get(position).getClassId())
                                .putExtra("book_id",likesList.get(position).getId().toString())
                                .putExtra("subject_name",otherDetail.getSubjectName())
                                .putExtra("medium",otherDetail.getMediumName())
                                .putExtra("class_name",otherDetail.getClassName())
                        );
                    }
                }
            });
            binding.rvLikes.setHasFixedSize(true);
            binding.rvLikes.setLayoutManager(new LinearLayoutManager(context));
            binding.rvLikes.setAdapter(adapter);
        } else {
            binding.rvLikes.setVisibility(View.GONE);
            binding.llNoData.setVisibility(View.VISIBLE);
        }
    }

    public void GetLikesAPI() {
        Customprogress.showPopupProgressSpinner(context, false);

        jsonPlaceHolderApi.GetLikesAPI("application/json", "application/json","Bearer " + mySharedPref.getSavedAccessToken()).enqueue(new Callback<BookRes>() {
            @Override
            public void onResponse(Call<BookRes> call, Response<BookRes> response) {
                if (response.isSuccessful()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {
                        setLikesListData(response.body().getData(),response.body().getOtherDetail());
                    } else {
                        binding.rvLikes.setVisibility(View.GONE);
                        binding.llNoData.setVisibility(View.VISIBLE);
                    }
                }else{
                    Customprogress.showPopupProgressSpinner(context, false);
                    Toast.makeText(context, "server error", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<BookRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG!!!", t.getMessage());
                //  Toast.makeText(context,t.getMessage().toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void LikeAPI(String bookId) {
        Customprogress.showPopupProgressSpinner(context, false);

        LikeParaRes likeParaRes = new LikeParaRes();
        likeParaRes.setBookId(bookId);

        jsonPlaceHolderApi.LikeAPI(
                "application/json",
                "application/json",
                "Bearer " + mySharedPref.getSavedAccessToken(),
                likeParaRes
        ).enqueue(new Callback<LikeRes>() {
            @Override
            public void onResponse(Call<LikeRes> call, Response<LikeRes> response) {
                Customprogress.showPopupProgressSpinner(context, false);  // ✅ Always hide progress

                if (response.isSuccessful()) {
                    Boolean status = response.body().getStatus();

                    if (status) {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                    if (Constants.isInternetConnected(context)) {
                        GetLikesAPI(); // ✅ refresh regardless of like/unlike
                    } else {
                        Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(context, getResources().getString(R.string.server_error), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LikeRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false); // ✅ hide progress
                Log.e("TAG", t.getMessage());
            }
        });
    }}

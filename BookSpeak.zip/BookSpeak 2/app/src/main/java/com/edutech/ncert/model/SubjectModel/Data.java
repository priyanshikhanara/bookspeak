package com.edutech.ncert.model.SubjectModel;

import java.io.Serializable;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Data implements Serializable {

    @SerializedName("subject")
    @Expose
    private List<Subject> subject;
    @SerializedName("subjectbanner")
    @Expose
    private List<Subjectbanner> subjectbanner;

    public List<Subject> getSubject() {
        return subject;
    }

    public void setSubject(List<Subject> subject) {
        this.subject = subject;
    }

    public List<Subjectbanner> getSubjectbanner() {
        return subjectbanner;
    }

    public void setSubjectbanner(List<Subjectbanner> subjectbanner) {
        this.subjectbanner = subjectbanner;
    }

}


package com.edutech.ncert.model.ClassModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ClassParaRes {



    @SerializedName("fcm_token")
    @Expose
    private String fcmToken;
    @SerializedName("device_id")
    @Expose
    private String deviceId;


    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getFcmToken() {
        return fcmToken;
    }

    public void setFcmToken(String fcmToken) {
        this.fcmToken = fcmToken;
    }

}

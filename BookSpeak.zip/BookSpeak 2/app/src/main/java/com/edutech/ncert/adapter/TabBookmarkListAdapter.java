package com.edutech.ncert.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ListItemChapterBinding;
import com.edutech.ncert.model.ChapterModel.Datum;
import com.edutech.ncert.server.Allurls;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.squareup.picasso.Picasso;

import java.util.List;

public class TabBookmarkListAdapter extends RecyclerView.Adapter<TabBookmarkListAdapter.RecyclerViewHolder> {
    Context context;
    List<Datum> list;
    ItemClick itemClick;
    ImageView ivSave, ivUnsave,ivChapterImage;
    LinearLayout btnCancel, btnRemove, llAudiobook, llEbook, llAudiobookEbook;
    TextView tvChapter, tvSubjectName,bottomtvAudioDuration,bottomtvPdfPages;

    public TabBookmarkListAdapter(Context context, List<Datum> list, ItemClick itemClick) {
        this.context = context;
        this.list = list;
        this.itemClick = itemClick;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item_chapter, parent, false);
        RecyclerViewHolder recyclerViewHolder = new RecyclerViewHolder(view);
        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.binding.tvChapter.setText(list.get(position).getChapterName());
        holder.binding.tvDescription.setText(Html.fromHtml(list.get(position).getDescription()));
        holder.binding.tvAudioDuration.setText(" | "+list.get(position).getTimeDuration()+" "+list.get(position).getSelectTime());
        holder.binding.tvAudioDuration.setVisibility(list.get(position).getTimeDuration().isEmpty()?View.GONE:View.VISIBLE);
        holder.binding.tvPdfPages.setText(" | "+list.get(position).getPdfCount()+" Pages");
        holder.binding.tvPdfPages.setVisibility(list.get(position).getPdfCount().isEmpty()?View.GONE:View.VISIBLE);
        if (list.get(position).getChapterImage() != null) {
            if (!list.get(position).getChapterImage().isEmpty()) {
                Picasso.get().load(Allurls.IMAGEURL + list.get(position).getChapterImage()).error(R.drawable.default_img).placeholder(R.drawable.default_img).into(holder.binding.ivChapterImage);
            }
        }

        holder.binding.ivsave.setVisibility(View.VISIBLE);
        holder.binding.ivUnsave.setVisibility(View.GONE);
        if(list.get(position).getAudio() != null && list.get(position).getPdf() != null){
            if(list.get(position).getAudio().isEmpty()  && list.get(position).getPdf().isEmpty()){
                holder.binding.llAudiobookEbook.setVisibility(View.GONE);
            }else if(!list.get(position).getAudio().isEmpty() && list.get(position).getPdf().isEmpty()){
                holder.binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                holder.binding.llAudiobook.setVisibility(View.VISIBLE);
                holder.binding.llEbook.setVisibility(View.GONE);
            }else if(!list.get(position).getPdf().isEmpty() && list.get(position).getAudio().isEmpty()){
                holder.binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                holder.binding.llEbook.setVisibility(View.VISIBLE);
                holder.binding.llAudiobook.setVisibility(View.GONE);
            }else{
                holder.binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                holder.binding.llAudiobook.setVisibility(View.VISIBLE);
                holder.binding.llEbook.setVisibility(View.VISIBLE);
            }
        }else{
            holder.binding.llAudiobookEbook.setVisibility(View.GONE);
        }
        holder.binding.ivsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBottomSheetBookmarkDialog(position);
            }
        });
        holder.binding.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemClick.onItemClick(position, "_bookmark");
                notifyDataSetChanged();
            }
        });
    }

    private void showBottomSheetBookmarkDialog(int position) {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context, R.style.CustomBottomSheetDialog);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_dialog_bookmark_layout);

        btnCancel = bottomSheetDialog.findViewById(R.id.btnCancel);
        btnRemove = bottomSheetDialog.findViewById(R.id.btnRemove);
        tvChapter = bottomSheetDialog.findViewById(R.id.tvChapter);
        tvSubjectName = bottomSheetDialog.findViewById(R.id.tvSubjectName);
        llAudiobook = bottomSheetDialog.findViewById(R.id.llAudiobook);
        llEbook = bottomSheetDialog.findViewById(R.id.llEbook);
        llAudiobookEbook = bottomSheetDialog.findViewById(R.id.llAudiobookEbook);
        ivChapterImage = bottomSheetDialog.findViewById(R.id.ivChapterImage);
        tvChapter.setText(list.get(position).getChapterName());
        tvSubjectName.setText(Html.fromHtml(list.get(position).getDescription()));
        bottomtvAudioDuration = bottomSheetDialog.findViewById(R.id.bottomtvAudioDuration);
        bottomtvPdfPages = bottomSheetDialog.findViewById(R.id.bottomtvPdfPages);
        bottomtvAudioDuration.setText(" | "+list.get(position).getTimeDuration()+" "+list.get(position).getSelectTime());
        bottomtvAudioDuration.setVisibility(list.get(position).getTimeDuration().isEmpty()?View.GONE:View.VISIBLE);
        bottomtvPdfPages.setText(" | "+list.get(position).getPdfCount()+" Pages");
        bottomtvPdfPages.setVisibility(list.get(position).getPdfCount().isEmpty()?View.GONE:View.VISIBLE);

        if (list.get(position).getChapterImage() != null) {
            if (!list.get(position).getChapterImage().isEmpty()) {
                Picasso.get().load(Allurls.IMAGEURL + list.get(position).getChapterImage()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(ivChapterImage);
            }
        }
        if (list.get(position).getAudio() != null && list.get(position).getPdf() != null) {
            if (list.get(position).getAudio().isEmpty() && list.get(position).getPdf().isEmpty()) {
                llAudiobookEbook.setVisibility(View.GONE);
            } else if (!list.get(position).getAudio().isEmpty() && list.get(position).getPdf().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.GONE);
            } else if (!list.get(position).getPdf().isEmpty() && list.get(position).getAudio().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.GONE);
            } else {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            }
        } else {
            llAudiobookEbook.setVisibility(View.GONE);
        }

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog.dismiss();
            }
        });


        btnRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog.dismiss();
                itemClick.onItemClick(position, "removebookmark");
                notifyDataSetChanged();
            }
        });
        bottomSheetDialog.show();
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private final ListItemChapterBinding binding;


        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ListItemChapterBinding.bind(itemView);
        }
    }
}
package com.edutech.ncert.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.edutech.ncert.R;
import com.edutech.ncert.server.MySharedPref;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

public class AskQuestionActivity extends AppCompatActivity {

    private static final int FILE_PICK_CODE = 101;

    EditText etTitle, etDetails;
    Button btnChoose, btnSubmit;
    TextView tvFileName;
    Uri fileUri = null;
    String fileUrl = "";
    boolean editMode = false;
    String questionId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ask_question);

        etTitle = findViewById(R.id.etTitle);
        etDetails = findViewById(R.id.etDescription);
        btnChoose = findViewById(R.id.btnChooseFile);
        btnSubmit = findViewById(R.id.btnSubmit);
        tvFileName = findViewById(R.id.tvFileName);

        // 🔄 Get edit info from intent
        Intent intent = getIntent();
        editMode = intent.getBooleanExtra("edit_mode", false);
        if (editMode) {
            questionId = intent.getStringExtra("question_id");
            etTitle.setText(intent.getStringExtra("title"));
            etDetails.setText(intent.getStringExtra("details"));
            fileUrl = intent.getStringExtra("attachment");
            tvFileName.setText(fileUrl != null && !fileUrl.isEmpty() ? "File already attached" : "No file selected");
        }

        btnChoose.setOnClickListener(v -> {
            Intent intentFile = new Intent(Intent.ACTION_GET_CONTENT);
            intentFile.setType("*/*");
            startActivityForResult(intentFile, FILE_PICK_CODE);
        });

        btnSubmit.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            String details = etDetails.getText().toString().trim();
            if (title.isEmpty()) {
                Toast.makeText(this, "Please enter a title", Toast.LENGTH_SHORT).show();
                return;
            }
            uploadQuestion(title, details);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICK_CODE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            fileUri = data.getData();
            String path = fileUri.getLastPathSegment();
            tvFileName.setText(path);
        }
    }

    private void uploadQuestion(String title, String details) {
        ProgressDialog dialog = new ProgressDialog(this);
        dialog.setMessage(editMode ? "Updating..." : "Submitting...");
        dialog.setCancelable(false);
        dialog.show();

        if (fileUri != null) {
            String extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(getContentResolver().getType(fileUri));
            StorageReference storageRef = FirebaseStorage.getInstance().getReference("ask_questions/" + System.currentTimeMillis() + "." + extension);
            storageRef.putFile(fileUri).addOnSuccessListener(taskSnapshot -> {
                storageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    fileUrl = uri.toString();
                    saveToDatabase(title, details, dialog);
                });
            }).addOnFailureListener(e -> {
                dialog.dismiss();
                Toast.makeText(this, "File upload failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        } else {
            saveToDatabase(title, details, dialog);
        }
    }

    private void saveToDatabase(String title, String details, ProgressDialog dialog) {
        MySharedPref pref = new MySharedPref(this);
        String userId = pref.getSavedUserid();
        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("ask_questions");

        long now = System.currentTimeMillis() / 1000;

        Map<String, Object> data = new HashMap<>();
        data.put("user_id", userId);
        data.put("title", title);
        data.put("details", details);
        data.put("attachment", fileUrl);
        data.put("status", "pending");
        data.put("admin_reply", "");
        data.put("admin_attachment", "");
        data.put("reply_type", "text");
        data.put("is_solved", false);
        data.put("likes", 0);
        data.put("dislikes", 0);
        data.put("updated_at", now);

        if (editMode && questionId != null) {
            dbRef.child(questionId).updateChildren(data).addOnSuccessListener(unused -> {
                dialog.dismiss();
                Toast.makeText(this, "Question updated", Toast.LENGTH_SHORT).show();
                finish();
            }).addOnFailureListener(e -> {
                dialog.dismiss();
                Toast.makeText(this, "Update failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        } else {
            data.put("created_at", now);
            String id = dbRef.push().getKey();
            dbRef.child(id).setValue(data).addOnSuccessListener(unused -> {
                dialog.dismiss();
                Toast.makeText(this, "Question submitted successfully", Toast.LENGTH_SHORT).show();
                finish();
            }).addOnFailureListener(e -> {
                dialog.dismiss();
                Toast.makeText(this, "Failed to submit: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        }
    }
}



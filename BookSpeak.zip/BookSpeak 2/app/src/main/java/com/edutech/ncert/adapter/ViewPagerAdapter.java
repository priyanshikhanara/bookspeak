package com.edutech.ncert.adapter;


import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import com.edutech.ncert.fragment.TabBookmarkFragment;
import com.edutech.ncert.fragment.TabLikesFragment;

public class ViewPagerAdapter extends FragmentStatePagerAdapter {

    public ViewPagerAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        if (position == 0)
            fragment = new TabBookmarkFragment();
         else if (position == 1)
            fragment = new TabLikesFragment();

        return fragment;
    }

    @Override
    public int getCount() {
        return 2;
    }

}

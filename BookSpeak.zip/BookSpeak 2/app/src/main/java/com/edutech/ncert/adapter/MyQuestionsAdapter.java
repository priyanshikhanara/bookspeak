package com.edutech.ncert.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.edutech.ncert.R;
import com.edutech.ncert.activity.AskQuestionActivity;
import com.edutech.ncert.activity.QuestionDetailActivity;
import com.edutech.ncert.model.QuestionModel;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class MyQuestionsAdapter extends RecyclerView.Adapter<MyQuestionsAdapter.ViewHolder> {

    private Context context;
    private List<QuestionModel> questionList;
    private Activity activity;

    public MyQuestionsAdapter(Context context, List<QuestionModel> questionList, Activity activity) {
        this.context = context;
        this.questionList = questionList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_my_question, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (position >= questionList.size()) return;

        QuestionModel model = questionList.get(position);

        holder.tvTitle.setText(model.getTitle());
        holder.tvStatus.setText("Status: " + model.getStatus());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, QuestionDetailActivity.class);
            intent.putExtra("title", model.getTitle());
            intent.putExtra("details", model.getDetails());
            intent.putExtra("status", model.getStatus());
            intent.putExtra("reply", model.getAdmin_reply());
            intent.putExtra("admin_attachment", model.getAdmin_attachment());
            intent.putExtra("reply_type", model.getReply_type());
            intent.putExtra("attachment", model.getAttachment());
            intent.putExtra("question_id", model.getId());
            context.startActivity(intent);
        });

        // Edit
        holder.btnEdit.setOnClickListener(v -> {
            if (context instanceof Activity) {
                Intent editIntent = new Intent(context, AskQuestionActivity.class);
                editIntent.putExtra("edit_mode", true);
                editIntent.putExtra("question_id", model.getId());
                editIntent.putExtra("title", model.getTitle());
                editIntent.putExtra("details", model.getDetails());
                editIntent.putExtra("attachment", model.getAttachment());
                ((Activity) context).startActivityForResult(editIntent, 101);
            } else {
                Toast.makeText(context, "Unable to launch edit screen", Toast.LENGTH_SHORT).show();
            }
        });

        // Delete
        holder.btnDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Delete Question")
                    .setMessage("Are you sure you want to delete this question?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        FirebaseDatabase.getInstance().getReference("ask_questions")
                                .child(model.getId())
                                .removeValue()
                                .addOnSuccessListener(unused -> {
                                    Toast.makeText(context, "Deleted", Toast.LENGTH_SHORT).show();
                                    if (position < questionList.size()) {
                                        questionList.remove(position);
                                        notifyItemRemoved(position);
                                        notifyItemRangeChanged(position, questionList.size());
                                    }
                                })
                                .addOnFailureListener(e -> Toast.makeText(context, "Failed to delete", Toast.LENGTH_SHORT).show());
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return questionList != null ? questionList.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvStatus;
        ImageView btnEdit, btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}

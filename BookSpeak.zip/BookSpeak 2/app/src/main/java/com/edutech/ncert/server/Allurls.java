package com.edutech.ncert.server;

public class Allurls {
    //https://mobidudes.com/MJ/bookspeak/
    public static final String MainURL = "https://ncert.schooltopper.in/api/";
    public static final String IMAGEURL = "https://ncert.schooltopper.in/";
//    public static final String MainURL = "https://rbseexams.textbooksolutions.in/api/";
//    public static final String IMAGEURL = "https://rbseexams.textbooksolutions.in/";

//    public static final String MainURL = "https://mobidudes.com/MJ/bookspeak/api/";
//    public static final String IMAGEURL = "https://mobidudes.com/MJ/bookspeak/";
}

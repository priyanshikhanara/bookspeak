package com.edutech.ncert.model.BookModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OtherDetail {

    @SerializedName("class_name")
    @Expose
    private String className;
    @SerializedName("medium_name")
    @Expose
    private String mediumName;
    @SerializedName("subject_name")
    @Expose
    private String subjectName;

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getMediumName() {
        return mediumName;
    }

    public void setMediumName(String mediumName) {
        this.mediumName = mediumName;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

}

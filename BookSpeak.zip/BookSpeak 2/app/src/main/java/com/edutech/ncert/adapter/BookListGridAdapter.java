package com.edutech.ncert.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ListItemBookBinding;
import com.edutech.ncert.databinding.ListItemGridBookBinding;
import com.edutech.ncert.model.BookModel.Datum;
import com.edutech.ncert.server.Allurls;
import com.edutech.ncert.server.MySharedPref;
import com.squareup.picasso.Picasso;

import java.util.List;

public class BookListGridAdapter extends RecyclerView.Adapter<BookListGridAdapter.RecyclerViewHolder> {
    Context context;
    List<Datum> list;
    int selectPosition = -1;
    ItemClick itemClick;
    private final MySharedPref mySharedPref;

    public BookListGridAdapter(Context context, List<Datum>  list, ItemClick itemClick) {
        this.context = context;
        this.list = list;
        this.itemClick = itemClick;
        mySharedPref = new MySharedPref(context);
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item_grid_book, parent, false);
        RecyclerViewHolder recyclerViewHolder = new RecyclerViewHolder(view);
        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.binding.tvBookName.setText(list.get(position).getName());
        holder.binding.tvAuthorName.setText(list.get(position).getAuthorName());
        if(!list.get(position).getBookImage().equals("")){
            Picasso.get().load(Allurls.IMAGEURL+list.get(position).getBookImage()).error(R.drawable.default_img).placeholder(R.drawable.default_img).into(holder.binding.ivBookImage);
        }

        holder.binding.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectPosition = position;
                itemClick.onItemClick(position,"_Book");
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private final ListItemGridBookBinding binding;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ListItemGridBookBinding.bind(itemView);

        }
    }
}
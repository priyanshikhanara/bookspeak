package com.edutech.ncert.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ActivityLoginMainBinding;
import com.edutech.ncert.model.Login.LoginParaRes;
import com.edutech.ncert.model.Login.LoginRes;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;
import com.hbb20.CountryCodePicker;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginMainActivity extends AppCompatActivity implements View.OnClickListener{

    Context context;
    private ActivityLoginMainBinding binding;
    private String fcm_token = "test";
    private String device_id = "";
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private MySharedPref mySharedPref;
    String countryCode = "91";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();
        onclicks();
    }


    public void init() {
        context = LoginMainActivity.this;
        jsonPlaceHolderApi = ApiUtils.getAPIService();
        mySharedPref = new MySharedPref(context);
        fcm_token = mySharedPref.getSavedFcmToken();
        CountryCodepicker();
        device_id = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);

    }

    private void CountryCodepicker() {
       /* binding.ccp.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
            @Override
            public void onCountrySelected(Country selectedCountry) {
                countryCode = selectedCountry.getPhoneCode();
                Log.d("TAG", "countryCode>>" + countryCode);
            }
        });*/
        binding.ccp.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
            @Override
            public void onCountrySelected() {
                countryCode = binding.ccp.getSelectedCountryCode();
                Log.d("TAG", "countryCode>>" + countryCode);
            }
        });
    }

    public void onclicks() {
        binding.btnSubmit.setOnClickListener(this);
        binding.btnSkip.setOnClickListener(this);
        binding.lytSignup.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSubmit:
                if (isValidate()) {
                    if (Constants.isInternetConnected(context)) {
                        loginAPI();
                    } else {
                        Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                    }

                }
                break;

            case R.id.btnSkip:
                startActivity(new Intent(context, HomeActivity.class)
                        .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                finish();
                break;

            case R.id.lytSignup:
                startActivity(new Intent(context, SignupActivity.class)
                        .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                finish();
                break;
        }
    }


    public void loginAPI() {
        Customprogress.showPopupProgressSpinner(context, false);
        LoginParaRes loginParaRes = new LoginParaRes();
        loginParaRes.setPhone(binding.etPhone.getText().toString().trim());
        loginParaRes.setCountryCode(countryCode);
        loginParaRes.setFcmToken(fcm_token);
        loginParaRes.setDeviceId(device_id);
        loginParaRes.setDevice(Constants.DEVICE_TYPE);


        jsonPlaceHolderApi.loginAPI("application/json", "application/json", loginParaRes).enqueue(new Callback<LoginRes>() {
            @Override
            public void onResponse(Call<LoginRes> call, Response<LoginRes> response) {
                if (response.isSuccessful()) {
                    Boolean status = response.body().getStatus();
                    Customprogress.showPopupProgressSpinner(context, false);
                    if (status) {
//                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
//                        Toast.makeText(context, "OTP sent to your phone number", Toast.LENGTH_SHORT).show();
//                        mySharedPref.saveLogin(true);
                        mySharedPref.setSavedAccessToken(String.valueOf(response.body().getData().getToken()));
                        mySharedPref.setSavedUserid(String.valueOf(response.body().getData().getUserId()));
//                        Intent i = new Intent(context, HomeActivity.class);
                        Intent i = new Intent(context, OtpVerificationActivity.class);
//                        i.putExtra("name",binding.etName.getText().toString());
                        i.putExtra("phone",binding.etPhone.getText().toString());
                        i.putExtra("countryCode",countryCode);
//                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
//                        finish();

                    } else {
                        // 🚫 User not registered → move to Signup screen
                        Intent intent = new Intent(context, SignupActivity.class);
                        intent.putExtra("phone", binding.etPhone.getText().toString());
                        intent.putExtra("countryCode", countryCode);
                        startActivity(intent);
                        Toast.makeText(context, "No account found. Please sign up.", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<LoginRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
    private Boolean isValidate() {
        if (binding.etPhone.getText().toString().trim().isEmpty()) {
            Toast.makeText(context, R.string.please_enter_your_phone_number, Toast.LENGTH_SHORT).show();
            return false;
        } else if (binding.etPhone.getText().toString().trim().length() < 8) {
            Toast.makeText(context, R.string.phone_number_should_be_atleast_8_digits, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
package com.edutech.ncert.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.text.HtmlCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ListItemBookBinding;
import com.edutech.ncert.model.BookModel.Datum;
import com.edutech.ncert.server.Allurls;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.OpenLoginDialogClass;
import com.squareup.picasso.Picasso;

import java.util.List;

public class BookListAdapter extends RecyclerView.Adapter<BookListAdapter.RecyclerViewHolder> {
    Context context;
    List<Datum> list;
    int selectPosition = -1;
    ItemClick itemClick;
    private final MySharedPref mySharedPref;

    public BookListAdapter(Context context,List<Datum>  list,ItemClick itemClick) {
        this.context = context;
        this.list = list;
        this.itemClick = itemClick;
        mySharedPref = new MySharedPref(context);
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item_book, parent, false);
        RecyclerViewHolder recyclerViewHolder = new RecyclerViewHolder(view);
        return recyclerViewHolder;
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, @SuppressLint("RecyclerView") int position) {
        // Set Chapter Number (formatted as 01, 02, 03)
        String chapterNumber = String.format("%02d", position + 1);  // Position starts at 0, so we add 1 to make it 01, 02, etc.
        holder.binding.tvChapterNumber.setText(chapterNumber);  // Assuming you have a TextView with id tvChapterNumber in your layout

        // Set Book Name (Title)
        holder.binding.tvBookName.setText(list.get(position).getName());

        // Set Description (Chapter count or other details)
        String count = list.get(position).getChapterCount();
        holder.binding.tvDescription.setText((count != null ? count : "0") + " Docs");

        // Set Like Count
        holder.binding.tvLikeCount.setText(list.get(position).getLike_count().toString());

        // Set Like/Unlike Visibility
        if (list.get(position).getStatus().equals("true")) {
            holder.binding.ivLike.setVisibility(View.VISIBLE);
            holder.binding.ivUnlike.setVisibility(View.GONE);
        } else {
            holder.binding.ivLike.setVisibility(View.GONE);
            holder.binding.ivUnlike.setVisibility(View.VISIBLE);
        }

        // Handle Like/Unlike click
        holder.binding.llLikeUnlike.setOnClickListener(view -> {
            if (mySharedPref.isLogin()) {
                itemClick.onItemClick(position, "likeUnlike");
                notifyDataSetChanged();
            } else {
                OpenLoginDialogClass.openLoginDialog(context);
            }
        });

        // Handle Book Item click
        holder.binding.llMain.setOnClickListener(view -> {
            selectPosition = position;
            itemClick.onItemClick(position, "_Book");
            notifyDataSetChanged();
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private final ListItemBookBinding binding;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ListItemBookBinding.bind(itemView);

        }
    }
}
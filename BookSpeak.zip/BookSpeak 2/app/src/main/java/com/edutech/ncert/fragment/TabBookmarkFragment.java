package com.edutech.ncert.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.activity.ChapterDetailActivity;
import com.edutech.ncert.adapter.TabBookmarkListAdapter;
import com.edutech.ncert.databinding.FragmentTabBookmarkBinding;
import com.edutech.ncert.model.ChapterModel.ChapterRes;
import com.edutech.ncert.model.ChapterModel.Datum;
import com.edutech.ncert.model.ChapterModel.OtherDetail;
import com.edutech.ncert.model.RemoveBookmark.RemoveBookmarkParaRes;
import com.edutech.ncert.model.RemoveBookmark.RemoveBookmarkRes;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;
import com.edutech.ncert.utils.OpenLoginDialogClass;

import java.io.Serializable;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TabBookmarkFragment extends Fragment {
    Context context;
    private FragmentTabBookmarkBinding binding;
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private MySharedPref mySharedPref;
    OtherDetail otherDetail;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentTabBookmarkBinding.inflate(inflater, container, false);
        init();
        return binding.getRoot();
    }

    public void init() {
        context = binding.getRoot().getContext();
        jsonPlaceHolderApi = ApiUtils.getAPIService();
        mySharedPref = new MySharedPref(context);

        if (Constants.isInternetConnected(context)) {
            GetBookmarkAPI();
        } else {
            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
        }
    }

    private void setBookmarkListData(List<Datum> bookmarkList) {
        if (bookmarkList.size() != 0) {
            binding.rvBookmark.setVisibility(View.VISIBLE);
            binding.llNoData.setVisibility(View.GONE);
            TabBookmarkListAdapter adapter = new TabBookmarkListAdapter(context, bookmarkList, new ItemClick() {
                @Override
                public void onItemClick(int position, String type) {
                    Log.d("TAG!!123","id>>"+bookmarkList.get(position).getId().toString());
                 if (type.equals("removebookmark")) {
                     if (Constants.isInternetConnected(context)) {
                         RemoveBookmarkAPI(bookmarkList.get(position).getBookmark_id());
                     } else {
                         Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                     }
                 }else{
                     startActivity(new Intent(context, ChapterDetailActivity.class)
                             .putExtra("ChapterDetail", bookmarkList.get(position))
                             .putExtra("otherDetail", otherDetail)
                             .putExtra("chapterList", (Serializable) bookmarkList)
                             .putExtra("positionChapter", String.valueOf(position))
                     );
                 }
                }
            });
            binding.rvBookmark.setHasFixedSize(true);
            binding.rvBookmark.setLayoutManager(new LinearLayoutManager(context));
            binding.rvBookmark.setAdapter(adapter);
        } else {
            binding.rvBookmark.setVisibility(View.GONE);
            binding.llNoData.setVisibility(View.VISIBLE);
        }
    }
    public void GetBookmarkAPI() {
        Customprogress.showPopupProgressSpinner(context, false);

        jsonPlaceHolderApi.GetBookmarkAPI(
                        "application/json",
                        "application/json",
                        "Bearer " + mySharedPref.getSavedAccessToken())
                .enqueue(new Callback<ChapterRes>() {

                    @Override
                    public void onResponse(Call<ChapterRes> call, Response<ChapterRes> response) {
                        Customprogress.showPopupProgressSpinner(context, false); // ✅ Always hide

                        if (response.isSuccessful()) {
                            Boolean status = response.body().getStatus();

                            if (status) {
                                Log.d("TAG22", "status2");
                                setBookmarkListData(response.body().getData());
                                otherDetail = response.body().getOtherDetail();

                                binding.rvBookmark.setVisibility(View.VISIBLE);
                                binding.llNoData.setVisibility(View.GONE);

                            } else {
                                binding.rvBookmark.setVisibility(View.GONE);
                                binding.llNoData.setVisibility(View.VISIBLE);

                                // ✅ Extra safe: always hide spinner before return
                                if ("Your account has been blocked by admin.".equals(response.body().getMessage())) {
                                    OpenLoginDialogClass.openBlockDeleteDialog(context, response.body().getMessage());
                                }
                            }
                        } else {
                            Customprogress.showPopupProgressSpinner(context, false); // ✅ already present
                            binding.rvBookmark.setVisibility(View.GONE);
                            binding.llNoData.setVisibility(View.VISIBLE);

                            if (response.code() == 401) {
                                OpenLoginDialogClass.openBlockDeleteDialog(context, "User not found");
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<ChapterRes> call, Throwable t) {
                        Customprogress.showPopupProgressSpinner(context, false);
                        Log.d("TAG22", "status0");
                        binding.rvBookmark.setVisibility(View.GONE);
                        binding.llNoData.setVisibility(View.VISIBLE);
                    }
                });
    }



    public void RemoveBookmarkAPI(String bookmarkId) {
        Customprogress.showPopupProgressSpinner(context, false);
        RemoveBookmarkParaRes removeBookmarkParaRes = new RemoveBookmarkParaRes();
        removeBookmarkParaRes.setBookmarkId(bookmarkId);

        jsonPlaceHolderApi.RemoveBookmarkAPI("application/json", "application/json", "Bearer " + mySharedPref.getSavedAccessToken(), removeBookmarkParaRes)
                .enqueue(new Callback<RemoveBookmarkRes>() {
                    @Override
                    public void onResponse(Call<RemoveBookmarkRes> call, Response<RemoveBookmarkRes> response) {
                        Customprogress.showPopupProgressSpinner(context, false); // ✅ always hide on response

                        if (response.isSuccessful()) {
                            Boolean status = response.body().getStatus();
                            if (status) {
                                Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                                if (Constants.isInternetConnected(context)) {
                                    GetBookmarkAPI(); // refresh
                                } else {
                                    Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(context, getResources().getString(R.string.server_error), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<RemoveBookmarkRes> call, Throwable t) {
                        Customprogress.showPopupProgressSpinner(context, false);
                        Log.e("TAG", t.getMessage());
                    }
                });
    }}

package com.edutech.ncert.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.edutech.ncert.R;

public class NotificationAudioActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_audio);
    }
}
package com.edutech.ncert.utils;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.edutech.ncert.R;
import com.edutech.ncert.activity.HomeActivity;
import com.edutech.ncert.activity.LoginMainActivity;
import com.edutech.ncert.server.MySharedPref;

public  class OpenLoginDialogClass {
    public static void openLoginDialog(Context context){
        final Dialog dialog = new Dialog(context);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.setContentView(R.layout.dialog_first_login);
        TextView txt_ok = dialog.findViewById(R.id.txt_ok);
        TextView txt_cancle = dialog.findViewById(R.id.txt_cancle);
        txt_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Intent intent = new Intent(context, LoginMainActivity.class);
                context.startActivity(intent);
            }
        });
        txt_cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public static void openBlockDeleteDialog(Context context,String msg) {
        MySharedPref mySharedPref = new MySharedPref(context);
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(msg);
        builder.setCancelable(false);
        builder.setNegativeButton(context.getResources().getString(R.string.OK), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (Constants.isInternetConnected(context)) {
                    mySharedPref.saveLogin(false);
                    mySharedPref.setSavedAccessToken("");
                    mySharedPref.setSavedUserid("");
                    Intent intent = new Intent(context, HomeActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    context.startActivity(intent);
                } else {
                    Toast.makeText(context, context.getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                }
                dialog.cancel();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}

package com.edutech.ncert.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ActivityLoginBinding;
import com.edutech.ncert.model.Signup.SignUpRes;
import com.edutech.ncert.model.Signup.SignupParaRes;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;
import com.hbb20.CountryCodePicker;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupActivity extends AppCompatActivity implements View.OnClickListener{
    Context context;
    private ActivityLoginBinding binding;
    private String fcm_token = "test";
    private String device_id = "";
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private MySharedPref mySharedPref;
    String countryCode = "91";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();
        onclicks();
    }

    public void init() {
        context = SignupActivity.this;
        jsonPlaceHolderApi = ApiUtils.getAPIService();
        mySharedPref = new MySharedPref(context);
        fcm_token = mySharedPref.getSavedFcmToken();
        String text1 = "By Continuing, you agree to our Terms & Conditions and Privacy Policies.";
        SpannableString spannableString1 = new SpannableString(text1);
        ClickableSpan clickableSpan11 = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                Intent intent11 = new Intent(context, TermsAndConditionActivity.class);
                startActivity(intent11);
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(true);
            }
        };
        ClickableSpan clickableSpan12 = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                Intent intent11 = new Intent(context, PrivacyPolicyActivity.class);
                startActivity(intent11);
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(true);
            }
        };
        spannableString1.setSpan(clickableSpan11, 32, 50, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString1.setSpan(clickableSpan12, 55, 72, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString1.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.black)), 0, text1.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        binding.tvCheck.setText(spannableString1);
        binding.tvCheck.setMovementMethod(LinkMovementMethod.getInstance());

        CountryCodepicker();
        device_id = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);

    }

    private void CountryCodepicker() {
        /*binding.ccp.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
            @Override
            public void onCountrySelected(Country selectedCountry) {
                countryCode = selectedCountry.getPhoneCode();
                Log.d("TAG", "countryCode>>" + countryCode);
            }
        });*/

        binding.ccp.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
            @Override
            public void onCountrySelected() {
                countryCode = binding.ccp.getSelectedCountryCode();
                Log.d("TAG", "countryCode>>" + countryCode);
            }
        });
    }
    public void onclicks() {
        binding.btnSubmit.setOnClickListener(this);
        binding.btnSkip.setOnClickListener(this);
        binding.lytLogin.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSubmit:
                if (isValidate()) {
                    if (Constants.isInternetConnected(context)) {
                        SignupAPI();
                    } else {
                        Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                    }

                }
                break;

            case R.id.btnSkip:
                startActivity(new Intent(context, HomeActivity.class)
                        .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                finish();
                break;


                case R.id.lytLogin:
                startActivity(new Intent(context, LoginMainActivity.class)
                        .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                finish();
                break;
        }
    }


    public void SignupAPI() {
        Customprogress.showPopupProgressSpinner(context, false);
        SignupParaRes signupParaRes = new SignupParaRes();
        signupParaRes.setName(binding.etName.getText().toString().trim());
        signupParaRes.setPhone(binding.etPhone.getText().toString().trim());
        signupParaRes.setCountryCode(countryCode);
        signupParaRes.setFcmToken(fcm_token);
        signupParaRes.setDeviceId(device_id);
        signupParaRes.setDevice(Constants.DEVICE_TYPE);

        jsonPlaceHolderApi.signupAPI("application/json", "application/json", signupParaRes).enqueue(new Callback<SignUpRes>() {
            @Override
            public void onResponse(Call<SignUpRes> call, Response<SignUpRes> response) {
                if (response.isSuccessful()) {
                    Boolean status = response.body().getStatus();
                    Customprogress.showPopupProgressSpinner(context, false);
                    if (status) {
//                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        Toast.makeText(context, "OTP sent to your phone number", Toast.LENGTH_SHORT).show();
                        mySharedPref.setSavedAccessToken(String.valueOf(response.body().getData().getAccessToken()));
                        mySharedPref.setSavedUserid(String.valueOf(response.body().getData().getUserId()));
                        Intent i = new Intent(context, OtpVerificationActivity.class);
//                        i.putExtra("name",binding.etName.getText().toString());
                        i.putExtra("phone",binding.etPhone.getText().toString());
                        i.putExtra("countryCode",countryCode);
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finish();

                    } else {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<SignUpRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
    private Boolean isValidate() {
        if (binding.etName.getText().toString().trim().isEmpty()) {
            Toast.makeText(context, R.string.Please_enter_your_name, Toast.LENGTH_SHORT).show();
            return false;
        } else if (binding.etPhone.getText().toString().trim().isEmpty()) {
            Toast.makeText(context, R.string.please_enter_your_phone_number, Toast.LENGTH_SHORT).show();
            return false;
        } else if (binding.etPhone.getText().toString().trim().length() < 8) {
            Toast.makeText(context, R.string.phone_number_should_be_atleast_8_digits, Toast.LENGTH_SHORT).show();
            return false;
        } else if (!binding.cbAgree.isChecked()) {
            Toast.makeText(context, R.string.please_accept_the_terms_and_conditions, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
package com.edutech.ncert.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ListItemClassBinding;
import com.edutech.ncert.model.ClassModel.Clas;

import java.util.List;

public class ClassListAdapter extends RecyclerView.Adapter<ClassListAdapter.RecyclerViewHolder> {
    Context context;
    List<Clas> list;
    ItemClick itemClick;

    public ClassListAdapter(Context context, List<Clas> list, ItemClick itemClick) {
        this.context = context;
        this.list = list;
        this.itemClick = itemClick;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item_class, parent, false);
        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Clas currentItem = list.get(position);

        holder.binding.tvTitle.setText(currentItem.getAddClass());

        String imageUrl = currentItem.getImage() != null
                ? "https://ncert.schooltopper.in/public/" + currentItem.getImage()
                : "https://ncert.schooltopper.in/public/uploads/book/ic_launcher.png";

        Glide.with(context)
                .load(imageUrl)
                .centerCrop()
                .placeholder(R.drawable.ic_splash_logo)
                .error(R.drawable.ic_splash_logo)
                .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.ALL)
                .dontTransform()
                .into(holder.binding.ivClassImage);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemClick.onItemClick(position, "_class");
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private final ListItemClassBinding binding;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ListItemClassBinding.bind(itemView);
        }
    }
}

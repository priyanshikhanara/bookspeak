package com.edutech.ncert.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ActivitySplashBinding;
import com.edutech.ncert.model.ClassModel.ClassParaRes;
import com.edutech.ncert.model.ClassModel.ClassRes;
import com.edutech.ncert.model.MaintenanceModel.MaintenanceRes;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.PrefManager;
import com.edutech.ncert.utils.VersionUtils;
import com.onesignal.Continue;
import com.onesignal.OneSignal;
import com.onesignal.debug.LogLevel;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SplashActivity extends AppCompatActivity {

    private Context context;
    private ActivitySplashBinding binding;
    private MySharedPref mySharedPref;
    private PrefManager prefManager;
    private JsonPlaceHolderApi jsonPlaceHolderApi;

    private final Handler fallbackHandler = new Handler();
    private final Runnable fallbackRunnable = this::startApp;
    private Call<ClassRes> classApiCall;
    private Call<MaintenanceRes> maintenanceApiCall;
    private boolean appStarted = false;
    private static final String TAG = "SplashActivity";
    private static final String ONESIGNAL_APP_ID = "20a7d279-8266-4274-b748-6f28f5c1d89e";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        context = this;
        OneSignal.getDebug().setLogLevel(LogLevel.VERBOSE);
        OneSignal.initWithContext(this, ONESIGNAL_APP_ID);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            OneSignal.getNotifications().requestPermission(true, Continue.with(r -> {
                if (r.isSuccess()) {
                    if (r.getData()) {
                        init();

                        // `requestPermission` completed successfully and the user has accepted permission
                    }
                    else {
                        init();

                        // `requestPermission` completed successfully but the user has rejected permission
                    }
                }
                else {
                    init();

                    // `requestPermission` completed unsuccessfully, check `r.getThrowable()` for more info on the failure reason
                }
            }));
        }else {
            init();

        }
        fallbackHandler.postDelayed(fallbackRunnable, 6000); // fallback after 6 seconds max
    }

    private void init() {
        jsonPlaceHolderApi = ApiUtils.getAPIService();
        mySharedPref = new MySharedPref(context);
        prefManager = new PrefManager(context);
        changeStatusBarColor();
        if (Constants.isInternetConnected(context)) {
            preloadHomeData();  // Fire both APIs in parallel
        } else {
            Toast.makeText(context, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            startApp(); // proceed if offline
        }
    }

    private void changeStatusBarColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(context, R.color.txt_blue));
        }
    }

    private void preloadHomeData() {
        fetchClassData();
        fetchMaintenanceData();  // These two now run independently
    }

    private void fetchClassData() {
        ClassParaRes classParaRes = new ClassParaRes();
        classParaRes.setFcmToken(mySharedPref.getFcmToken());
        classParaRes.setDeviceId(Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));

        classApiCall = jsonPlaceHolderApi.GetClassAPI("application/json", "application/json", classParaRes);
        classApiCall.enqueue(new Callback<ClassRes>() {
            @Override
            public void onResponse(Call<ClassRes> call, Response<ClassRes> response) {
                if (response.isSuccessful() && response.body() != null && response.body().getStatus()) {
                    mySharedPref.saveClassData(response.body());
                }
            }

            @Override
            public void onFailure(Call<ClassRes> call, Throwable t) {
                Log.e(TAG, "Class API failure: " + t.getMessage());
            }
        });
    }

    private void fetchMaintenanceData() {
        maintenanceApiCall = jsonPlaceHolderApi.MaintenanceAPI(
                "application/json", "application/json", "Bearer " + mySharedPref.getSavedAccessToken());

        maintenanceApiCall.enqueue(new Callback<MaintenanceRes>() {
            @Override
            public void onResponse(Call<MaintenanceRes> call, Response<MaintenanceRes> response) {
                if (!isFinishing() && !isDestroyed()) {
                    if (response.isSuccessful() && response.body() != null && response.body().getStatus()) {
                        MaintenanceRes data = response.body();

                        mySharedPref.setSavedInterstitialAddsStatus(data.getData().getInterstitialStatus());
                        mySharedPref.setSavedBannerAddsStatus(data.getData().getBannerStatus());
                        mySharedPref.setSavedRewardedAddsStatus(data.getData().getRewardStatus());

                        if ("Yes".equalsIgnoreCase(data.getData().getMaintenance())) {
                            showMaintenanceDialog();
                        } else if (Double.parseDouble(data.getData().getVerson()) >
                                VersionUtils.getVersionCode(SplashActivity.this)) {
                            showUpgradeDialog();
                        } else {
                            startApp();
                        }
                    } else {
                        Toast.makeText(context, "Server error", Toast.LENGTH_SHORT).show();
                        startApp();
                    }
                }
            }

            @Override
            public void onFailure(Call<MaintenanceRes> call, Throwable t) {
                Log.e(TAG, "Maintenance API failure: " + t.getMessage());
                startApp();
            }
        });
    }

    private void startApp() {
        if (appStarted) return; // Prevent duplicate launch
        appStarted = true;
        fallbackHandler.removeCallbacks(fallbackRunnable); // Cancel fallback

        runOnUiThread(() -> new Handler().postDelayed(() -> {
            Intent intent = prefManager.isFirstTimeLaunch()
                    ? new Intent(context, OnboardingActivity.class)
                    : new Intent(context, HomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }, 200));
    }

    private void showUpgradeDialog() {
        if (isFinishing() || isDestroyed()) return;
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_upgrade);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialog.findViewById(R.id.btnSubmit).setOnClickListener(v -> openPlayStore());
        dialog.show();
    }

    private void showMaintenanceDialog() {
        if (isFinishing() || isDestroyed()) return;
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_maintenance);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialog.findViewById(R.id.btnSubmit).setOnClickListener(v -> finishAffinity());
        dialog.show();
    }

    private void openPlayStore() {
        String appPackageName = "com.edutech.ncert";
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName));
            intent.setPackage("com.android.vending");
            startActivity(intent);
        } catch (android.content.ActivityNotFoundException e) {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName));
            startActivity(intent);
        }
    }

    @Override
    protected void onDestroy() {
        if (classApiCall != null) classApiCall.cancel();
        if (maintenanceApiCall != null) maintenanceApiCall.cancel();
        fallbackHandler.removeCallbacks(fallbackRunnable);
        super.onDestroy();
    }
}

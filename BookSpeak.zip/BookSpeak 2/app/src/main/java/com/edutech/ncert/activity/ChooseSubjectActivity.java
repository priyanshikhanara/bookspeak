package com.edutech.ncert.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewpager.widget.ViewPager;

import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.adapter.Sliding_adapter;
import com.edutech.ncert.adapter.SubjectListAdapter;
import com.edutech.ncert.databinding.ActivityChooseSubjectBinding;
import com.edutech.ncert.databinding.ActivityHeaderLayoutBinding;
import com.edutech.ncert.model.ChapterModel.ChapterParaRes;
import com.edutech.ncert.model.ChapterModel.ChapterRes;
import com.edutech.ncert.model.SubjectModel.Subject;
import com.edutech.ncert.model.SubjectModel.SubjectParaRes;
import com.edutech.ncert.model.SubjectModel.SubjectRes;
import com.edutech.ncert.model.SubjectModel.Subjectbanner;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChooseSubjectActivity extends AppCompatActivity implements View.OnClickListener {
    Context context;
    private ActivityChooseSubjectBinding binding;
    private ActivityHeaderLayoutBinding headerBinding;
    String title,class_id,medium_id;
    LayoutInflater mInflater;
    private PopupWindow mDropdown = null;
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private MySharedPref mySharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChooseSubjectBinding.inflate(getLayoutInflater());
        headerBinding = binding.bindingHeader;
        setContentView(binding.getRoot());
    }

    @Override
    protected void onStart() {
        super.onStart();
        init();
        onclicks();
    }

    public void init() {
        context = ChooseSubjectActivity.this;
        jsonPlaceHolderApi = ApiUtils.getAPIService();
        mySharedPref = new MySharedPref(context);
        MobileAds.initialize(context, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        binding.adView.loadAd(adRequest);
        if(mySharedPref.getSavedBannerAddsStatus().equals("Yes")){
            binding.btnAdsShow.setVisibility(View.VISIBLE);
        }else{
            binding.btnAdsShow.setVisibility(View.GONE);
        }

        Intent intent = getIntent();
        if (intent != null) {
            title = intent.getStringExtra("title");
            class_id = intent.getStringExtra("class_id");
            medium_id = intent.getStringExtra("medium_id");
            Log.d("TAG", title);
        }


        if (Constants.isInternetConnected(context)) {
            GetSubjectAPI();
        } else {
            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
        }
    }

    public void onclicks() {
        headerBinding.llBack.setOnClickListener(this);
        headerBinding.llEdit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llBack:
                onBackPressed();
                break;

            case R.id.llEdit:
                initiatePopupWindow();
                break;
        }
    }

    private PopupWindow initiatePopupWindow() {
        try {
            mInflater = (LayoutInflater) getApplicationContext()
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View layout = mInflater.inflate(R.layout.custom_popup_rate_share, null);

            final TextView menu_share = layout.findViewById(R.id.menu_share);
            final TextView menu_rate = layout.findViewById(R.id.menu_rate);

            menu_share.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mDropdown.dismiss();
                }
            });

            menu_rate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mDropdown.dismiss();
                }
            });

            layout.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            mDropdown = new PopupWindow(layout, FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT, true);
            Drawable background = getResources().getDrawable(android.R.drawable.alert_light_frame);

            mDropdown.setBackgroundDrawable(background);
            mDropdown.showAsDropDown(headerBinding.llEdit, 5, 5);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return mDropdown;
    }

    public void SetSliderData(ViewPager viewPager, List<String> image, List<Subjectbanner> subjectbanner) {
        try {
            viewPager.setAdapter(new Sliding_adapter(context, viewPager, image, new ItemClick() {
                @Override
                public void onItemClick(int position, String type) {
                    if(subjectbanner.get(position).getUrl() != null){
                        if(!subjectbanner.get(position).getUrl().isEmpty()){
                            Intent httpIntent = new Intent(Intent.ACTION_VIEW);
                            httpIntent.setData(Uri.parse("http://"+subjectbanner.get(position).getUrl()));
                            startActivity(httpIntent);
                        }else if(!subjectbanner.get(position).getChapterId().equals("0")){

                            GetChapterAPI(subjectbanner.get(position).getBookId(), Long.valueOf(subjectbanner.get(position).getChapterId()));


                        }
                    }
                }
            }));
            // binding.indicator.setViewPager(viewPager);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void GetSubjectAPI() {
        Customprogress.showPopupProgressSpinner(context, false);
        SubjectParaRes subjectParaRes = new SubjectParaRes();
        subjectParaRes.setClassId(class_id);
        subjectParaRes.setMediumId(medium_id);

        jsonPlaceHolderApi.GetSubjectAPI("application/json", "application/json", subjectParaRes).enqueue(new Callback<SubjectRes>() {
            @Override
            public void onResponse(Call<SubjectRes> call, Response<SubjectRes> response) {
                Customprogress.showPopupProgressSpinner(context, false);
                if (response.isSuccessful()) {
                    Boolean status = response.body().getStatus();
                    if (status) {
                        List<Subjectbanner> banners = response.body().getData().getSubjectbanner();

                        if (banners != null && !banners.isEmpty()) {
                            List<String> image = new ArrayList<>();
                            for (Subjectbanner banner : banners) {
                                image.add(banner.getImage());
                            }
                            binding.layoutBannerContainer.setVisibility(View.VISIBLE); // Show the full banner layout
                            SetSliderData(binding.imgViewPager, image, banners);
                        } else {
                            binding.layoutBannerContainer.setVisibility(View.GONE);

// Remove padding dynamically
                            binding.outerLinearLayout.setPadding(0, 0, 0, 0);
                        }

                        setSubjectData(response.body().getData().getSubject());
                        headerBinding.tvTitle.setText(response.body().getUserdetail().getClassName() + " (" + title + ")");
                    } else {
                        binding.llNoData.setVisibility(View.VISIBLE);
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Log.d("TAG", ">>" + response.message());
                    binding.llNoData.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<SubjectRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
                binding.llNoData.setVisibility(View.VISIBLE);
            }
        });
    }

    private void setSubjectData(List<Subject> subjectList) {
        if (subjectList.size() != 0) {
            binding.rvSubject.setVisibility(View.VISIBLE);
            binding.llNoData.setVisibility(View.GONE);
            SubjectListAdapter adapter = new SubjectListAdapter(context, subjectList, new ItemClick() {
                @Override
                public void onItemClick(int position, String type) {
                    startActivity(new Intent(context, ChooseBookActivity.class)
                            .putExtra("title",subjectList.get(position).getSubject())
                            .putExtra("class_id",class_id)
                            .putExtra("medium_id",medium_id)
                            .putExtra("subject_id",subjectList.get(position).getId().toString())
                    );
                }
            });
            binding.rvSubject.setHasFixedSize(true);
            if (Constants.showInGrid){
                binding.rvSubject.setLayoutManager(new GridLayoutManager(context,2));
            }else {
                binding.rvSubject.setLayoutManager(new LinearLayoutManager(context));
            }

            binding.rvSubject.setAdapter(adapter);
        } else {
            binding.rvSubject.setVisibility(View.GONE);
            binding.llNoData.setVisibility(View.VISIBLE);
        }
    }

    public void GetChapterAPI(String book_id,Long chapter_id) {
        Customprogress.showPopupProgressSpinner(context, false);
        ChapterParaRes chapterParaRes = new ChapterParaRes();
        chapterParaRes.setUserId(mySharedPref.getSavedUserid());
        chapterParaRes.setClassId(class_id);
        chapterParaRes.setBookId(book_id);

        jsonPlaceHolderApi.GetChapterAPI("application/json", "application/json", chapterParaRes).enqueue(new Callback<ChapterRes>() {
            @Override
            public void onResponse(Call<ChapterRes> call, Response<ChapterRes> response) {
                if (response.isSuccessful()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {
                        for (int i = 0; i < response.body().getData().size(); i++) {
                            //do something with object
                            if(response.body().getData().get(i).getId()==chapter_id){
                                System.out.println("Selected bookid?>>>>>>>>  "+response.body().getData().get(i).getId()+"  banner>>>  "+chapter_id);
                                startActivity(new Intent(context, ChapterDetailActivity.class)
                                        .putExtra("ChapterDetail", response.body().getData().get(i))
                                        .putExtra("otherDetail", response.body().getOtherDetail())
                                        .putExtra("chapterList", (Serializable) response.body().getData())
                                        .putExtra("positionChapter", String.valueOf(i)));
                            }

                        }




                    } else {
                        binding.llNoData.setVisibility(View.VISIBLE);
                        //  Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Log.d("TAG", ">>" + response.message());
                    binding.llNoData.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<ChapterRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
                binding.llNoData.setVisibility(View.VISIBLE);
            }
        });
    }
}
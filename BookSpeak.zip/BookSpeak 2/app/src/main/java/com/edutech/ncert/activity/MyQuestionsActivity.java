package com.edutech.ncert.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.edutech.ncert.R;
import com.edutech.ncert.adapter.MyQuestionsAdapter;
import com.edutech.ncert.model.QuestionModel;
import com.edutech.ncert.server.MySharedPref;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MyQuestionsActivity extends AppCompatActivity {

    private static final int REQUEST_EDIT_QUESTION = 101;
    private RecyclerView recyclerView;
    private MyQuestionsAdapter adapter;
    private List<QuestionModel> questionList;
    private MySharedPref mySharedPref;
    private DatabaseReference databaseReference;
    private Button btnAsk;
    private ProgressBar progressBar; // ✅ added

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_questions);

        recyclerView = findViewById(R.id.recyclerView);
        btnAsk = findViewById(R.id.btnAskQuestion);
        progressBar = findViewById(R.id.progressBar); // ✅ bind progressBar

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        questionList = new ArrayList<>();
        adapter = new MyQuestionsAdapter(this, questionList, this);
        recyclerView.setAdapter(adapter);

        mySharedPref = new MySharedPref(this);
        databaseReference = FirebaseDatabase.getInstance().getReference("ask_questions");

        btnAsk.setOnClickListener(v -> {
            Intent intent = new Intent(MyQuestionsActivity.this, AskQuestionActivity.class);
            startActivityForResult(intent, REQUEST_EDIT_QUESTION);
        });

        loadQuestions();
    }

    private void loadQuestions() {
        progressBar.setVisibility(View.VISIBLE); // ✅ show while loading

        String userId = mySharedPref.getSavedUserid();
        databaseReference.orderByChild("user_id").equalTo(userId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        questionList.clear();
                        for (DataSnapshot data : snapshot.getChildren()) {
                            QuestionModel model = data.getValue(QuestionModel.class);
                            if (model != null) {
                                model.setId(data.getKey());
                                questionList.add(model);
                            }
                        }
                        adapter.notifyDataSetChanged();
                        progressBar.setVisibility(View.GONE); // ✅ hide when done
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(MyQuestionsActivity.this, "Failed to load questions", Toast.LENGTH_SHORT).show();
                        progressBar.setVisibility(View.GONE); // ✅ hide on error too
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_EDIT_QUESTION && resultCode == RESULT_OK) {
            loadQuestions(); // refresh list on return
        }
    }
}

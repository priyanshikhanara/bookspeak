package com.edutech.ncert.Interface;

public interface ItemClick {
    void onItemClick(int position, String type);
}

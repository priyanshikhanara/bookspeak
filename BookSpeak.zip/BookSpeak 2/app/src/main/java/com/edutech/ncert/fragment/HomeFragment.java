package com.edutech.ncert.fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewpager.widget.ViewPager;

import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.activity.ChooseMediumActivity;
import com.edutech.ncert.activity.HomeActivity;
import com.edutech.ncert.adapter.ClassListAdapter;
import com.edutech.ncert.adapter.Sliding_adapter;
import com.edutech.ncert.databinding.FragmentHomeBinding;
import com.edutech.ncert.model.ClassModel.Clas;
import com.edutech.ncert.model.ClassModel.ClassParaRes;
import com.edutech.ncert.model.ClassModel.ClassRes;
import com.edutech.ncert.model.ClassModel.Classbanner;
import com.edutech.ncert.model.GetProfile.Data;
import com.edutech.ncert.model.GetProfile.GetProfileRes;
import com.edutech.ncert.server.Allurls;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.OpenLoginDialogClass;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {
    Context context;
    private FragmentHomeBinding binding;
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private MySharedPref mySharedPref;
    private String device_id = "";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        context = binding.getRoot().getContext();
        HomeActivity.chipNavigationBar.setItemSelected(R.id.menu_home, true);
        LayoutInflater.from(context).inflate(R.layout.activity_choose_medium, null);
        init();
        return binding.getRoot();
    }

    public void init() {
        jsonPlaceHolderApi = ApiUtils.getAPIService();
        mySharedPref = new MySharedPref(context);
        device_id = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);

        binding.rlLoader.setVisibility(View.VISIBLE);

        ClassRes cachedClassData = mySharedPref.getCachedClassData1();
        if (cachedClassData != null && cachedClassData.getStatus()) {
            updateUIWithClassData(cachedClassData);
        }

        if (Constants.isInternetConnected(context)) {
            GetClassAPI();
        } else {
            binding.rlLoader.setVisibility(View.GONE);
            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
        }
    }

    public void refreshContent() {
        binding.rlLoader.setVisibility(View.VISIBLE);
        GetClassAPI();
    }

    private void updateUIWithClassData(ClassRes res) {
        binding.tvGreetings.setText(getLocalGreeting());
        setGreetingImage(binding.tvGreetings.getText().toString());

        if (res.getUserdetail() != null) {
            setProfileData(res.getUserdetail().getUserName(), res.getUserdetail().getUserImage());
        }

        setClassData(res.getData().getClass_());

        List<Classbanner> banners = res.getData().getClassbanner();
        if (banners != null && !banners.isEmpty()) {
            List<String> images = new ArrayList<>();
            for (Classbanner banner : banners) {
                images.add(banner.getImage());
            }
            binding.layoutBannerContainer.setVisibility(View.VISIBLE);
            SetSliderData(binding.imgViewPager, images, banners);
        } else {
            binding.layoutBannerContainer.setVisibility(View.GONE);
            binding.rvClass.setPadding(0, 0, 0, 0);
        }
    }

    public void SetSliderData(ViewPager viewPager, List<String> image, List<Classbanner> classbanner) {
        try {
            viewPager.setAdapter(new Sliding_adapter(context, viewPager, image, (position, type) -> {
                String url = classbanner.get(position).getUrl();
                if (isValid(url)) {
                    Intent httpIntent = new Intent(Intent.ACTION_VIEW);
                    httpIntent.setData(Uri.parse("http://" + url));
                    startActivity(httpIntent);
                }
            }));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setClassData(List<Clas> class_list) {
        if (!class_list.isEmpty()) {
            binding.rvClass.setVisibility(View.VISIBLE);
            ClassListAdapter adapter = new ClassListAdapter(context, class_list, (position, type) -> {
                Intent intent = new Intent(context, ChooseMediumActivity.class);
                intent.putExtra("title", class_list.get(position).getAddClass());
                intent.putExtra("class_id", class_list.get(position).getId().toString());
                startActivity(intent);
                requireActivity().overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            });
            binding.rvClass.setHasFixedSize(true);
            binding.rvClass.setLayoutManager(Constants.showInGrid ? new GridLayoutManager(context, 3) : new LinearLayoutManager(context));
            binding.rvClass.setAdapter(adapter);
        } else {
            binding.rvClass.setVisibility(View.GONE);
        }
    }

    public void GetClassAPI() {
        ClassParaRes classParaRes = new ClassParaRes();
        classParaRes.setDeviceId(mySharedPref.isLogin() ? "" : device_id);
        classParaRes.setFcmToken(mySharedPref.getFcmToken());

        jsonPlaceHolderApi.GetClassAPI("application/json", "application/json", classParaRes).enqueue(new Callback<ClassRes>() {
            @Override
            public void onResponse(Call<ClassRes> call, Response<ClassRes> response) {
                binding.rlLoader.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null && response.body().getStatus()) {
                    ClassRes classRes = response.body();

                    if (mySharedPref.isLogin() && Constants.isInternetConnected(context)) {
                        GetProfileAPI();
                    }

                    mySharedPref.setCachedClassData(classRes);
                    updateUIWithClassData(classRes);
                } else {
                    Toast.makeText(context, "Server error: " + (response.body() != null ? response.body().getMessage() : ""), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ClassRes> call, Throwable t) {
                binding.rlLoader.setVisibility(View.GONE);
                Log.e("API_FAILURE", "Error loading class: " + t.getMessage());
                Toast.makeText(context, "Something went wrong. Try again later.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setGreetingImage(String greeting) {
        int imageRes = R.drawable.evening;
        switch (greeting) {
            case "Good Morning": imageRes = R.drawable.morning; break;
            case "Good Night": imageRes = R.drawable.night; break;
            case "Good Afternoon": imageRes = R.drawable.noon; break;
        }
        binding.ivGreeting.setBackgroundResource(imageRes);
    }

    public void GetProfileAPI() {
        String token = mySharedPref.getSavedAccessToken();
        if (!isValid(token)) {
            Toast.makeText(context, "Invalid token", Toast.LENGTH_SHORT).show();
            return;
        }

        jsonPlaceHolderApi.GetProfileAPI("application/json", "application/json", "Bearer " + token).enqueue(new Callback<GetProfileRes>() {
            @Override
            public void onResponse(Call<GetProfileRes> call, Response<GetProfileRes> response) {
                if (response.isSuccessful() && response.body() != null) {
                    GetProfileRes res = response.body();
                    if (Boolean.TRUE.equals(res.getStatus())) {
                        setProfileData(res.getData());
                    } else {
                        Toast.makeText(context, res.getMessage(), Toast.LENGTH_SHORT).show();
                        if ("Your account has been blocked by admin.".equals(res.getMessage())) {
                            OpenLoginDialogClass.openBlockDeleteDialog(context, res.getMessage());
                        }
                    }
                } else {
                    Toast.makeText(context, "Server error", Toast.LENGTH_SHORT).show();
                    if (response.code() == 401) {
                        OpenLoginDialogClass.openBlockDeleteDialog(context, "User not found");
                    }
                }
            }

            @Override
            public void onFailure(Call<GetProfileRes> call, Throwable t) {
                Log.e("GetProfileAPI", "Failure: " + t.getMessage());
                Toast.makeText(context, "Failed to load profile", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setProfileData(Data profileData) {
        if (profileData == null || profileData.getUser() == null) return;
        setProfileData(profileData.getUser().getName(), profileData.getUser().getImage());
    }

    private void setProfileData(String name, String image) {
        binding.tvUserName.setText(isValid(name) ? name : "");
        if (isValid(image)) {
            loadUserImage(Allurls.IMAGEURL + image);
        } else {
            binding.cvUserProfile.setImageResource(R.drawable.ic_profile_image_default);
        }
    }

    private void loadUserImage(String url) {
        Picasso.get()
                .load(url)
                .placeholder(R.drawable.ic_profile_image_default)
                .error(R.drawable.ic_profile_image_default)
                .into(binding.cvUserProfile);
    }

    private boolean isValid(String s) {
        return s != null && !s.trim().isEmpty();
    }

    private String getLocalGreeting() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 12) return "Good Morning";
        else if (hour < 17) return "Good Afternoon";
        else if (hour < 21) return "Good Evening";
        else return "Good Night";
    }
}

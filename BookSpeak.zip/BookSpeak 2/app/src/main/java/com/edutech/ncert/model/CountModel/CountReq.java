
package com.edutech.ncert.model.CountModel;
import com.google.gson.annotations.SerializedName;

@SuppressWarnings("unused")
public class CountReq {

    @SerializedName("chapter_id")
    private Long mChapterId;

    public Long getChapterId() {
        return mChapterId;
    }

    public void setChapterId(Long chapterId) {
        mChapterId = chapterId;
    }

}

package com.edutech.ncert.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.arges.sepan.argmusicplayer.Callbacks.OnCompletedListener;
import com.arges.sepan.argmusicplayer.Models.ArgAudio;
import com.arges.sepan.argmusicplayer.Models.ArgNotificationOptions;
import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ActivityAudioBookNewBinding;
import com.edutech.ncert.model.ChapterModel.Datum;
import com.edutech.ncert.model.ChapterModel.OtherDetail;
import com.edutech.ncert.server.Allurls;
import com.edutech.ncert.server.MySharedPref;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.squareup.picasso.Picasso;

public class AudioBookNewActivity extends AppCompatActivity implements View.OnClickListener {
    Context context;
    private ActivityAudioBookNewBinding binding;
    Datum chapterDetail;
    OtherDetail otherDetail;
    TextView tvs25, tvs5, tvs75, tvNormal, tv25, tv5, tv75, tv2;
    String speedValue = "1X";
    private MySharedPref mySharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAudioBookNewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();
        onclicks();
    }

    public void init() {
        context = AudioBookNewActivity.this;
        mySharedPref = new MySharedPref(context);

        MobileAds.initialize(context, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        binding.adView.loadAd(adRequest);
        if(mySharedPref.getSavedBannerAddsStatus().equals("Yes")){
            binding.btnAdsShow.setVisibility(View.VISIBLE);
        }else{
            binding.btnAdsShow.setVisibility(View.GONE);
        }

        Intent intent = getIntent();
        if (intent != null) {
            chapterDetail = (Datum) intent.getSerializableExtra("ChapterDetail");
            otherDetail = (OtherDetail) intent.getSerializableExtra("otherDetail");

            setAudioBookDetail();
            String url = Allurls.IMAGEURL + chapterDetail.getAudio();
            ArgAudio audio = ArgAudio.createFromURL(otherDetail.getBookName(), otherDetail.getAuthorName(), url);
            binding.argmusicplayer.play(audio);
            binding.argmusicplayer.setAllButtonsImageResource(R.drawable.ic_play, R.drawable.ic_a_play11,
                    R.drawable.ic_a_previous, R.drawable.ic_a_next, 0, 0);
            binding.argmusicplayer.enableNotification(new ArgNotificationOptions(this)
                    .setProgressEnabled(true).setImageResoureId(R.drawable.ic_logo_blue).setEnabled(true));
             binding.argmusicplayer.setOnCompletedListener(new OnCompletedListener() {
                 @Override
                 public void onCompleted() {
                     binding.argmusicplayer.stop();
                     ArgAudio audio = ArgAudio.createFromURL(otherDetail.getBookName(), "Author name", url);
                     binding.argmusicplayer.loadSingleAudio(audio);
                 }
             });
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                binding.argmusicplayer.setAllowClickWhenDisabled(true);
            }
        }
    }

    private void setAudioBookDetail() {
        binding.tvChapter.setText(chapterDetail.getChapterName());
        binding.tvChapterName1.setText(chapterDetail.getChapterName());
        binding.tvAuthorName.setText(otherDetail.getAuthorName());
        if (!chapterDetail.getChapterImage().isEmpty()) {
            Picasso.get().load(Allurls.IMAGEURL + chapterDetail.getChapterImage()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(binding.ivChapterImage);
        }
        binding.tvBookName.setText(otherDetail.getBookName());
        binding.tvBookAuthor.setText(otherDetail.getBookName() + "," +  otherDetail.getAuthorName());

    }

    public void onclicks() {
        binding.llBack.setOnClickListener(this);
        binding.btnRead1.setOnClickListener(this);
        binding.ivRevert.setOnClickListener(this);
       /* binding.ivPrevious.setOnClickListener(this);
        binding.ivPlay.setOnClickListener(this);
        binding.ivPause.setOnClickListener(this);
        binding.ivNext.setOnClickListener(this);*/
        binding.ivFastforward.setOnClickListener(this);
        binding.llSpeed.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llBack:
                onBackPressed();
                break;

            case R.id.btnRead1:
                startActivity(new Intent(context, EbookActivity.class)
                        .putExtra("ChapterDetail", chapterDetail)
                        .putExtra("otherDetail", otherDetail)
                        .putExtra("FROM","AudioBookActivity"));

                break;

            case R.id.ivFastforward:
                binding.argmusicplayer.forward(30000, true);
                break;

            case R.id.ivRevert:
                binding.argmusicplayer.backward(30000, true);
                break;

            case R.id.llSpeed:
                showBottomSheetSpeedDialog();
                break;
        }
    }

    private void showBottomSheetSpeedDialog() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context, R.style.CustomBottomSheetDialog);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_speed_layout);

        tvs25 = bottomSheetDialog.findViewById(R.id.tvs25);
        tvs5 = bottomSheetDialog.findViewById(R.id.tvs5);
        tvs75 = bottomSheetDialog.findViewById(R.id.tvs75);
        tvNormal = bottomSheetDialog.findViewById(R.id.tvNormal);
        tv25 = bottomSheetDialog.findViewById(R.id.tv25);
        tv5 = bottomSheetDialog.findViewById(R.id.tv5);
        tv75 = bottomSheetDialog.findViewById(R.id.tv75);
        tv2 = bottomSheetDialog.findViewById(R.id.tv2);

        tvs25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "0.25X Speed";
                      //  binding.argmusicplayer.setPlaybackParams(new PlaybackParams().setSpeed(0.25f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
            }
        });

        tvs5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "0.5X Speed";
                      //  mediaPlayer.setPlaybackParams(new PlaybackParams().setSpeed(0.5f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }

            }
        });

        tvs75.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "0.75X Speed";
                      //  mediaPlayer.setPlaybackParams(new PlaybackParams().setSpeed(0.75f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
            }
        });

        tvNormal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "1X Speed";
                        //mediaPlayer.setPlaybackParams(new PlaybackParams().setSpeed(1f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
            }
        });

        tv25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "1.25X Speed";
                        //mediaPlayer.setPlaybackParams(new PlaybackParams().setSpeed(1.25f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
            }
        });

        tv5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "1.5X Speed";
                        //mediaPlayer.setPlaybackParams(new PlaybackParams().setSpeed(1.5f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
            }
        });
        tv75.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "1.75X Speed";
                        //mediaPlayer.setPlaybackParams(new PlaybackParams().setSpeed(1.75f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
            }
        });
        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "2X Speed";
                        //mediaPlayer.setPlaybackParams(new PlaybackParams().setSpeed(2f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
            }
        });
        bottomSheetDialog.show();
    }

}
package com.edutech.ncert.server;


import com.edutech.ncert.model.AddBookmark.AddBookmarkParaRes;
import com.edutech.ncert.model.AddBookmark.AddBookmarkRes;
import com.edutech.ncert.model.AudioApiModel.AudioParaRes;
import com.edutech.ncert.model.AudioApiModel.AudioRes;
import com.edutech.ncert.model.BookModel.BookParaRes;
import com.edutech.ncert.model.BookModel.BookRes;
import com.edutech.ncert.model.ChapterModel.ChapterParaRes;
import com.edutech.ncert.model.ChapterModel.ChapterRes;
import com.edutech.ncert.model.ClassModel.ClassParaRes;
import com.edutech.ncert.model.ClassModel.ClassRes;
import com.edutech.ncert.model.CountModel.CountReq;
import com.edutech.ncert.model.CountModel.CountResponse;
import com.edutech.ncert.model.GetProfile.GetProfileRes;
import com.edutech.ncert.model.LikeModel.LikeParaRes;
import com.edutech.ncert.model.LikeModel.LikeRes;
import com.edutech.ncert.model.Login.LoginParaRes;
import com.edutech.ncert.model.Login.LoginRes;
import com.edutech.ncert.model.LogoutModel.LogoutParaRes;
import com.edutech.ncert.model.MaintenanceModel.MaintenanceRes;
import com.edutech.ncert.model.MediumModel.MediumParaRes;
import com.edutech.ncert.model.MediumModel.MediumRes;
import com.edutech.ncert.model.NewsModel.NewsRes;
import com.edutech.ncert.model.PrivacyPolicy.PrivacyRes;
import com.edutech.ncert.model.RemoveBookmark.RemoveBookmarkParaRes;
import com.edutech.ncert.model.RemoveBookmark.RemoveBookmarkRes;
import com.edutech.ncert.model.ResponseStatusMsg;
import com.edutech.ncert.model.Signup.SignUpRes;
import com.edutech.ncert.model.Signup.SignupParaRes;
import com.edutech.ncert.model.SubjectModel.SubjectParaRes;
import com.edutech.ncert.model.SubjectModel.SubjectRes;
import com.edutech.ncert.model.Terms.TermsRes;
import com.edutech.ncert.model.UpdateProfile.UpdateProfileResponse;
import com.edutech.ncert.model.Verify.VerifyOtpRes;
import com.edutech.ncert.model.Verify.VeriyOtpParaRes;

import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;

public interface JsonPlaceHolderApi {
    @POST("register")
    Call<SignUpRes> signupAPI(@Header("Accept") String accept,
                              @Header("Content-Type") String content_type,
                              @Body SignupParaRes signupParaRes);

    @POST("login")
    Call<LoginRes> loginAPI(@Header("Accept") String accept,
                            @Header("Content-Type") String content_type,
                            @Body LoginParaRes loginParaRes);

    @POST("verify")
    Call<VerifyOtpRes> verifyOTPAPI(@Header("Accept") String accept,
                                    @Header("Content-Type") String content_type,
                                    @Body VeriyOtpParaRes veriyOtpParaRes);

    @POST("user/logout")
    Call<ResponseStatusMsg> LogoutAPI(@Header("Accept") String accept,
                                      @Header("Content-Type") String content_type,
                                      @Header("Authorization") String token , @Body LogoutParaRes looutParaRes);

    @POST("class")
    Call<ClassRes> GetClassAPI(@Header("Accept") String accept,
                               @Header("Content-Type") String content_type, @Body ClassParaRes classParaRes);

    @POST("medium")
    Call<MediumRes> GetMediumAPI(@Header("Accept") String accept,
                                 @Header("Content-Type") String content_type,
                                 @Body MediumParaRes mediumParaRes);

    @POST("subject")
    Call<SubjectRes> GetSubjectAPI(@Header("Accept") String accept,
                                   @Header("Content-Type") String content_type,
                                   @Body SubjectParaRes subjectParaRes);

    @POST("book")
    Call<BookRes> GetBookAPI(@Header("Accept") String accept,
                             @Header("Content-Type") String content_type,
                             @Body BookParaRes bookParaRes);

    @POST("chapter")
    Call<ChapterRes> GetChapterAPI(@Header("Accept") String accept,
                                   @Header("Content-Type") String content_type,
                                   @Body ChapterParaRes chapterParaRes);

    @POST("terms")
    Call<TermsRes> GetTermsAPI(@Header("Accept") String accept,
                               @Header("Content-Type") String content_type);

    @POST("privacy-policy")
    Call<PrivacyRes> GetPrivacyAPI(@Header("Accept") String accept,
                                   @Header("Content-Type") String content_type);

    @POST("user/like")
    Call<LikeRes> LikeAPI(@Header("Accept") String accept,
                          @Header("Content-Type") String content_type,
                          @Header("Authorization") String token,
                          @Body LikeParaRes likeParaRes);

    @Multipart
    @POST("user/update-profile")
    Call<UpdateProfileResponse> UpdateProfile(@Header("Accept") String accept,
                                              @Header("Authorization") String token,
                                              @PartMap Map<String, RequestBody> data,
                                              @Part MultipartBody.Part image);


    @POST("user/add-bookmark")
    Call<AddBookmarkRes> AddBookmarkAPI(@Header("Accept") String accept,
                                        @Header("Content-Type") String content_type,
                                        @Header("Authorization") String token,
                                        @Body AddBookmarkParaRes addBookmarkParaRes);

    @POST("user/remove-bookmark")
    Call<RemoveBookmarkRes> RemoveBookmarkAPI(@Header("Accept") String accept,
                                              @Header("Content-Type") String content_type,
                                              @Header("Authorization") String token,
                                              @Body RemoveBookmarkParaRes removeBookmarkParaRes);

    @POST("user/view-count")
    Call<CountResponse> ViewCountAPI(@Header("Accept") String accept,
                                          @Header("Content-Type") String content_type,
                                          @Header("Authorization") String token,
                                          @Body CountReq countReq);

    @POST("user/get-bookmark")
    Call<ChapterRes> GetBookmarkAPI(@Header("Accept") String accept,
                                    @Header("Content-Type") String content_type,
                                    @Header("Authorization") String token);

    @POST("user/get-profile")
    Call<GetProfileRes> GetProfileAPI(@Header("Accept") String accept,
                                      @Header("Content-Type") String content_type,
                                      @Header("Authorization") String token);

    @POST("news")
    Call<NewsRes> GetNewsAPI(@Header("Accept") String accept,
                             @Header("Content-Type") String content_type,
                             @Header("Authorization") String token);

    @POST("user/like-get")
    Call<BookRes> GetLikesAPI(@Header("Accept") String accept,
                              @Header("Content-Type") String content_type,
                              @Header("Authorization") String token);

    @POST("user/delete-profile")
    Call<ResponseStatusMsg> DeleteAccountAPI(@Header("Accept") String accept,
                                             @Header("Content-Type") String content_type,
                                             @Header("Authorization") String token);

    @POST("user/chapter-audio")
    Call<AudioRes> AudioApi(@Header("Accept") String accept,
                            @Header("Content-Type") String content_type,
                            @Header("Authorization") String token,
                            @Body AudioParaRes audioParaRes);

    @POST("maintenance")
    Call<MaintenanceRes> MaintenanceAPI(@Header("Accept") String accept,
                                        @Header("Content-Type") String content_type,
                                        @Header("Authorization") String token);

}

package com.edutech.ncert.model.AudioApiModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AudioParaRes {

    @SerializedName("chapter_id")
    @Expose
    private String chapterId;

    public String getChapterId() {
        return chapterId;
    }

    public void setChapterId(String chapterId) {
        this.chapterId = chapterId;
    }

}

package com.edutech.ncert.activity;

import static androidx.core.content.FileProvider.getUriForFile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.downloader.Error;
import com.downloader.OnDownloadListener;
import com.downloader.OnProgressListener;
import com.downloader.OnStartOrResumeListener;
import com.downloader.PRDownloader;
import com.downloader.PRDownloaderConfig;
import com.downloader.Progress;
import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ActivityEbookBinding;
import com.edutech.ncert.model.ChapterModel.Datum;
import com.edutech.ncert.model.ChapterModel.OtherDetail;
import com.edutech.ncert.server.Allurls;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.AdManager;
import com.github.barteksc.pdfviewer.listener.OnErrorListener;
import com.github.barteksc.pdfviewer.listener.OnPageChangeListener;
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle;
import com.google.android.gms.ads.AdRequest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class EbookActivity extends AppCompatActivity implements View.OnClickListener, OnPageChangeListener {

    String TAG="EBOOKTAG";
    Context context;
    Bitmap coverImageBitmap;
    final  int APP_STORAGE_ACCESS_REQUEST_CODE = 501; // Any value
    final  int STORAGE_PERMISSION_CODE = 502; // Any value

    private ActivityEbookBinding binding;
    LayoutInflater mInflater;
    private final PopupWindow mDropdown = null;
    Datum chapterDetail;
    OtherDetail otherDetail;
    String positionChapter;
    List<Datum> chapterList = new ArrayList<>();
    InputStream inputStream = null;
    //   boolean nightMode = false;
    MySharedPref mySharedPref;
    File file;
    String pdfName = "";

    boolean nightMode = false;
    int pageNumber = 0;
    String url = "";
    String downloadDir = "";
    String fileName=null;
    AdManager adManager;

    private final Handler interstitialHandler = new Handler();
    private Runnable runnable;
    private final long delayMillis = 2 * 60 * 1000; // 2 minutes in milliseconds
    private boolean stayedLongEnough = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEbookBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        StrictMode.ThreadPolicy policy = new
                StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        // Start tracking time
        runnable = new Runnable() {
            @Override
            public void run() {
                stayedLongEnough = true;
            }
        };

        interstitialHandler.postDelayed(runnable, delayMillis);
        init();
        onclicks();
    }

    public void init() {
        context = EbookActivity.this;

        mySharedPref = new MySharedPref(context);
        /*Log.d("ADSTAG", "init: "+mySharedPref.getSavedInterstitialAddsStatus());
        if(mySharedPref.getSavedInterstitialAddsStatus().equals("Yes")){
//            AdManager.getInstance().showInterstitialAd();
            AdManager.getInstance().loadInterstitialAd(this);
        }*/

        if(mySharedPref.getSavedBannerAddsStatus().equals("Yes")){
            AdRequest adRequest = new AdRequest.Builder().build();
            binding.adView.loadAd(adRequest);
            binding.adView.setVisibility(View.VISIBLE);
        }else{
            binding.adView.setVisibility(View.GONE);
        }

        Intent intent = getIntent();
        if (intent != null) {

            chapterDetail = (Datum) intent.getSerializableExtra("ChapterDetail");
            otherDetail = (OtherDetail) intent.getSerializableExtra("otherDetail");
            chapterList = (List<Datum>) intent.getSerializableExtra("chapterList");
            positionChapter = intent.getStringExtra("positionChapter");
            Log.d(TAG, "init: "+chapterList.size()+" "+positionChapter);
            Log.d("AUDIOTAG", "init: audio="+chapterDetail.getAudio());

            if (chapterDetail.getAudio().isEmpty() && chapterDetail.getUrl().isEmpty()){
                binding.llPlayPdf.setVisibility(View.GONE);
            }

//            coverImageBitmap=intent.getStringExtra("",)
            if(!chapterDetail.getPdf().isEmpty()){
                url = Allurls.IMAGEURL + chapterDetail.getPdf();
            }else if(!chapterDetail.getPdfUrl().isEmpty()){
                url = chapterDetail.getPdfUrl();
            }

//            downloadDir=getApplicationContext().getApplicationInfo().dataDir;
            downloadDir=getFilesDir().getAbsolutePath();
            Log.d(TAG, "init: "+downloadDir);
            fileName=chapterDetail.getDateTime();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                fileName=Base64.getEncoder().encodeToString(fileName.getBytes()) + ".pdf";
            }else {
                fileName=fileName + ".pdf";
            }

//            fileName=chapterDetail.getId().toString()+ ".pdf";
            Log.d(TAG, "init: "+fileName);

            file = new File(downloadDir, fileName);
            if(!file.exists()){
                if(mySharedPref.getSavedInterstitialAddsStatus().equals("Yes")){
                    if (!intent.getStringExtra("FROM").equals("AudioBookActivity")){
                        AdManager.getInstance().loadInterstitial(this);

                    }
                }
                Log.d("EBOOKTAG", "init: book not available"+file.getAbsolutePath());
                Download_PDF_Internal_Storage(url);
            }else{
                Log.d("EBOOKTAG", "init: book available "+url);
                AdManager.getInstance().loadInterstitialAd(this);
                openPdf();
            }
        }
    }
    //    Biology Study Material-2024-01-19T15:53:12.000000Z
    private void Download_PDF_Internal_Storage(String url) {
        PRDownloaderConfig config = PRDownloaderConfig.newBuilder()
                .setReadTimeout(30_000)
                .setConnectTimeout(30_000)
                .build();
        PRDownloader.initialize(getApplicationContext(), config);
        ProgressDialog dialog=new ProgressDialog(this);
        dialog.setTitle("Downloading Pdf");
        dialog.setCancelable(false);
        dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        dialog.show();
        Log.d("EBOOKTAG", "Download_PDF_Internal_Storage: "+url);

        PRDownloader.download(url,downloadDir,fileName)
                .build()
                .setOnStartOrResumeListener(new OnStartOrResumeListener() {
                    @Override
                    public void onStartOrResume() {
                        Log.d("EBOOKTAG", "onStartOrResume: ");
                    }
                })
                .setOnProgressListener(new OnProgressListener() {
                    @Override
                    public void onProgress(Progress progress) {
                        Integer progressPercent = Integer.parseInt(String.valueOf(progress.currentBytes * 100 / progress.totalBytes));
                        dialog.setProgress(progressPercent);

                                        /*DecimalFormat df = new DecimalFormat("#.#");
                                        Log.d(TAG, "onProgress: File Size:"+df.format((double)progress.totalBytes/1000000)+" mb");
                                        dialog.setMessage("File Size: "+df.format((double)progress.totalBytes/1000000)+" mb\n"+"Progress ..."+progressPercent+"%");
                                        dialog.setMessage("File Size: "+df.format((double)progress.totalBytes/1000000)+" mb\nProgress ..."+progressPercent+"%");
                                        */
                    }
                })
                .start(new OnDownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        dialog.dismiss();
                        AdManager.getInstance().showInterstitialAd(EbookActivity.this);
                        file = new File(downloadDir, fileName);
                        openPdf();
                    }

                    @Override
                    public void onError(Error error) {
                        dialog.dismiss();
                        Toast.makeText(context, "download error", Toast.LENGTH_SHORT).show();
                        Log.d("EBOOKTAG", "onError: "+error.getServerErrorMessage());
                    }
                });
    }

    private void openPdf() {
        Log.d("EBOOKTAG", "openPdf: "+ file.getAbsolutePath());
        binding.pdfView.fromFile(file)
                .nightMode(nightMode)
                .enableDoubletap(true)
                .defaultPage(0)
                .scrollHandle(new DefaultScrollHandle(this))
                .onPageChange(this)
                .spacing(10)
                .onError(new OnErrorListener() {
                    @Override
                    public void onError(Throwable t) {
                        Log.d("EBOOKTAG", "onError: "+t.getMessage());
                    }
                })
                .load();

    }


    public void onclicks() {
        binding.llBack.setOnClickListener(this);
        binding.llDark.setOnClickListener(this);
        binding.llLight.setOnClickListener(this);
        binding.llshare.setOnClickListener(this);
        binding.llSendPdf.setOnClickListener(this);
        binding.llPlayPdf.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llBack:
                onBackPressed();
                if (stayedLongEnough) {
                    AdManager.getInstance().loadInterstitialAd(this);
                    onBackPressed();
                } else {
                    onBackPressed(); // Go back if the condition is not met
                }
                break;
            case R.id.llPlayPdf:
                if(mySharedPref.getSavedRewardedAddsStatus().equals("Yes")){
                    showunlockDialog();
                }else {
                    Log.d("POSTAG", "onClick:Ebook POS" + positionChapter);
                    startActivity(new Intent(context, AudiobookActivity.class)
                            .putExtra("ChapterDetail", chapterDetail)
                            .putExtra("otherDetail", otherDetail)
                            .putExtra("chapterList", (Serializable) chapterList)
                            .putExtra("positionChapter", positionChapter));
                    finish();
                }
                break;
            case R.id.llDark:
                nightMode = true;
                binding.llDark.setVisibility(View.GONE);
                binding.llLight.setVisibility(View.VISIBLE);
                openPdf();
                // new RetrivePDFfromUrl().execute(Allurls.IMAGEURL + chapterDetail.getPdf());
                break;

            case R.id.llLight:
                nightMode = false;
                binding.llDark.setVisibility(View.VISIBLE);
                binding.llLight.setVisibility(View.GONE);
                openPdf();
                //   new RetrivePDFfromUrl().execute(Allurls.IMAGEURL + chapterDetail.getPdf());
                break;

            case R.id.llshare:
//               shareApp();
//                sharePdf();
                shareApp();
                //   new RetrivePDFfromUrl().execute(Allurls.IMAGEURL + chapterDetail.getPdf());
                break;
            case R.id.llSendPdf:
                sendPdfToWhatsapp();
                break;
        }
    }

    @Override
    public void onPageChanged(int page, int pageCount) {
        pageNumber = page;
        binding.tvPageNo.setText(String.format("%s %s / %s","", page+1,pageCount));
    }

    private boolean isPlayStoreInstalled() {
        PackageManager packageManager = getPackageManager();
        Intent playStoreIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.gms"));
        List<ResolveInfo> list = packageManager.queryIntentActivities(playStoreIntent, PackageManager.MATCH_DEFAULT_ONLY);
        return list.size() > 0;
    }


    public  Uri getUriForFileProvider(Context context, File file) {
        return FileProvider.getUriForFile(context, "com.edutech.ncert.provider", file);
    }
    private void sendPdfToWhatsapp(){

        if (file.exists()) {
            final Uri contentUri = getUriForFileProvider(this, file);

            Intent shareIntent = new Intent();
            shareIntent.setAction(Intent.ACTION_SEND);
            shareIntent.setType("application/pdf");

            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            shareIntent.setDataAndType(contentUri, getContentResolver().getType(contentUri));
            shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
//            shareIntent.putExtra(Intent.EXTRA_TEXT, strExtra);
            shareIntent.setPackage("com.whatsapp");


            startActivity(Intent.createChooser(shareIntent, "Share Via"));
        }else {
            Log.d(TAG, "sharePdf: file not exists!");
        }


    }
    private void shareApp() {

        binding.llshare.requestFocus();
        Bitmap bitmap = Bitmap.createBitmap(binding.pdfView.getWidth(), binding.pdfView.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        // Set the scale to fit the entire page onto the canvas
        float scale = binding.pdfView.getWidth() / binding.pdfView.toCurrentScale(binding.pdfView.getWidth());
        canvas.scale(scale, scale);

        // Render the PDF page onto the canvas
        binding.pdfView.draw(canvas);

        shareImage(bitmap);
    }

    public String shareImage(Bitmap bitmap) {
        // save bitmap to cache directory
        try {
            File cachePath = new File(getCacheDir(), "images");
            cachePath.mkdirs(); // don't forget to make the directory
            FileOutputStream stream = new FileOutputStream(cachePath + "/image.png");
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            stream.close();

        } catch (Exception e) {
            Log.d(TAG, "shareImage: "+e.getMessage());
        }
        String strExtra="Hi, I have shared "+chapterDetail.getChapterName()+"\n\nYou can download more from the app.\nClick the link to download\nhttps://play.google.com/store/apps/details?id=com.edutech.ncert";
        File imagePath = new File(getCacheDir(), "images");
        File newFile = new File(imagePath, "image.png");
        final Uri contentUri = getUriForFileProvider(this,newFile);
        if (contentUri != null) {
            Intent shareIntent = new Intent();
            shareIntent.setAction(Intent.ACTION_SEND);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            shareIntent.setDataAndType(contentUri, getContentResolver().getType(contentUri));
            shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
            shareIntent.putExtra(Intent.EXTRA_TEXT, strExtra);
            shareIntent.setType("image/png");
            startActivity(Intent.createChooser(shareIntent, "Share Via"));
        }
        return newFile.getAbsolutePath();
    }
    public void showunlockDialog() {
        boolean isCLICK;
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_unlock_audio);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.findViewById(R.id.btnWatch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();
                startActivity(new Intent(context, AudiobookActivity.class)
                        .putExtra("ChapterDetail", chapterDetail)
                        .putExtra("otherDetail", otherDetail)
                        .putExtra("chapterList", (Serializable) chapterList)
                        .putExtra("positionChapter", positionChapter));
                finish();
            }
        });
        dialog.findViewById(R.id.btnSkipPLay).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();
            }
        });

        dialog.show();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        interstitialHandler.removeCallbacks(runnable);
    }
}

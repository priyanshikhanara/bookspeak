
package com.edutech.ncert.model.Signup;

import com.google.gson.annotations.SerializedName;

@SuppressWarnings("unused")
public class Data {

    @SerializedName("access_token")
    private String mAccessToken;
    @SerializedName("user_id")
    private Object mUserId;

    public String getAccessToken() {
        return mAccessToken;
    }

    public void setAccessToken(String accessToken) {
        mAccessToken = accessToken;
    }

    public Object getUserId() {
        return mUserId;
    }

    public void setUserId(Object userId) {
        mUserId = userId;
    }

}

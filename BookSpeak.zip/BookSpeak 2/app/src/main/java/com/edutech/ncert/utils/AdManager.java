package com.edutech.ncert.utils;

import android.app.Activity;
import android.util.Log;

import androidx.annotation.NonNull;

import com.edutech.ncert.R;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class AdManager {
    String TAG="ADSTAG";
    private static AdManager instance;
    private InterstitialAd mInterstitialAd;
    public RewardedAd rewardedAd;
    private boolean isRewardedAdLoaded;
    // Private constructor to enforce singleton pattern
    private AdManager() {
    }

    // Method to get the singleton instance of AdManager
    public static synchronized AdManager getInstance() {
        if (instance == null) {
            instance = new AdManager();
        }
        return instance;
    }

    // Initialize the interstitial ad
//    public void initInterstitialAd(Context context, String adUnitId) {
//        if (interstitialAd == null) {
////            interstitialAd = new InterstitialAd(context);
////            interstitialAd.setAdUnitId(adUnitId);
//            MobileAds.initialize(context, new OnInitializationCompleteListener() {
//                @Override
//                public void onInitializationComplete(InitializationStatus initializationStatus) {}
//            });
//            AdRequest adRequest = new AdRequest.Builder().build();
//
//            InterstitialAd.load(this,"ca-app-pub-3940256099942544/1033173712", adRequest,
//                    new InterstitialAdLoadCallback() {
//                        @Override
//                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
//                            // The mInterstitialAd reference will be null until
//                            // an ad is loaded.
////                            mInterstitialAd = interstitialAd;
//                            Log.i(TAG, "onAdLoaded");
//                        }
//
//                        @Override
//                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
//                            // Handle the error
//                            Log.d(TAG, loadAdError.toString());
//                            mInterstitialAd = null;
//                        }
//                    });
//        }
//    }

    // Load the interstitial ad
    public void loadInterstitialAd(Activity context) {
        Log.d(TAG, "loadInterstitialAd: loading interstitial");

//            AdRequest adRequest = new AdRequest.Builder().build();
//            interstitialAd.loadAd(adRequest);

//            interstitialAd = new InterstitialAd(context);
//            interstitialAd.setAdUnitId(adUnitId);
                MobileAds.initialize(context, new OnInitializationCompleteListener() {
                    @Override
                    public void onInitializationComplete(InitializationStatus initializationStatus) {}
                });
                AdRequest adRequest = new AdRequest.Builder().build();

                InterstitialAd.load(context,context.getString(R.string.admob_interstitial_id), adRequest,
                        new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                // The mInterstitialAd reference will be null until
                                // an ad is loaded.
                                mInterstitialAd = interstitialAd;
                                Log.d(TAG, "onAdLoaded: ");
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                // Handle the error
                                Log.d(TAG, loadAdError.toString());
                                mInterstitialAd = null;
                            }
                        });

        if (mInterstitialAd != null) {
            mInterstitialAd.show(context);
        } else {
            Log.d(TAG, "The interstitial ad wasn't ready yet.");
//            Toast.makeText(context, "The interstitial ad wasn't ready yet.", Toast.LENGTH_SHORT).show();
//            loadInterstitialAd(context);
        }
    }
    public void loadInterstitial(Activity context) {

//            AdRequest adRequest = new AdRequest.Builder().build();
//            interstitialAd.loadAd(adRequest);

//            interstitialAd = new InterstitialAd(context);
//            interstitialAd.setAdUnitId(adUnitId);
//        if (mInterstitialAd == null) {
            MobileAds.initialize(context, new OnInitializationCompleteListener() {
                @Override
                public void onInitializationComplete(InitializationStatus initializationStatus) {}
            });
            AdRequest adRequest = new AdRequest.Builder().build();

            InterstitialAd.load(context,context.getString(R.string.admob_interstitial_id), adRequest,
                    new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            // The mInterstitialAd reference will be null until
                            // an ad is loaded.
                            mInterstitialAd = interstitialAd;
                            Log.d(TAG, "inter onAdLoaded: ");
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            // Handle the error
                            Log.d(TAG, "inter "+ loadAdError);
                            mInterstitialAd = null;
                        }
                    });

        }
//    }

    // Show the interstitial ad
    public void showInterstitialAd(Activity context) {
        if (mInterstitialAd != null ) {
            mInterstitialAd.show(context);
            mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    super.onAdDismissedFullScreenContent();
                    loadInterstitial(context);
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    super.onAdFailedToShowFullScreenContent(adError);
                    loadInterstitial(context);
                }
            });
        }
    }
    public void showInterstitial(Activity context, Runnable onAdClosed) {
        if (mInterstitialAd != null) {
            mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    mInterstitialAd = null;
                    loadInterstitial(context); // preload next
                    if (onAdClosed != null) onAdClosed.run();
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    mInterstitialAd = null;
                    loadInterstitial(context);
                    if (onAdClosed != null) onAdClosed.run();
                }

                @Override
                public void onAdShowedFullScreenContent() {
                    // Optional: log if needed
                }
            });

            mInterstitialAd.show(context);
        } else {
            // No ad ready — continue immediately
            if (onAdClosed != null) onAdClosed.run();
        }
    }



    //rewarded ads

    // Initialize the rewarded ad
//    public void initRewardedAd(Context context, String adUnitId) {
//        if (rewardedAd == null) {
//            rewardedAd = new RewardedAd(context, adUnitId);
//            loadRewardedAd(context);
//        }
//    }

    public void loadRewardedAd(Activity context) {
         AdRequest adRequest = new AdRequest.Builder().build();
        RewardedAd.load(context, context.getString(R.string.admob_rewarded_id),
                adRequest, new RewardedAdLoadCallback() {
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        // Handle the error.
                        Log.d(TAG, loadAdError.toString());
                        rewardedAd = null;
                    }

                    @Override
                    public void onAdLoaded(@NonNull RewardedAd ad) {
                        rewardedAd = ad;
                        Log.d(TAG, "Ad was loaded.");
                    }
                });
//        if (rewardedAd != null) {
//            rewardedAd.show(context, new OnUserEarnedRewardListener() {
//                @Override
//                public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
//                    // Handle the reward.
//                    Log.d(TAG, "The user earned the reward.");
//                    int rewardAmount = rewardItem.getAmount();
//                    String rewardType = rewardItem.getType();
//                }
//            });
//        } else {
//            Log.d(TAG, "The rewarded ad wasn't ready yet.");
//        }

    }

    public void showRewardedAd(Activity activity, OnUserEarnedRewardListener rewardedAdCallback, FullScreenContentCallback fullScreenContentCallback) {
        if (rewardedAd != null) {
            rewardedAd.show(activity, rewardedAdCallback);
            // Load the next rewarded ad after showing the current one
//            loadRewardedAd(activity);
            rewardedAd.setFullScreenContentCallback(fullScreenContentCallback);
        } else {
            // Rewarded ad is not loaded or null. Handle this situation accordingly.
        }
    }
}


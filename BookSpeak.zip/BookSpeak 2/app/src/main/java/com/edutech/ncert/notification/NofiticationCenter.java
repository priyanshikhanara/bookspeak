package com.edutech.ncert.notification;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

import com.edutech.ncert.utils.AdManager;


public class NofiticationCenter extends Application {
    public static final String channel_1_ID="channel1";




    @Override
    public void onCreate() {
        super.onCreate();
        createNofitication();
        // Initialize the AdManager and set the Interstitial Ad Unit ID
        AdManager adManager = AdManager.getInstance();

//        adManager.initRewardedAd(this, getString(R.string.admob_rewarded_id));
//        adManager.initInterstitialAd(this, getString(R.string.admob_interstitial_id));
     }

   private void createNofitication(){
    if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
        NotificationChannel ch1=new NotificationChannel(channel_1_ID,"Song", NotificationManager.IMPORTANCE_LOW);
        ch1.setDescription("HEY");
        NotificationManager manager=getSystemService(NotificationManager.class);
        manager.createNotificationChannel(ch1);
    }

   }




}

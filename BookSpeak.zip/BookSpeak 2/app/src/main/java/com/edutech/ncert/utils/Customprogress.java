package com.edutech.ncert.utils;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;
import android.widget.ProgressBar;

import com.edutech.ncert.R;

public class Customprogress {

    private static Dialog progressDialog = null;

    public static void showPopupProgressSpinner(Context context, Boolean isShowing) {
        if (isShowing) {
            if (progressDialog == null || !progressDialog.isShowing()) {
                progressDialog = new Dialog(context);
                progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                progressDialog.setContentView(R.layout.popup_progressbar);
                progressDialog.setCancelable(false);
                if (progressDialog.getWindow() != null) {
                    progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                }
                progressDialog.show();
            }
        } else {
            if (progressDialog != null && progressDialog.isShowing()) {
                progressDialog.dismiss();
                progressDialog = null; // free memory
            }
        }
    }
}


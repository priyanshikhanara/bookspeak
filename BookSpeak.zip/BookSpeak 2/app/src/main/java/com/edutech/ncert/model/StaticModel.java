package com.edutech.ncert.model;

import java.io.Serializable;

public class StaticModel implements Serializable {
    String title;

    public StaticModel(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}

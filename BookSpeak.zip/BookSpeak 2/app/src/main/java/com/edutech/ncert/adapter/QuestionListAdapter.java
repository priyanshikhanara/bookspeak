package com.edutech.ncert.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.edutech.ncert.R;
import com.edutech.ncert.model.QuestionModel;

import java.util.List;

public class QuestionListAdapter extends RecyclerView.Adapter<QuestionListAdapter.QuestionViewHolder> {

    private final Context context;
    private final List<QuestionModel> questionList;

    public QuestionListAdapter(Context context, List<QuestionModel> questionList) {
        this.context = context;
        this.questionList = questionList;
    }

    @NonNull
    @Override
    public QuestionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_my_question, parent, false);
        return new QuestionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull QuestionViewHolder holder, int position) {
        QuestionModel model = questionList.get(position);
        holder.title.setText(model.getTitle());
        holder.details.setText(model.getDetails());
        holder.status.setText("Status: " + model.getStatus());
        holder.reply.setText("Reply: " + (model.getAdmin_reply().isEmpty() ? "Not yet" : model.getAdmin_reply()));
    }

    @Override
    public int getItemCount() {
        return questionList.size();
    }

    static class QuestionViewHolder extends RecyclerView.ViewHolder {
        TextView title, details, status, reply;

        public QuestionViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tvTitle);
            details = itemView.findViewById(R.id.tvDetails);
            status = itemView.findViewById(R.id.tvStatus);
            reply = itemView.findViewById(R.id.tvReply);
        }
    }
}

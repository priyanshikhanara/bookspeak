package com.edutech.ncert.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ActivityChapterDetailBinding;
import com.edutech.ncert.model.AddBookmark.AddBookmarkParaRes;
import com.edutech.ncert.model.AddBookmark.AddBookmarkRes;
import com.edutech.ncert.model.ChapterModel.Datum;
import com.edutech.ncert.model.ChapterModel.OtherDetail;
import com.edutech.ncert.model.CountModel.CountReq;
import com.edutech.ncert.model.CountModel.CountResponse;
import com.edutech.ncert.model.RemoveBookmark.RemoveBookmarkParaRes;
import com.edutech.ncert.model.RemoveBookmark.RemoveBookmarkRes;
import com.edutech.ncert.server.Allurls;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.AdManager;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;
import com.edutech.ncert.utils.DrawableUtils;
import com.edutech.ncert.utils.OpenLoginDialogClass;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.squareup.picasso.Picasso;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChapterDetailActivity extends AppCompatActivity implements View.OnClickListener {
    Context context;
    private ActivityChapterDetailBinding binding;
    Datum chapterDetail;
    OtherDetail otherDetail;
    String positionChapter;
    List<Datum> chapterList = new ArrayList<>();
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private MySharedPref mySharedPref;
    LinearLayout btnCancel, btnRemove, llAudiobook, llEbook, llAudiobookEbook;
    TextView tvChapter, tvSubjectName,bottomtvAudioDuration,bottomtvPdfPages;
    ImageView ivChapterImage;
    public static String newPosition;
    boolean isClick;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChapterDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();
        onclicks();
    }

    public void init() {
        context = ChapterDetailActivity.this;
        jsonPlaceHolderApi = ApiUtils.getAPIService();
        mySharedPref = new MySharedPref(context);
//        AdManager.getInstance().loadRewardedAd();
        /*if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions((AppCompatActivity) context, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        } else {

        }*/

        MobileAds.initialize(context, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        binding.adView.loadAd(adRequest);
        if(mySharedPref.getSavedRewardedAddsStatus().equals("Yes")){
            AdManager.getInstance().loadRewardedAd(ChapterDetailActivity.this);
        }
        if(mySharedPref.getSavedBannerAddsStatus().equals("Yes")){
            binding.btnAdsShow.setVisibility(View.VISIBLE);
//            loadInterstitialAds();
        }else{
            binding.btnAdsShow.setVisibility(View.GONE);
        }

        if(mySharedPref.getSavedInterstitialAddsStatus().equals("Yes")){
//            AdManager.getInstance().showInterstitialAd();
            AdManager.getInstance().loadInterstitial(ChapterDetailActivity.this);
        }



        Intent intent = getIntent();
        if (intent != null) {
            chapterDetail = (Datum) intent.getSerializableExtra("ChapterDetail");
            otherDetail = (OtherDetail) intent.getSerializableExtra("otherDetail");
            chapterList = (List<Datum>) intent.getSerializableExtra("chapterList");
            positionChapter = intent.getStringExtra("positionChapter");

            AddCountAPI();
            setChapterDetail();
        }
    }

//    void  loadInterstitialAds(){
//        Customprogress.showPopupProgressSpinner(context,true);
//
//        AdRequest adRequest = new AdRequest.Builder().build();
//
//        InterstitialAd interstitial = new InterstitialAd(context);
//
//        // Set the Ad Unit ID
//        interstitial.setAdUnitId(getString(R.string.admob_interstitial_id));
//
//        // Load the Interstitial Ad
//        interstitial.loadAd(adRequest);
//
//        // Prepare an Interstitial Ad Listener
//        interstitial.setAdListener(new AdListener() {
//            @Override
//            public void onAdLoaded() {
//                // Call displayInterstitial() function when the Ad loads
//                if (interstitial.isLoaded()) {
//                    if(!isClick){
//                        interstitial.show();
//
//                    }
//
//                }
//                Customprogress.showPopupProgressSpinner(context,false);
//            }
//        });
//
//    }


    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        System.out.println("Request Code >>>>>>>" + requestCode);
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {
                    // Toast.makeText((AppCompatActivity) context, "Permission denied", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    public Bitmap fastblur(Bitmap sentBitmap, float scale, int radius) {

        int width = Math.round(sentBitmap.getWidth() * scale);
        int height = Math.round(sentBitmap.getHeight() * scale);
        sentBitmap = Bitmap.createScaledBitmap(sentBitmap, width, height, false);

        Bitmap bitmap = sentBitmap.copy(sentBitmap.getConfig(), true);

        if (radius < 1) {
            return (null);
        }

        int w = bitmap.getWidth();
        int h = bitmap.getHeight();

        int[] pix = new int[w * h];
        Log.e("pix", w + " " + h + " " + pix.length);
        bitmap.getPixels(pix, 0, w, 0, 0, w, h);

        int wm = w - 1;
        int hm = h - 1;
        int wh = w * h;
        int div = radius + radius + 1;

        int r[] = new int[wh];
        int g[] = new int[wh];
        int b[] = new int[wh];
        int rsum, gsum, bsum, x, y, i, p, yp, yi, yw;
        int vmin[] = new int[Math.max(w, h)];

        int divsum = (div + 1) >> 1;
        divsum *= divsum;
        int dv[] = new int[256 * divsum];
        for (i = 0; i < 256 * divsum; i++) {
            dv[i] = (i / divsum);
        }

        yw = yi = 0;

        int[][] stack = new int[div][3];
        int stackpointer;
        int stackstart;
        int[] sir;
        int rbs;
        int r1 = radius + 1;
        int routsum, goutsum, boutsum;
        int rinsum, ginsum, binsum;

        for (y = 0; y < h; y++) {
            rinsum = ginsum = binsum = routsum = goutsum = boutsum = rsum = gsum = bsum = 0;
            for (i = -radius; i <= radius; i++) {
                p = pix[yi + Math.min(wm, Math.max(i, 0))];
                sir = stack[i + radius];
                sir[0] = (p & 0xff0000) >> 16;
                sir[1] = (p & 0x00ff00) >> 8;
                sir[2] = (p & 0x0000ff);
                rbs = r1 - Math.abs(i);
                rsum += sir[0] * rbs;
                gsum += sir[1] * rbs;
                bsum += sir[2] * rbs;
                if (i > 0) {
                    rinsum += sir[0];
                    ginsum += sir[1];
                    binsum += sir[2];
                } else {
                    routsum += sir[0];
                    goutsum += sir[1];
                    boutsum += sir[2];
                }
            }
            stackpointer = radius;

            for (x = 0; x < w; x++) {

                r[yi] = dv[rsum];
                g[yi] = dv[gsum];
                b[yi] = dv[bsum];

                rsum -= routsum;
                gsum -= goutsum;
                bsum -= boutsum;

                stackstart = stackpointer - radius + div;
                sir = stack[stackstart % div];

                routsum -= sir[0];
                goutsum -= sir[1];
                boutsum -= sir[2];

                if (y == 0) {
                    vmin[x] = Math.min(x + radius + 1, wm);
                }
                p = pix[yw + vmin[x]];

                sir[0] = (p & 0xff0000) >> 16;
                sir[1] = (p & 0x00ff00) >> 8;
                sir[2] = (p & 0x0000ff);

                rinsum += sir[0];
                ginsum += sir[1];
                binsum += sir[2];

                rsum += rinsum;
                gsum += ginsum;
                bsum += binsum;

                stackpointer = (stackpointer + 1) % div;
                sir = stack[(stackpointer) % div];

                routsum += sir[0];
                goutsum += sir[1];
                boutsum += sir[2];

                rinsum -= sir[0];
                ginsum -= sir[1];
                binsum -= sir[2];

                yi++;
            }
            yw += w;
        }
        for (x = 0; x < w; x++) {
            rinsum = ginsum = binsum = routsum = goutsum = boutsum = rsum = gsum = bsum = 0;
            yp = -radius * w;
            for (i = -radius; i <= radius; i++) {
                yi = Math.max(0, yp) + x;

                sir = stack[i + radius];

                sir[0] = r[yi];
                sir[1] = g[yi];
                sir[2] = b[yi];

                rbs = r1 - Math.abs(i);

                rsum += r[yi] * rbs;
                gsum += g[yi] * rbs;
                bsum += b[yi] * rbs;

                if (i > 0) {
                    rinsum += sir[0];
                    ginsum += sir[1];
                    binsum += sir[2];
                } else {
                    routsum += sir[0];
                    goutsum += sir[1];
                    boutsum += sir[2];
                }

                if (i < hm) {
                    yp += w;
                }
            }
            yi = x;
            stackpointer = radius;
            for (y = 0; y < h; y++) {
                // Preserve alpha channel: ( 0xff000000 & pix[yi] )
                pix[yi] = ( 0xff000000 & pix[yi] ) | ( dv[rsum] << 16 ) | ( dv[gsum] << 8 ) | dv[bsum];

                rsum -= routsum;
                gsum -= goutsum;
                bsum -= boutsum;

                stackstart = stackpointer - radius + div;
                sir = stack[stackstart % div];

                routsum -= sir[0];
                goutsum -= sir[1];
                boutsum -= sir[2];

                if (x == 0) {
                    vmin[y] = Math.min(y + r1, hm) * w;
                }
                p = x + vmin[y];

                sir[0] = r[p];
                sir[1] = g[p];
                sir[2] = b[p];

                rinsum += sir[0];
                ginsum += sir[1];
                binsum += sir[2];

                rsum += rinsum;
                gsum += ginsum;
                bsum += binsum;

                stackpointer = (stackpointer + 1) % div;
                sir = stack[stackpointer];

                routsum += sir[0];
                goutsum += sir[1];
                boutsum += sir[2];

                rinsum -= sir[0];
                ginsum -= sir[1];
                binsum -= sir[2];

                yi += w;
            }
        }

        Log.e("pix", w + " " + h + " " + pix.length);
        bitmap.setPixels(pix, 0, w, 0, 0, w, h);

        return (bitmap);
    }

    private void setChapterDetail() {
        if(chapterDetail.getStatus().equals("true")){
            binding.ivBookmark.setBackgroundResource(R.drawable.ic_bookmark_save);
        }else{
            binding.ivBookmark.setBackgroundResource(R.drawable.ic_bookmark_unsave);
        }
        binding.tvChapter.setText(chapterDetail.getChapterName());
        binding.tvDescription.setText(Html.fromHtml(chapterDetail.getDescription()));

        if(chapterDetail.getChapterImage() != null){
            if (!chapterDetail.getChapterImage().isEmpty()) {
                Picasso.get()
                        .load(Allurls.IMAGEURL + chapterDetail.getChapterImage())
                        .error(R.drawable.progress_animation)
                        .placeholder(R.drawable.progress_animation).
                        into(binding.ivChapterImage, new com.squareup.picasso.Callback() {
                            @Override
                            public void onSuccess() {
                                Drawable drawable = binding.ivChapterImage.getDrawable();
                                Bitmap bitmap = DrawableUtils.drawableToBitmap(drawable);
                                Bitmap blurred = fastblur(bitmap, 1.f, 25);
                                binding.blurryLayout.setImageBitmap(blurred);
//                                binding.blurryLayout.setBitmapBlur(bitmap,25,100);
                                /*binding.ivChapterImage.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        Drawable drawable = binding.ivChapterImage.getDrawable();
                                        Bitmap bitmap = DrawableUtils.drawableToBitmap(drawable);

                                        // Configure BlurView with RenderScriptBlur and set the bitmap
                                        float radius = 5f;
                                        binding.bluriew.setupWith(binding.rlMain)
                                                .setFrameClearDrawable(drawable)
                                                .setBlurAlgorithm(new RenderScriptBlur(ChapterDetailActivity.this))
                                                .setBlurRadius(radius)
                                                .setBlurAutoUpdate(true)
                                                .setHasFixedTransformationMatrix(true);
                                    }
                                });*/
                            }

                            @Override
                            public void onError(Exception e) {

                            }
                        });

            }
        }

        binding.tvBookName.setText("Book: " +otherDetail.getBookName());
        binding.tvAuthorName.setText("अध्ययन सामग्री: " + otherDetail.getAuthorName());
        binding.tvAudioDuration.setText(" | "+chapterDetail.getTimeDuration()+" "+chapterDetail.getSelectTime());
        binding.tvAudioDuration.setVisibility(chapterDetail.getTimeDuration().isEmpty()?View.GONE:View.VISIBLE);
        binding.tvPdfPages.setText(" | "+chapterDetail.getPdfCount()+" Pages");
        binding.tvPdfPages.setVisibility(chapterDetail.getPdfCount().isEmpty()?View.GONE:View.VISIBLE);

        if (chapterDetail.getAudio() != null && chapterDetail.getPdf() != null) {
            if (chapterDetail.getAudio().isEmpty() && chapterDetail.getPdf().isEmpty()
                    && chapterDetail.getUrl().isEmpty() && chapterDetail.getPdfUrl().isEmpty()) {
                binding.llAudiobookEbook.setVisibility(View.GONE);
            } else if (!chapterDetail.getAudio().isEmpty() && chapterDetail.getPdf().isEmpty()
                    && chapterDetail.getUrl().isEmpty() && chapterDetail.getPdfUrl().isEmpty()) {
                binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                binding.llAudiobook.setVisibility(View.VISIBLE);
                binding.btnPlay.setVisibility(View.VISIBLE);
                binding.llEbook.setVisibility(View.GONE);
                binding.btnRead.setVisibility(View.GONE);
            } else if (!chapterDetail.getPdf().isEmpty() && chapterDetail.getAudio().isEmpty()
                    && chapterDetail.getUrl().isEmpty() && chapterDetail.getPdfUrl().isEmpty()) {
                binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                binding.llEbook.setVisibility(View.VISIBLE);
                binding.btnRead.setVisibility(View.VISIBLE);
                binding.llAudiobook.setVisibility(View.GONE);
                binding.btnPlay.setVisibility(View.GONE);
            }else if (chapterDetail.getAudio().isEmpty() && chapterDetail.getPdf().isEmpty()
                    && !chapterDetail.getUrl().isEmpty() && chapterDetail.getPdfUrl().isEmpty()) {
                binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                binding.llAudiobook.setVisibility(View.VISIBLE);
                binding.btnPlay.setVisibility(View.VISIBLE);
                binding.llEbook.setVisibility(View.GONE);
                binding.btnRead.setVisibility(View.GONE);
            }else if (chapterDetail.getPdf().isEmpty() && chapterDetail.getAudio().isEmpty()
                    && chapterDetail.getUrl().isEmpty() && !chapterDetail.getPdfUrl().isEmpty()) {
                binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                binding.llEbook.setVisibility(View.VISIBLE);
                binding.btnRead.setVisibility(View.VISIBLE);
                binding.llAudiobook.setVisibility(View.GONE);
                binding.btnPlay.setVisibility(View.GONE);
            }
            else if (!chapterDetail.getAudio().isEmpty() && !chapterDetail.getPdf().isEmpty()
                    && chapterDetail.getUrl().isEmpty() && chapterDetail.getPdfUrl().isEmpty()) {
                binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                binding.llAudiobook.setVisibility(View.VISIBLE);
                binding.btnPlay.setVisibility(View.VISIBLE);
                binding.llEbook.setVisibility(View.VISIBLE);
                binding.btnRead.setVisibility(View.VISIBLE);
            }else if (chapterDetail.getAudio().isEmpty() && chapterDetail.getPdf().isEmpty()
                    && !chapterDetail.getUrl().isEmpty() && !chapterDetail.getPdfUrl().isEmpty()) {
                binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                binding.llAudiobook.setVisibility(View.VISIBLE);
                binding.btnPlay.setVisibility(View.VISIBLE);
                binding.llEbook.setVisibility(View.VISIBLE);
                binding.btnRead.setVisibility(View.VISIBLE);
            }else if (!chapterDetail.getAudio().isEmpty() && chapterDetail.getPdf().isEmpty()
                    && !chapterDetail.getUrl().isEmpty() && chapterDetail.getPdfUrl().isEmpty()) {
                binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                binding.llAudiobook.setVisibility(View.VISIBLE);
                binding.btnPlay.setVisibility(View.VISIBLE);
                binding.llEbook.setVisibility(View.GONE);
                binding.btnRead.setVisibility(View.GONE);
            } else if (chapterDetail.getAudio().isEmpty() && !chapterDetail.getPdf().isEmpty()
                    && chapterDetail.getUrl().isEmpty() && !chapterDetail.getPdfUrl().isEmpty()) {
                binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                binding.llEbook.setVisibility(View.VISIBLE);
                binding.btnRead.setVisibility(View.VISIBLE);
                binding.llAudiobook.setVisibility(View.GONE);
                binding.btnPlay.setVisibility(View.GONE);
            } else if (!chapterDetail.getAudio().isEmpty() && !chapterDetail.getPdf().isEmpty()
                    && !chapterDetail.getUrl().isEmpty() && chapterDetail.getPdfUrl().isEmpty()) {
                binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                binding.llAudiobook.setVisibility(View.VISIBLE);
                binding.btnPlay.setVisibility(View.VISIBLE);
                binding.llEbook.setVisibility(View.VISIBLE);
                binding.btnRead.setVisibility(View.VISIBLE);
            } else if (!chapterDetail.getAudio().isEmpty() && !chapterDetail.getPdf().isEmpty()
                    && chapterDetail.getUrl().isEmpty() && !chapterDetail.getPdfUrl().isEmpty()) {
                binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                binding.llAudiobook.setVisibility(View.VISIBLE);
                binding.btnPlay.setVisibility(View.VISIBLE);
                binding.llEbook.setVisibility(View.VISIBLE);
                binding.btnRead.setVisibility(View.VISIBLE);
            } else if (chapterDetail.getAudio().isEmpty() && !chapterDetail.getPdf().isEmpty()
                    && !chapterDetail.getUrl().isEmpty() && !chapterDetail.getPdfUrl().isEmpty()) {
                binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                binding.llAudiobook.setVisibility(View.VISIBLE);
                binding.btnPlay.setVisibility(View.VISIBLE);
                binding.llEbook.setVisibility(View.VISIBLE);
                binding.btnRead.setVisibility(View.VISIBLE);
            } else if (!chapterDetail.getAudio().isEmpty() && chapterDetail.getPdf().isEmpty()
                    && !chapterDetail.getUrl().isEmpty() && !chapterDetail.getPdfUrl().isEmpty()) {
                binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                binding.llAudiobook.setVisibility(View.VISIBLE);
                binding.btnPlay.setVisibility(View.VISIBLE);
                binding.llEbook.setVisibility(View.VISIBLE);
                binding.btnRead.setVisibility(View.VISIBLE);
            } else {
                binding.llAudiobookEbook.setVisibility(View.VISIBLE);
                binding.llAudiobook.setVisibility(View.VISIBLE);
                binding.btnPlay.setVisibility(View.VISIBLE);
                binding.llEbook.setVisibility(View.VISIBLE);
                binding.btnRead.setVisibility(View.VISIBLE);
            }
        } else {
            binding.llAudiobookEbook.setVisibility(View.GONE);
        }
    }



    private String convertFormate(int duration) {
        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(duration),
                TimeUnit.MILLISECONDS.toSeconds(duration) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration)));
    }

    public void onclicks() {
        binding.llBack.setOnClickListener(this);
        binding.btnPlay.setOnClickListener(this);
        binding.btnRead.setOnClickListener(this);
        binding.llBookmark.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llBack:
                onBackPressed();
                break;

            case R.id.btnPlay:
                isClick = true;
                newPosition = positionChapter;
                if(mySharedPref.getSavedRewardedAddsStatus().equals("Yes")){
                    showunlockDialog();
                }else{
                    startActivity(new Intent(context, AudiobookActivity.class)
                            .putExtra("ChapterDetail", chapterDetail)
                            .putExtra("otherDetail", otherDetail)
                            .putExtra("chapterList", (Serializable) chapterList)
                            .putExtra("positionChapter", positionChapter));

                }
//                if(mySharedPref.getSavedFirstPlay().equals("1")){
////                loadRewardedVideoAd();
//
//                    if(mySharedPref.getSavedRewardedAddsStatus().equals("Yes")){
//
//                        showunlockDialog();
//                    }else{
//                        startActivity(new Intent(context, AudiobookActivity.class)
//                                .putExtra("ChapterDetail", (Serializable) chapterDetail)
//                                .putExtra("otherDetail", (Serializable) otherDetail)
//                                .putExtra("chapterList", (Serializable) chapterList)
//                                .putExtra("positionChapter", positionChapter));
//                    }
//
//                }else{
//                    startActivity(new Intent(context, AudiobookActivity.class)
//                            .putExtra("ChapterDetail", (Serializable) chapterDetail)
//                            .putExtra("otherDetail", (Serializable) otherDetail)
//                            .putExtra("chapterList", (Serializable) chapterList)
//                            .putExtra("positionChapter", positionChapter));
//
//                    mySharedPref.setSavedFirstPlay("1");
//                }
                break;

            case R.id.btnRead:
                /*BitmapDrawable drawable = (BitmapDrawable) ivChapterImage.getDrawable();
                Bitmap bitmap = drawable.getBitmap();*/
                startActivity(new Intent(context, EbookActivity.class)
                        .putExtra("ChapterDetail", chapterDetail)
                        .putExtra("otherDetail", otherDetail)
                        .putExtra("chapterList", (Serializable) chapterList)
                        .putExtra("positionChapter", positionChapter)
                        .putExtra("FROM","ChapterDetailActivity")

                );
                break;
            case R.id.llBookmark:
                if (mySharedPref.isLogin()) {
                    if(chapterDetail.getStatus().equals("true")){
                        showBottomSheetBookmarkDialog();
                    }else{
                        if (Constants.isInternetConnected(context)) {
                            AddBookmarkAPI(chapterDetail.getId().toString());
                        } else {
                            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    OpenLoginDialogClass.openLoginDialog(context);
                }
                break;
        }
    }

    public void showunlockDialog() {
        boolean isCLICK;
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_unlock_audio);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.findViewById(R.id.btnWatch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();

                startActivity(new Intent(context, AudiobookActivity.class)
                        .putExtra("ChapterDetail", chapterDetail)
                        .putExtra("otherDetail", otherDetail)
                        .putExtra("chapterList", (Serializable) chapterList)
                        .putExtra("positionChapter", positionChapter));

//                Customprogress.showPopupProgressSpinner(context,true);
                /*new Handler().postDelayed(new Runnable() {
                    public void run() {
                        // yourMethod();
                        Customprogress.showPopupProgressSpinner(context,false);
                        startActivity(new Intent(context, AudiobookActivity.class)
                                .putExtra("ChapterDetail", (Serializable) chapterDetail)
                                .putExtra("otherDetail", (Serializable) otherDetail)
                                .putExtra("chapterList", (Serializable) chapterList)
                                .putExtra("positionChapter", positionChapter));
                    }
                }, 5000);*/



            }
        });
        dialog.findViewById(R.id.btnSkipPLay).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();
            }
        });

        dialog.show();
    }



    public void AddBookmarkAPI(String chapterId) {
        Customprogress.showPopupProgressSpinner(context, false);
        AddBookmarkParaRes addBookmarkParaRes = new AddBookmarkParaRes();
        addBookmarkParaRes.setChapterId(chapterId);
        jsonPlaceHolderApi.AddBookmarkAPI("application/json", "application/json", "Bearer " + mySharedPref.getSavedAccessToken(), addBookmarkParaRes).enqueue(new Callback<AddBookmarkRes>() {
            @Override
            public void onResponse(Call<AddBookmarkRes> call, Response<AddBookmarkRes> response) {

                if (response.isSuccessful()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {
                        binding.ivBookmark.setBackgroundResource(R.drawable.ic_bookmark_save);
                        chapterDetail.setStatus("true");
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<AddBookmarkRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
//        AdManager.getInstance().loadInterstitialAd(context);
    }

    private void showBottomSheetBookmarkDialog() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context, R.style.CustomBottomSheetDialog);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_dialog_bookmark_layout);

        btnCancel = bottomSheetDialog.findViewById(R.id.btnCancel);
        btnRemove = bottomSheetDialog.findViewById(R.id.btnRemove);
        tvChapter = bottomSheetDialog.findViewById(R.id.tvChapter);
        tvSubjectName = bottomSheetDialog.findViewById(R.id.tvSubjectName);
        llAudiobook = bottomSheetDialog.findViewById(R.id.llAudiobook);
        llEbook = bottomSheetDialog.findViewById(R.id.llEbook);
        llAudiobookEbook = bottomSheetDialog.findViewById(R.id.llAudiobookEbook);
        ivChapterImage = bottomSheetDialog.findViewById(R.id.ivChapterImage);
        tvChapter.setText(chapterDetail.getChapterName());
        tvSubjectName.setText(Html.fromHtml(chapterDetail.getDescription()));
        bottomtvAudioDuration = bottomSheetDialog.findViewById(R.id.bottomtvAudioDuration);
        bottomtvPdfPages = bottomSheetDialog.findViewById(R.id.bottomtvPdfPages);
        bottomtvAudioDuration.setText(" | "+chapterDetail.getTimeDuration()+" "+chapterDetail.getSelectTime());
        bottomtvAudioDuration.setVisibility(chapterDetail.getTimeDuration().isEmpty()?View.GONE:View.VISIBLE);
        bottomtvPdfPages.setText(" | "+chapterDetail.getPdfCount()+" Pages");
        bottomtvPdfPages.setVisibility(chapterDetail.getPdfCount().isEmpty()?View.GONE:View.VISIBLE);

        if (chapterDetail.getChapterImage() != null) {
            if (!chapterDetail.getChapterImage().isEmpty()) {
                Picasso.get().load(Allurls.IMAGEURL + chapterDetail.getChapterImage()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(ivChapterImage);
            }
        }
        if (chapterDetail.getAudio() != null && chapterDetail.getPdf() != null) {
            if (chapterDetail.getAudio().isEmpty() && chapterDetail.getPdf().isEmpty()
                    && chapterDetail.getUrl().isEmpty() && chapterDetail.getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.GONE);
            } else if (!chapterDetail.getAudio().isEmpty() && chapterDetail.getPdf().isEmpty()
                    && chapterDetail.getUrl().isEmpty() && chapterDetail.getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.GONE);
            } else if (chapterDetail.getAudio().isEmpty() && !chapterDetail.getPdf().isEmpty()
                    && chapterDetail.getUrl().isEmpty() && chapterDetail.getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.GONE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (chapterDetail.getAudio().isEmpty() && chapterDetail.getPdf().isEmpty()
                    && !chapterDetail.getUrl().isEmpty() && chapterDetail.getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.GONE);
            } else if (chapterDetail.getAudio().isEmpty() && chapterDetail.getPdf().isEmpty()
                    && chapterDetail.getUrl().isEmpty() && !chapterDetail.getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.GONE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (!chapterDetail.getAudio().isEmpty() && !chapterDetail.getPdf().isEmpty()
                    && chapterDetail.getUrl().isEmpty() && chapterDetail.getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (chapterDetail.getAudio().isEmpty() && chapterDetail.getPdf().isEmpty()
                    && !chapterDetail.getUrl().isEmpty() && !chapterDetail.getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (!chapterDetail.getAudio().isEmpty() && !chapterDetail.getPdf().isEmpty()
                    && !chapterDetail.getUrl().isEmpty() && chapterDetail.getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (!chapterDetail.getAudio().isEmpty() && !chapterDetail.getPdf().isEmpty()
                    && chapterDetail.getUrl().isEmpty() && !chapterDetail.getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (chapterDetail.getAudio().isEmpty() && !chapterDetail.getPdf().isEmpty()
                    && !chapterDetail.getUrl().isEmpty() && !chapterDetail.getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (!chapterDetail.getAudio().isEmpty() && chapterDetail.getPdf().isEmpty()
                    && !chapterDetail.getUrl().isEmpty() && !chapterDetail.getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            } else {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            }
        } else {
            llAudiobookEbook.setVisibility(View.GONE);
        }


        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog.dismiss();
            }
        });


        btnRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog.dismiss();
                if (Constants.isInternetConnected(context)) {
                    RemoveBookmarkAPI(chapterDetail.getBookmark_id());
                } else {
                    Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                }

            }
        });
        bottomSheetDialog.show();
    }

    public void RemoveBookmarkAPI(String bookmarkId) {
        Customprogress.showPopupProgressSpinner(context, false);
        RemoveBookmarkParaRes removeBookmarkParaRes = new RemoveBookmarkParaRes();
        removeBookmarkParaRes.setBookmarkId(bookmarkId);
        jsonPlaceHolderApi.RemoveBookmarkAPI("application/json", "application/json", "Bearer " + mySharedPref.getSavedAccessToken(), removeBookmarkParaRes).enqueue(new Callback<RemoveBookmarkRes>() {
            @Override
            public void onResponse(Call<RemoveBookmarkRes> call, Response<RemoveBookmarkRes> response) {
                if (response.isSuccessful()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {
                        binding.ivBookmark.setBackgroundResource(R.drawable.ic_bookmark_unsave);
                        chapterDetail.setStatus("false");
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<RemoveBookmarkRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
            }
        });
    }

    public void AddCountAPI() {
//        Customprogress.showPopupProgressSpinner(context, true);
        CountReq chapterParaRes = new CountReq();
        chapterParaRes.setChapterId(chapterList.get(Integer.parseInt(positionChapter)).getId());

        jsonPlaceHolderApi.ViewCountAPI("application/json", "application/json", "Bearer " + mySharedPref.getSavedAccessToken(), chapterParaRes).enqueue(new Callback<CountResponse>() {
            @Override
            public void onResponse(Call<CountResponse> call, Response<CountResponse> response) {
                if (response.isSuccessful()) {
//                   Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {

                    } else {

                    }
                }
            }

            @Override
            public void onFailure(Call<CountResponse> call, Throwable t) {
//                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
            }
        });
    }


}
package com.edutech.ncert.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Environment;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.activity.web.WebViewActivity;
import com.edutech.ncert.databinding.ListItemChapterBinding;
import com.edutech.ncert.model.ChapterModel.Datum;
import com.edutech.ncert.server.Allurls;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.AdManager;
import com.edutech.ncert.utils.OpenLoginDialogClass;
import com.github.barteksc.pdfviewer.PDFView;
import com.github.barteksc.pdfviewer.listener.OnPageChangeListener;
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ChapterListAdapter extends RecyclerView.Adapter<ChapterListAdapter.RecyclerViewHolder> implements OnPageChangeListener{
    Context context;
    List<Datum> list;
    int selectPosition = -1;
    ItemClick itemClick;
    ImageView ivSave, ivUnsave, ivChapterImage;
    LinearLayout btnCancel, btnRemove, llAudiobook, llEbook, llAudiobookEbook;
    TextView tvChapter, tvSubjectName,bottomtvAudioDuration,bottomtvPdfPages;
    private final MySharedPref mySharedPref;
    String duration = "00:00";
    TextView tvAudioDuration, tvPdfPages;
    MediaPlayer mPlayer;
    InputStream inputStream = null;
    PDFView pdfView;
    File file;
    String pdfName = "";
    int pageNumber = 0;
    String totalPage = "";
    AdManager adManager; // 🔼 Add this at class level

    public ChapterListAdapter(Context context, List<Datum> list, ItemClick itemClick, AdManager adManager) {
        this.context = context;
        this.list = list;
        this.itemClick = itemClick;
        this.adManager = adManager;
        mySharedPref = new MySharedPref(context);
    }


    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item_chapter, parent, false);
        RecyclerViewHolder recyclerViewHolder = new RecyclerViewHolder(view);
        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, @SuppressLint("RecyclerView") int position) {
       /* new Handler().postDelayed(() -> {
            Customprogress.showPopupProgressSpinner(context,false);
        }, 3000);*/
        holder.binding.tvChapter.setText(list.get(position).getChapterName());
        //html description
        Spanned htmlDescription = Html.fromHtml(list.get(position).getDescription());
        String descriptionWithOutExtraSpace = htmlDescription.toString().trim();
        holder.binding.tvDescription.setText(htmlDescription.subSequence(0, descriptionWithOutExtraSpace.length()));
//        holder.binding.tvDescription.setText(Html.fromHtml(list.get(position).getDescription()));
        holder.binding.tvAudioDuration.setText(" | "+list.get(position).getTimeDuration()+" "+list.get(position).getSelectTime());
        holder.binding.tvAudioDuration.setVisibility(list.get(position).getTimeDuration().isEmpty()?View.GONE:View.VISIBLE);
        holder.binding.tvPdfPages.setText(" | " + list.get(position).getPdfCount() + " Pages");

// Proper visibility handling for tvPdfPages
        holder.binding.tvPdfPages.setVisibility(
                list.get(position).getPdfCount() != null && !list.get(position).getPdfCount().isEmpty()
                        ? View.VISIBLE : View.GONE
        );

// Show WebView icon if URL is present
        if (list.get(position).getWebviewUrl() != null && !list.get(position).getWebviewUrl().isEmpty()) {
            holder.binding.llWebview.setVisibility(View.VISIBLE);
        } else {
            holder.binding.llWebview.setVisibility(View.GONE);
        }


        if (list.get(position).getStatus().equals("true")) {
            holder.binding.ivsave.setVisibility(View.VISIBLE);
            holder.binding.ivUnsave.setVisibility(View.GONE);
        } else {
            holder.binding.ivsave.setVisibility(View.GONE);
            holder.binding.ivUnsave.setVisibility(View.VISIBLE);
        }

        Log.d("TAG", "image>>" + Allurls.IMAGEURL + list.get(position).getChapterImage());
        if (list.get(position).getChapterImage() != null) {
            if (!list.get(position).getChapterImage().isEmpty()) {
                Picasso.get().load(Allurls.IMAGEURL + list.get(position).getChapterImage()).error(R.drawable.default_img).placeholder(R.drawable.default_img).into(holder.binding.ivChapterImage);
            }
        }


        boolean hasAudio =
                (list.get(position).getAudio() != null && !list.get(position).getAudio().isEmpty()) ||
                        (list.get(position).getUrl() != null && !list.get(position).getUrl().isEmpty());

        boolean hasPdf = (list.get(position).getPdf() != null && !list.get(position).getPdf().isEmpty()) ||
                (list.get(position).getPdfUrl() != null && !list.get(position).getPdfUrl().isEmpty());

        boolean hasWeb = list.get(position).getWebviewUrl() != null && !list.get(position).getWebviewUrl().isEmpty();

        holder.binding.llAudiobook.setVisibility(hasAudio ? View.VISIBLE : View.GONE);
        holder.binding.llEbook.setVisibility(hasPdf ? View.VISIBLE : View.GONE);
        holder.binding.llWebview.setVisibility(hasWeb ? View.VISIBLE : View.GONE);

        if (hasAudio || hasPdf || hasWeb) {
            holder.binding.llAudiobookEbook.setVisibility(View.VISIBLE);
        } else {
            holder.binding.llAudiobookEbook.setVisibility(View.GONE);
        }




        holder.binding.llSaveUnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mySharedPref.isLogin()) {
                    if (holder.binding.ivsave.getVisibility() == View.VISIBLE) {
                        showBottomSheetBookmarkDialog(position);
                    } else {
                        itemClick.onItemClick(position, "addbookmark");
                        notifyDataSetChanged();
                    }
                } else {
                    OpenLoginDialogClass.openLoginDialog(context);
                }
            }
        });

        holder.binding.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Datum chapter = list.get(position);
                if (chapter.getWebviewUrl() != null && !chapter.getWebviewUrl().isEmpty()) {
                    if (adManager != null) {
                        adManager.showInterstitial((Activity) context, () -> {
                            Intent intent = new Intent(context, WebViewActivity.class);
                            intent.putExtra("url", chapter.getWebviewUrl());
                            context.startActivity(intent);
                        });
                    } else {
                        Intent intent = new Intent(context, WebViewActivity.class);
                        intent.putExtra("url", chapter.getWebviewUrl());
                        context.startActivity(intent);
                    }
                    return;
                }

                selectPosition = position;
                itemClick.onItemClick(position, "_chapter");
                notifyDataSetChanged();
            }
        });

        mPlayer = new MediaPlayer();
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);

        if (!list.get(position).getAudio().isEmpty()) {
         /*   try {
                mPlayer.setDataSource(Allurls.IMAGEURL + list.get(position).getAudio());
                mPlayer.prepare();

                duration = convertFormate(mPlayer.getDuration());
                holder.binding.tvAudioDuration.setText(duration);

            } catch (IOException e) {
                throw new RuntimeException(e);
            }*/
        } else if (!list.get(position).getUrl().isEmpty()) {
       /*     try {
                mPlayer.setDataSource(Allurls.IMAGEURL + list.get(position).getUrl());
                mPlayer.prepare();
                duration = convertFormate(mPlayer.getDuration());
                holder.binding.tvAudioDuration.setText(duration);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }*/
        }

        if (!list.get(position).getPdf().isEmpty()) {
          /*  if(!mySharedPref.getSavedPdf().equals(list.get(position).getId().toString()+".pdf")){
                Download_PDF_Internal_Storage(Allurls.IMAGEURL+list.get(position).getPdf(),list.get(position).getId().toString());

            }else{
                file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), list.get(position).getId().toString() + ".pdf");
                openPdf();
            }*/

        } else if (!list.get(position).getPdfUrl().isEmpty()) {
            /*if(!mySharedPref.getSavedPdf().equals(list.get(position).getId().toString()+".pdf")){
                Download_PDF_Internal_Storage(Allurls.IMAGEURL+list.get(position).getPdfUrl(),list.get(position).getId().toString());
            }else{
                file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), list.get(position).getId().toString() + ".pdf");
                openPdf();
            }*/
        }
    }

    private void showBottomSheetBookmarkDialog(int position) {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context, R.style.CustomBottomSheetDialog);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_dialog_bookmark_layout);

        btnCancel = bottomSheetDialog.findViewById(R.id.btnCancel);
        btnRemove = bottomSheetDialog.findViewById(R.id.btnRemove);
        tvChapter = bottomSheetDialog.findViewById(R.id.tvChapter);
        tvSubjectName = bottomSheetDialog.findViewById(R.id.tvSubjectName);
        llAudiobook = bottomSheetDialog.findViewById(R.id.llAudiobook);
        llEbook = bottomSheetDialog.findViewById(R.id.llEbook);
        llAudiobookEbook = bottomSheetDialog.findViewById(R.id.llAudiobookEbook);
        ivChapterImage = bottomSheetDialog.findViewById(R.id.ivChapterImage);
        bottomtvAudioDuration = bottomSheetDialog.findViewById(R.id.bottomtvAudioDuration);
        bottomtvPdfPages = bottomSheetDialog.findViewById(R.id.bottomtvPdfPages);
        bottomtvAudioDuration.setText(" | "+list.get(position).getTimeDuration()+" "+list.get(position).getSelectTime());
        bottomtvAudioDuration.setVisibility(list.get(position).getTimeDuration().isEmpty()?View.GONE:View.VISIBLE);
        bottomtvPdfPages.setText(" | "+list.get(position).getPdfCount()+" Pages");
        bottomtvPdfPages.setVisibility(list.get(position).getPdfCount().isEmpty()?View.GONE:View.VISIBLE);

        tvChapter.setText(list.get(position).getChapterName());
        tvSubjectName.setText(Html.fromHtml(list.get(position).getDescription()));
        if (list.get(position).getChapterImage() != null) {
            if (!list.get(position).getChapterImage().isEmpty()) {
                Picasso.get().load(Allurls.IMAGEURL + list.get(position).getChapterImage()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(ivChapterImage);
            }
        }
        if (list.get(position).getAudio() != null && list.get(position).getPdf() != null) {
            if (list.get(position).getAudio().isEmpty() && list.get(position).getPdf().isEmpty()
                    && list.get(position).getUrl().isEmpty() && list.get(position).getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.GONE);
            } else if (!list.get(position).getAudio().isEmpty() && list.get(position).getPdf().isEmpty()
                    && list.get(position).getUrl().isEmpty() && list.get(position).getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.GONE);
            } else if (list.get(position).getAudio().isEmpty() && !list.get(position).getPdf().isEmpty()
                    && list.get(position).getUrl().isEmpty() && list.get(position).getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.GONE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (list.get(position).getAudio().isEmpty() && list.get(position).getPdf().isEmpty()
                    && !list.get(position).getUrl().isEmpty() && list.get(position).getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.GONE);
            } else if (list.get(position).getAudio().isEmpty() && list.get(position).getPdf().isEmpty()
                    && list.get(position).getUrl().isEmpty() && !list.get(position).getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.GONE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (!list.get(position).getAudio().isEmpty() && !list.get(position).getPdf().isEmpty()
                    && list.get(position).getUrl().isEmpty() && list.get(position).getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (list.get(position).getAudio().isEmpty() && list.get(position).getPdf().isEmpty()
                    && !list.get(position).getUrl().isEmpty() && !list.get(position).getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (!list.get(position).getAudio().isEmpty() && !list.get(position).getPdf().isEmpty()
                    && !list.get(position).getUrl().isEmpty() && list.get(position).getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (!list.get(position).getAudio().isEmpty() && !list.get(position).getPdf().isEmpty()
                    && list.get(position).getUrl().isEmpty() && !list.get(position).getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (list.get(position).getAudio().isEmpty() && !list.get(position).getPdf().isEmpty()
                    && !list.get(position).getUrl().isEmpty() && !list.get(position).getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            } else if (!list.get(position).getAudio().isEmpty() && list.get(position).getPdf().isEmpty()
                    && !list.get(position).getUrl().isEmpty() && !list.get(position).getPdfUrl().isEmpty()) {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            } else {
                llAudiobookEbook.setVisibility(View.VISIBLE);
                llAudiobook.setVisibility(View.VISIBLE);
                llEbook.setVisibility(View.VISIBLE);
            }
        } else {
            llAudiobookEbook.setVisibility(View.GONE);
        }


        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog.dismiss();
            }
        });


        btnRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog.dismiss();
             /*   ivSave.setVisibility(View.GONE);
                ivUnsave.setVisibility(View.VISIBLE);*/
                itemClick.onItemClick(position, "removebookmark");
                notifyDataSetChanged();
            }
        });
        bottomSheetDialog.show();
    }

    @Override
    public int getItemCount() {
        return list.size();
    }




    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private final ListItemChapterBinding binding;


        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ListItemChapterBinding.bind(itemView);
            ivSave = itemView.findViewById(R.id.ivsave);
            ivUnsave = itemView.findViewById(R.id.ivUnsave);
            tvAudioDuration = itemView.findViewById(R.id.tvAudioDuration);
            tvPdfPages = itemView.findViewById(R.id.tvPdfPages);
            pdfView = itemView.findViewById(R.id.pdfView);

        }
    }
    private String convertFormate(int duration) {
        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(duration),
                TimeUnit.MILLISECONDS.toSeconds(duration) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration)));
    }

    private void Download_PDF_Internal_Storage(String url,String chapterId) {
        DownloadManager mgr = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        Uri Download_Uri = Uri.parse(url);
        DownloadManager.Request request = new DownloadManager.Request(Download_Uri);

        request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE);
        request.setAllowedOverRoaming(false);
        request.setTitle("PDF File Download");
        request.setDescription("Downloading " + "pdf" + " file using Download Manager.");
        request.setVisibleInDownloadsUi(true);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, chapterId + ".pdf");
        //  request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_HIDDEN);
        mgr.enqueue(request);
        //  Toast.makeText(this, "PDF Download Started", Toast.LENGTH_SHORT).show();

        BroadcastReceiver onComplete = new BroadcastReceiver() {
            public void onReceive(Context ctxt, Intent intent) {
                file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), chapterId + ".pdf");
                pdfName = file.getName();
                mySharedPref.setSavedPdf(pdfName);
                openPdf();
            }

        };
        context.registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
    }
    private void openPdf() {
        pdfView.fromFile(file)
                .enableDoubletap(true)
                .defaultPage(0)
                .scrollHandle(new DefaultScrollHandle(context))
                .onPageChange(this)
                .spacing(10)
                .load();
    }

    @Override
    public void onPageChanged(int page, int pageCount) {
        pageNumber = page;
        totalPage = String.format("%s",pageCount+" Pages");
//        tvPdfPages.setText(totalPage);
        Log.d("TAG123>>", "page>>" + String.format("%s",pageCount));

    }
}

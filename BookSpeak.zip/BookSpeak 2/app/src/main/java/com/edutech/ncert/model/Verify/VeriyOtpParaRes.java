package com.edutech.ncert.model.Verify;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class VeriyOtpParaRes {

    @SerializedName("phone")
    @Expose
    private String phone;

    @SerializedName("countryCode")
    @Expose
    private String countryCode;
    @SerializedName("otp")
    @Expose
    private String otp;
    @SerializedName("device")
    @Expose
    private String device;
    @SerializedName("device_id")
    @Expose
    private String deviceId;
    @SerializedName("fcm_token")
    @Expose
    private String fcmToken;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getFcmToken() {
        return fcmToken;
    }

    public void setFcmToken(String fcmToken) {
        this.fcmToken = fcmToken;
    }

}

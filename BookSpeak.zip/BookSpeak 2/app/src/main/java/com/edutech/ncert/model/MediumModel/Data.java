
package com.edutech.ncert.model.MediumModel;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Data {

    @SerializedName("medium")
    @Expose
    private List<Medium> medium;
    @SerializedName("mediumbanner")
    @Expose
    private List<Mediumbanner> mediumbanner;

    public List<Medium> getMedium() {
        return medium;
    }

    public void setMedium(List<Medium> medium) {
        this.medium = medium;
    }

    public List<Mediumbanner> getMediumbanner() {
        return mediumbanner;
    }

    public void setMediumbanner(List<Mediumbanner> mediumbanner) {
        this.mediumbanner = mediumbanner;
    }

}

package com.edutech.ncert.model.GetBookmark;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class OtherDetail implements Serializable {

    @SerializedName("book_name")
    @Expose
    private String bookName;
    @SerializedName("author_name")
    @Expose
    private String authorName;
    @SerializedName("book_image")
    @Expose
    private String bookImage;

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public String getBookImage() {
        return bookImage;
    }

    public void setBookImage(String bookImage) {
        this.bookImage = bookImage;
    }

}

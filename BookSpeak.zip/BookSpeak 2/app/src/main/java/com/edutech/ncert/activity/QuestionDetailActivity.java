package com.edutech.ncert.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.edutech.ncert.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class QuestionDetailActivity extends AppCompatActivity {

    TextView tvTitle, tvDetails, tvStatus, tvReply;
    ImageView imgAttachment;
    Button btnViewPdf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_detail);

        tvTitle = findViewById(R.id.tvTitle);
        tvDetails = findViewById(R.id.tvDetails);
        tvStatus = findViewById(R.id.tvStatus);
        tvReply = findViewById(R.id.tvReply);
        imgAttachment = findViewById(R.id.imgAttachment);
        btnViewPdf = findViewById(R.id.btnViewPdf);

        Intent intent = getIntent();
        tvTitle.setText(intent.getStringExtra("title"));
        tvDetails.setText(intent.getStringExtra("details"));
        tvStatus.setText("Status: " + intent.getStringExtra("status"));

        String questionId = intent.getStringExtra("question_id");
        if (questionId == null || questionId.isEmpty()) {
            Toast.makeText(this, "Invalid question ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ask_questions").child(questionId);
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String reply = snapshot.child("admin_reply").getValue(String.class);
                    String attachmentUrl = snapshot.child("admin_attachment").getValue(String.class);

                    if (reply != null && !reply.isEmpty()) {
                        tvReply.setText("Admin Reply:\n" + reply);
                    } else {
                        tvReply.setText("No reply yet.");
                    }

                    if (attachmentUrl != null && !attachmentUrl.isEmpty()) {
                        String ext = attachmentUrl.substring(attachmentUrl.lastIndexOf('.') + 1).toLowerCase();

                        if (ext.equals("pdf")) {
                            btnViewPdf.setVisibility(Button.VISIBLE);
                            btnViewPdf.setOnClickListener(v -> {
                                Intent pdfIntent = new Intent(Intent.ACTION_VIEW);
                                pdfIntent.setDataAndType(Uri.parse(attachmentUrl), "application/pdf");
                                pdfIntent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                startActivity(pdfIntent);
                            });
                        } else {
                            imgAttachment.setVisibility(ImageView.VISIBLE);
                            Glide.with(QuestionDetailActivity.this).load(attachmentUrl).into(imgAttachment);
                        }
                    } else {
                        btnViewPdf.setVisibility(Button.GONE);
                        imgAttachment.setVisibility(ImageView.GONE);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(QuestionDetailActivity.this, "Failed to load data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

package com.edutech.ncert.activity;

import static com.edutech.ncert.activity.ChapterDetailActivity.newPosition;
import static com.edutech.ncert.notification.NofiticationCenter.channel_1_ID;

import android.Manifest;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.downloader.Error;
import com.downloader.OnDownloadListener;
import com.downloader.OnProgressListener;
import com.downloader.OnStartOrResumeListener;
import com.downloader.PRDownloader;
import com.downloader.PRDownloaderConfig;
import com.downloader.Progress;
import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ActivityAudiobookBinding;
import com.edutech.ncert.model.ChapterModel.Datum;
import com.edutech.ncert.model.ChapterModel.OtherDetail;
import com.edutech.ncert.notification.NotiService;
import com.edutech.ncert.server.Allurls;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.AdManager;
import com.edutech.ncert.utils.Customprogress;
import com.github.barteksc.pdfviewer.listener.OnErrorListener;
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackException;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class AudiobookActivity extends AppCompatActivity implements View.OnClickListener {
    private RewardedAd rewardedAd;
    public static boolean playin;
    private static AudiobookActivity instance;
    final int PERMISSION_REQUEST_CODE = 112;
    private static final String TAG = "AudioBookActivityTAG";
    private NotificationManagerCompat notificationManager;
    MediaMetadataRetriever metadataRetriever;
    private MediaSessionCompat mediaSession;
    public static Notification notification;
    int position;
    Context context;
    private ActivityAudiobookBinding binding;
    ExoPlayer player;
    private double startTime = 0;
    private double finalTime = 0;
    private final int forwardTime = 30000;
    private final int backwardTime = 30000;
    TextView tvs25, tvs5, tvs75, tvNormal, tv25, tv5, tv75, tv2;
    String speedValue = "1X";
    OtherDetail otherDetail;
    List<Datum> chapterList = new ArrayList<>();
    String positionChapter;
    int positionChapterint;
    Handler handler = new Handler();
    private MySharedPref mySharedPref;
    Datum chapterDetail;
    int pageNumber = 0;
    String url = "";
    String downloadDir = "";
    String fileName = null;
    File file;

    private final Handler interstitialHandler = new Handler();
    private Runnable runnable;
    private final long delayMillis = 2 * 60 * 1000; // 2 minutes in milliseconds
    private boolean stayedLongEnough = false;

    private boolean isAdDismissed=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAudiobookBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Start tracking time
        runnable = new Runnable() {
            @Override
            public void run() {
                stayedLongEnough = true;
            }
        };

        interstitialHandler.postDelayed(runnable, delayMillis);

        init();
        onclicks();
    }

    public void init() {
        context = AudiobookActivity.this;
        mySharedPref = new MySharedPref(context);
        getNotificationPermission();

        MobileAds.initialize(context, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        binding.adView.loadAd(adRequest);
        if (mySharedPref.getSavedBannerAddsStatus().equals("Yes")) {
            binding.btnAdsShow.setVisibility(View.VISIBLE);
            System.out.println("mySharedPref.getSavedFirstPlay()>>> " + mySharedPref.getSavedFirstPlay());
            if (mySharedPref.getSavedFirstPlay().equals("1")) {
//                loadRewardedVideoAd();
            }
            mySharedPref.setSavedFirstPlay("1");

        } else {
            binding.btnAdsShow.setVisibility(View.GONE);
        }

        notificationManager = NotificationManagerCompat.from(this);
        mediaSession = new MediaSessionCompat(this, "tag");
        mediaSession.setCallback(new MediaSessionCompat.Callback() {
            // Implement callbacks
            @Override
            public boolean onMediaButtonEvent(Intent mediaButtonEvent) {
                // your implements
                return false;
            }

            @Override
            public void onPlay() {
                super.onPlay();
                // your play() implements
                play();
            }

            @Override
            public void onPause() {
                super.onPause();
                // your pause() implements
                pause();
            }

            @Override
            public void onSkipToNext() {
                super.onSkipToNext();
                // your next() implements
                next();
            }

            @Override
            public void onSkipToPrevious() {
                super.onSkipToPrevious();
                // your prev() implements
                previous();
            }

            @Override
            public void onSeekTo(long pos) {
                // your seek() implements
            }
        });
        instance = this;
        Intent intent = getIntent();
        if (intent != null) {
            chapterDetail = (Datum) intent.getSerializableExtra("ChapterDetail");
            otherDetail = (OtherDetail) intent.getSerializableExtra("otherDetail");
            chapterList = (List<Datum>) intent.getSerializableExtra("chapterList");
            positionChapter = intent.getStringExtra("positionChapter");
            Log.d("TAG!!123", "positionChapter<<" + positionChapter);
            Log.d("TAG!!123", "newPosition<<" + newPosition);

            if (!chapterDetail.getPdf().isEmpty()) {
                url = Allurls.IMAGEURL + chapterDetail.getPdf();
            } else if (!chapterDetail.getPdfUrl().isEmpty()) {
                url = chapterDetail.getPdfUrl();
            }

//            downloadDir=getApplicationContext().getApplicationInfo().dataDir;
            downloadDir = getFilesDir().getAbsolutePath();
            Log.d(TAG, "init: " + downloadDir);
            fileName = chapterDetail.getDateTime();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                fileName = Base64.getEncoder().encodeToString(fileName.getBytes()) + ".pdf";
            } else {
                fileName = fileName + ".pdf";
            }

//            fileName=chapterDetail.getId().toString()+ ".pdf";
            Log.d(TAG, "init: " + fileName);

            file = new File(downloadDir, fileName);
            if (!file.exists()) {
                Log.d("EBOOKTAG", "init: book not available" + file.getAbsolutePath());
                binding.bookCover.setVisibility(View.VISIBLE);
                binding.pdfView.setVisibility(View.GONE);
                Log.d(TAG, "init: book url = "+url);
                if (!url.isEmpty()) {
                    Download_PDF_Internal_Storage(url);
                }
            } else {
                Log.d("EBOOKTAG", "init: book available " + url);
                binding.bookCover.setVisibility(View.GONE);
                binding.pdfView.setVisibility(View.VISIBLE);
                openPdf();
            }

            positionChapterint = Integer.parseInt(positionChapter);
            initPlayer(positionChapterint);
            if (mySharedPref.getSavedRewardedAddsStatus().equals("Yes")) {
                onButtonClick();
            }
            /*if (positionChapter.equals(newPosition)) {
                positionChapterint = Integer.parseInt(positionChapter);
                initPlayer(positionChapterint);
            } else {

                // stopService(new Intent(context, NotiService.class));
                onBackPressed();
            }*/
        } else {
            Log.d("TAG!!12", "null Intent");
        }
    }

    private void Download_PDF_Internal_Storage(String url) {
        PRDownloaderConfig config = PRDownloaderConfig.newBuilder()
                .setReadTimeout(30_000)
                .setConnectTimeout(30_000)
                .build();
        PRDownloader.initialize(getApplicationContext(), config);
        ProgressDialog dialog = new ProgressDialog(this);
        dialog.setTitle("Downloading Pdf");
        dialog.setCancelable(false);
        dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        dialog.show();
        Log.d("EBOOKTAG", "Download_PDF_Internal_Storage: " + url);

        PRDownloader.download(url, downloadDir, fileName)
                .build()

                .setOnStartOrResumeListener(new OnStartOrResumeListener() {
                    @Override
                    public void onStartOrResume() {
                        Log.d("EBOOKTAG", "onStartOrResume: ");
                    }
                })
                .setOnProgressListener(new OnProgressListener() {
                    @Override
                    public void onProgress(Progress progress) {
                        Integer progressPercent = Integer.parseInt(String.valueOf(progress.currentBytes * 100 / progress.totalBytes));
                        dialog.setProgress(progressPercent);
                        /*
                        long progressPercent = progress.currentBytes * 100 / progress.totalBytes;
                        DecimalFormat df = new DecimalFormat("#.#");
                        dialog.setMessage(*//*"File Size: "+df.format((double)progress.totalBytes/1000000)+" mb\n*//*"Progress ..."+progressPercent+"%");
                         */
                    }
                })
                .start(new OnDownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        dialog.dismiss();
                        Log.d("EBOOKTAG", "onDownloadComplete: ");
                        file = new File(downloadDir, fileName);
                        binding.pdfView.setVisibility(View.VISIBLE);
                        binding.bookCover.setVisibility(View.GONE);
                        openPdf();
                    }

                    @Override
                    public void onError(Error error) {
                        dialog.dismiss();
                        binding.pdfView.setVisibility(View.GONE);
                        binding.bookCover.setVisibility(View.VISIBLE);
                        Toast.makeText(context, "download error", Toast.LENGTH_SHORT).show();
                        Log.d("EBOOKTAG", "onError: " + error.getServerErrorMessage());
                    }
                });
    }

    private void openPdf() {
        Log.d("EBOOKTAG", "openPdf: " + file.getAbsolutePath());
        binding.pdfView.fromFile(file)
                .nightMode(false)
                .enableDoubletap(true)
                .defaultPage(0)
                .scrollHandle(new DefaultScrollHandle(this))
//                .onPageChange(this)
                /*.onPageChange(new OnPageChangeListener() {
                    @Override
                    public void onPageChanged(int i, int i1) {

                    }
                })*/
                .spacing(10)
                .onError(new OnErrorListener() {
                    @Override
                    public void onError(Throwable t) {
                        Log.d("EBOOKTAG", "onError: " + t.getMessage());
                    }
                })
                .load();
        if (player!=null && !player.isPlaying()){
            if (mySharedPref.getSavedRewardedAddsStatus().equals("Yes") && isAdDismissed) {

                play();
            }
        }
    }

    public void onButtonClick() {
        Customprogress.showPopupProgressSpinner(context, false);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                // do something...
                Customprogress.showPopupProgressSpinner(context, false);
                System.out.println("rewarded ads>>>>>>>>   ");
//                        pause();
                playin = false;
                player.pause();
                binding.ivPause.setVisibility(View.VISIBLE);
                binding.ivPlay.setVisibility(View.GONE);
                binding.ivLoader.setVisibility(View.GONE);
                sendOnChannel(chapterList.get(positionChapterint).getChapterName(), otherDetail.getAuthorName(), positionChapterint);

            }
        }, 100);

        if (AdManager.getInstance().rewardedAd != null) {
            Log.d(TAG, "onButtonClick: reward");
            AdManager.getInstance().showRewardedAd(AudiobookActivity.this, new OnUserEarnedRewardListener() {
                @Override
                public void onUserEarnedReward(@NonNull RewardItem rewardItem) {

                }
            }, new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    super.onAdDismissedFullScreenContent();
                    isAdDismissed=true;
                    Log.d(TAG, "onAdDismissedFullScreenContent: Ad Dismissed");
                    if (file.exists()) {
                        play();
                    }
                    AdManager.getInstance().rewardedAd = null;
                }
            });
        } else {
            if (mySharedPref.getSavedInterstitialAddsStatus().equals("Yes")) {
//            AdManager.getInstance().showInterstitialAd();
                Log.d(TAG, "onButtonClick: interstitial");

                /*if (player != null) {
                    Log.d(TAG, "onButtonClick: null");
                    player.pause();
                }else {
                    Log.d(TAG, "onButtonClick: not null");
                }*/
                AdManager.getInstance().loadInterstitialAd(this);
                if (player != null) {
                    Log.d(TAG, "onButtonClick: null");
                    pause();
                }
            }
        }

//    void loadRewardedVideoAd()
//    {
//        // initializing RewardedVideoAd Object
//        // RewardedVideoAd  Constructor Takes Context as its
//        // Argument
//        RewardedVideoAd AdMobrewardedVideoAd
//                = MobileAds.getRewardedVideoAdInstance(this);
//
//        // Rewarded Video Ad Listener
//        AdMobrewardedVideoAd.setRewardedVideoAdListener(
//                new RewardedVideoAdListener() {
//                    @Override
//                    public void onRewardedVideoAdLoaded()
//                    {
//                        pause();
//                        AdMobrewardedVideoAd.show();
//                        // Showing Toast Message
////                        Toast
////                                .makeText(context,
////                                        "onRewardedVideoAdLoaded",
////                                        Toast.LENGTH_SHORT)
////                                .show();
//                    }
//
//                    @Override
//                    public void onRewardedVideoAdOpened()
//                    {
//                        // Showing Toast Message
////                        Toast
////                                .makeText(context,
////                                        "onRewardedVideoAdOpened",
////                                        Toast.LENGTH_SHORT)
////                                .show();
//                    }
//
//                    @Override
//                    public void onRewardedVideoStarted()
//                    {
//                        // Showing Toast Message
////                        Toast
////                                .makeText(context,
////                                        "onRewardedVideoStarted",
////                                        Toast.LENGTH_SHORT)
////                                .show();
//                    }
//
//                    @Override
//                    public void onRewardedVideoAdClosed()
//                    {
//                        // Showing Toast Message
////                        Toast
////                                .makeText(context,
////                                        "onRewardedVideoAdClosed",
////                                        Toast.LENGTH_SHORT)
////                                .show();
//                    }
//
//                    @Override
//                    public void onRewarded(
//                            RewardItem rewardItem)
//                    {
//                        // Showing Toast Message
////                        Toast
////                                .makeText(context,
////                                        "onRewarded",
////                                        Toast.LENGTH_SHORT)
////                                .show();
//                    }
//
//                    @Override
//                    public void
//                    onRewardedVideoAdLeftApplication()
//                    {
//                        // Showing Toast Message
////                        Toast
////                                .makeText(
////                                        context,
////                                        "onRewardedVideoAdLeftApplication",
////                                        Toast.LENGTH_SHORT)
////                                .show();
//                    }
//
//                    @Override
//                    public void onRewardedVideoAdFailedToLoad(
//                            int i)
//                    {
//                        // Showing Toast Message
////                        Toast
////                                .makeText(
////                                        context,
////                                        "onRewardedVideoAdFailedToLoad",
////                                        Toast.LENGTH_SHORT)
////                                .show();
//                    }
//
//                    @Override
//                    public void onRewardedVideoCompleted()
//                    {
//                        // Showing Toast Message
////                        Toast
////                                .makeText(
////                                        context,
////                                        "onRewardedVideoCompleted",
////                                        Toast.LENGTH_SHORT)
////                                .show();
//                    }
//                });
//
//        // Loading Rewarded Video Ad
//        AdMobrewardedVideoAd.loadAd(
//                getString(R.string.admob_rewarded_id), new AdRequest.Builder().build());
//    }
    }

    public void getNotificationPermission() {
        try {
            if (Build.VERSION.SDK_INT > 32) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        PERMISSION_REQUEST_CODE);
            } else {

            }
        } catch (Exception e) {

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                } else {
                    //deny
                    getNotificationPermission();
                }
        }
    }

    private void playerControls() {
        player.addListener(new Player.Listener() {
            @Override
            public void onMediaItemTransition(@Nullable MediaItem mediaItem, int reason) {
                //  Customprogress.showPopupProgressSpinner(context, false);
                Log.d("TAG!!!", "onMediaItemTransition");
                Player.Listener.super.onMediaItemTransition(mediaItem, reason);
                finalTime = player.getDuration();
                startTime = player.getCurrentPosition();
                binding.tvstart.setText(convertFormate((int) player.getCurrentPosition()));
                binding.seekBarAudio.setProgress((int) player.getCurrentPosition());
                binding.seekBarAudio.setMax((int) player.getDuration());
                binding.tvEnd.setText(convertFormate((int) player.getDuration()));
                updatePlayerPositionProgress();
                if (!player.isPlaying()) {
                    player.play();
                }
            }

            @Override
            public void onPlaybackStateChanged(int playbackState) {
//                Customprogress.showPopupProgressSpinner(context, false);
                try {
                    Customprogress.showPopupProgressSpinner(context, false);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Log.d("TAG!!!", "onPlaybackStateChanged");
                Player.Listener.super.onPlaybackStateChanged(playbackState);
                if (playbackState == ExoPlayer.STATE_READY) {
                    //  sendNotification();
                    Log.d("TAG!!!", "if  onPlaybackStateChanged");

                    finalTime = player.getDuration();
                    startTime = player.getCurrentPosition();
                    binding.tvstart.setText(convertFormate((int) player.getCurrentPosition()));
                    binding.tvEnd.setText(convertFormate((int) player.getDuration()));
                    binding.seekBarAudio.setProgress((int) player.getCurrentPosition());
                    binding.seekBarAudio.setMax((int) player.getDuration());
                    binding.seekBarAudio.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        int progressValue = 0;

                        @Override
                        public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                            progressValue = seekBar.getProgress();
                            if (progressValue == player.getDuration()) {
                                Log.d("TAG!!!!!", "progressValue == player.getDuration()");
                                player.seekTo(0);
                                player.setPlayWhenReady(true);
                                if (player.isPlaying()) {
                                } else {
                                }
                            }
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {
                            binding.ivPause.setVisibility(View.GONE);
                            binding.ivPlay.setVisibility(View.GONE);
                            binding.ivLoader.setVisibility(View.VISIBLE);

                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {
                            if (player.getPlaybackState() == ExoPlayer.STATE_READY) {
                                seekBar.setProgress(progressValue);
                                binding.tvstart.setText(convertFormate(progressValue));
                                player.seekTo(progressValue);
                                sendOnChannel(chapterList.get(positionChapterint).getChapterName(), otherDetail.getAuthorName(), positionChapterint);
                                if (player.isPlaying()) {

                                } else {
                                    Log.d("TAG>>>", "progressValue>>" + progressValue);

                                }
                            } else {

                            }
                        }
                    });
                    if (player.isPlaying()) {
                        binding.tvstart.setText(convertFormate((int) player.getCurrentPosition()));
                        binding.seekBarAudio.setProgress((int) player.getCurrentPosition());
                        binding.ivPause.setVisibility(View.GONE);
                        binding.ivPlay.setVisibility(View.VISIBLE);
                        binding.ivLoader.setVisibility(View.GONE);
                    } else {
                        binding.ivPause.setVisibility(View.VISIBLE);
                        binding.ivPlay.setVisibility(View.GONE);
                        binding.ivLoader.setVisibility(View.GONE);
                    }
                    updateTimeProgress();
                } else if (playbackState == ExoPlayer.STATE_ENDED) {
                    player.seekTo(0);
                    player.setPlayWhenReady(false);

                } else if (playbackState == ExoPlayer.STATE_BUFFERING) {

                    //  Toast.makeText(context, "Buffering", Toast.LENGTH_SHORT).show();
                } else if (playbackState == ExoPlayer.STATE_IDLE) {
                    //  Toast.makeText(context, "Preparing", Toast.LENGTH_SHORT).show();

                } else {
                    Log.d("TAG!!!", "else  onPlaybackStateChanged");
                    binding.seekBarAudio.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

                        int progressValue = 0;

                        @Override
                        public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                            progressValue = seekBar.getProgress();
                            if (progressValue == player.getDuration()) {
                                Log.d("TAG!!!!!", "progressValue == player.getDuration()");
                                player.seekTo(0);
                                player.setPlayWhenReady(true);
                                if (player.isPlaying()) {

                                } else {

                                }
                            }
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {
                            binding.ivPause.setVisibility(View.GONE);
                            binding.ivPlay.setVisibility(View.GONE);
                            binding.ivLoader.setVisibility(View.VISIBLE);
                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {
                            if (player.getPlaybackState() == ExoPlayer.STATE_READY) {
                                seekBar.setProgress(progressValue);
                                binding.tvstart.setText(convertFormate(progressValue));
                                player.seekTo(progressValue);
                                if (player.isPlaying()) {

                                } else {
                                    Log.d("TAG>>", "progressValue>>" + progressValue);

                                }
                            } else {

                            }
                        }
                    });
                    if (player.isPlaying()) {
                        binding.tvstart.setText(convertFormate((int) player.getCurrentPosition()));
                        binding.seekBarAudio.setProgress((int) player.getCurrentPosition());
                        binding.ivPause.setVisibility(View.GONE);
                        binding.ivPlay.setVisibility(View.VISIBLE);
                        binding.ivLoader.setVisibility(View.GONE);
                    } else {
                        binding.ivPause.setVisibility(View.VISIBLE);
                        binding.ivPlay.setVisibility(View.GONE);
                        binding.ivLoader.setVisibility(View.GONE);
                    }
                    updateTimeProgress();
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                Player.Listener.super.onPlayerError(error);
                Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onIsLoadingChanged(boolean isLoading) {
                Player.Listener.super.onIsLoadingChanged(isLoading);
                Log.d("TAG!!!!!!", "onIsLoadingChanged");

            }
        });
    }

    private void updatePlayerPositionProgress() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (player.isPlaying()) {
                    binding.tvstart.setText(convertFormate((int) player.getCurrentPosition()));
                    binding.seekBarAudio.setProgress((int) player.getCurrentPosition());
                    binding.ivPause.setVisibility(View.GONE);
                    binding.ivPlay.setVisibility(View.VISIBLE);
                    binding.ivLoader.setVisibility(View.GONE);
                } else {
                    binding.ivPause.setVisibility(View.VISIBLE);
                    binding.ivPlay.setVisibility(View.GONE);
                    binding.ivLoader.setVisibility(View.GONE);
                }
                updatePlayerPositionProgress();
            }
        }, 1000);
    }

    private void updateTimeProgress() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (player.isPlaying()) {
                    binding.tvstart.setText(convertFormate((int) player.getCurrentPosition()));
                    binding.seekBarAudio.setProgress((int) player.getCurrentPosition());
                } else {

                }
                updateTimeProgress();
            }
        }, 1000);
    }

    private String convertFormate(int duration) {
        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(duration),
                TimeUnit.MILLISECONDS.toSeconds(duration) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration)));
    }

    public void onclicks() {
        binding.llBack.setOnClickListener(this);
        binding.btnRead1.setOnClickListener(this);
        binding.ivRevert.setOnClickListener(this);
        binding.ivPrevious.setOnClickListener(this);
        binding.ivPlay.setOnClickListener(this);
        binding.ivPause.setOnClickListener(this);
        binding.ivNext.setOnClickListener(this);
        binding.ivFastforward.setOnClickListener(this);
        binding.llSpeed.setOnClickListener(this);
        binding.llshare.setOnClickListener(this);
        binding.ivExpandAudio.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llBack:
//                onBackPressed();
                if (stayedLongEnough) {
                    AdManager.getInstance().loadInterstitialAd(this);
                    onBackPressed();
                } else {
                    onBackPressed(); // Go back if the condition is not met
                }
                break;
            /*case R.id.iv_expand_audio:
                startActivity(new Intent(context, AudioActivity.class)
                        .putExtra("ChapterDetail", (Serializable) chapterDetail)
                        .putExtra("otherDetail", (Serializable) otherDetail)
                        .putExtra("chapterList", (Serializable) chapterList)
                        .putExtra("positionChapter", positionChapter));
                finish();
                break;*/
            case R.id.btnRead1:
                startActivity(new Intent(context, EbookActivity.class)
                                .putExtra("ChapterDetail", chapterDetail)
                                .putExtra("otherDetail", otherDetail)
                                .putExtra("chapterList", (Serializable) chapterList)
                                .putExtra("positionChapter", positionChapter)
                                .putExtra("FROM", "AudioBookActivity")

                        /*.putExtra("ChapterDetail", (Serializable) chapterList.get(positionChapterint))
                        .putExtra("otherDetail", (Serializable) otherDetail)
                        .putExtra("FROM","AudioBookActivity")*/
                );
                finish();
                break;

            case R.id.ivPlay:
                pause();
                break;

            case R.id.ivPause:
                play();
                break;


            case R.id.ivFastforward:
                startTime = player.getCurrentPosition();
                int temp = (int) startTime;
                Log.d("TAG123", "temp>>" + temp);
                Log.d("TAG123", "forwardTime>>" + forwardTime);
                if ((temp + forwardTime) <= finalTime) {
                    startTime = startTime + forwardTime;
                    binding.seekBarAudio.setProgress((int) startTime);
                    player.seekTo((int) startTime);
                    sendOnChannel(chapterList.get(positionChapterint).getChapterName(), otherDetail.getAuthorName(), positionChapterint);
                    Log.d("TAG123", "f_startTime>>" + startTime);
                    //   Toast.makeText(getApplicationContext(), "You have Jumped forward 30 seconds", Toast.LENGTH_SHORT).show();
                } else {
                    // Toast.makeText(getApplicationContext(), "Cannot jump forward 30 seconds", Toast.LENGTH_SHORT).show();
                }
                if (player.isPlaying()) {
                    binding.ivPause.setVisibility(View.GONE);
                    binding.ivPlay.setVisibility(View.VISIBLE);
                    binding.ivLoader.setVisibility(View.GONE);
                } else {
                    binding.ivPause.setVisibility(View.VISIBLE);
                    binding.ivPlay.setVisibility(View.GONE);
                    binding.ivLoader.setVisibility(View.GONE);
                }
                break;

            case R.id.ivRevert:
                startTime = player.getCurrentPosition();
                int temp1 = (int) startTime;
                if ((temp1 - backwardTime) > 0) {
                    startTime = startTime - backwardTime;
                    binding.seekBarAudio.setProgress((int) startTime);
                    player.seekTo((int) startTime);
                    sendOnChannel(chapterList.get(positionChapterint).getChapterName(), otherDetail.getAuthorName(), positionChapterint);
                    Log.d("TAG123", "startTime>>" + startTime);
                    // Toast.makeText(getApplicationContext(), "You have Jumped backward 30 seconds", Toast.LENGTH_SHORT).show();
                } else {
                    // Toast.makeText(getApplicationContext(), "Cannot jump backward 30 seconds", Toast.LENGTH_SHORT).show();
                }
                if (player.isPlaying()) {
                    binding.ivPause.setVisibility(View.GONE);
                    binding.ivPlay.setVisibility(View.VISIBLE);
                    binding.ivLoader.setVisibility(View.GONE);
                } else {
                    binding.ivPause.setVisibility(View.VISIBLE);
                    binding.ivPlay.setVisibility(View.GONE);
                    binding.ivLoader.setVisibility(View.GONE);
                }
                break;

            case R.id.llSpeed:
                showBottomSheetSpeedDialog();
                break;

            case R.id.ivPrevious:
                previous();
                break;

            case R.id.ivNext:
                next();
                break;
            case R.id.llshare:
                shareApp();
                //   new RetrivePDFfromUrl().execute(Allurls.IMAGEURL + chapterDetail.getPdf());
                break;
        }
    }

    private boolean isPlayStoreInstalled() {
        PackageManager packageManager = getPackageManager();
        Intent playStoreIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.gms"));
        List<ResolveInfo> list = packageManager.queryIntentActivities(playStoreIntent, PackageManager.MATCH_DEFAULT_ONLY);
        return list.size() > 0;
    }

    void shareApp() {
        // Check if the Play Store app is installed
        if (isPlayStoreInstalled()) {
            // Create an intent to open the app in the Play Store
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, "Check out this app: https://play.google.com/store/apps/details?id=" + "com.edutech.ncert");

            // Create a chooser dialog
            Intent chooser = Intent.createChooser(shareIntent, "Share via");

            // Verify if there are apps available to handle the intent
            if (shareIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(chooser);
            } else {
                // Handle the case where no apps can handle the share Intent
                Toast.makeText(this, "No apps can handle this share request", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Play Store is not installed, handle the situation accordingly
            Toast.makeText(this, "Google Play Store is not installed", Toast.LENGTH_SHORT).show();
        }
    }

   /* private void setPlayerScreen() {
        player = new ExoPlayer.Builder(context).build();
        DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(context,
                Util.getUserAgent(context, "BookSpeak"));
        MediaSource audioSource = new ProgressiveMediaSource.Factory(dataSourceFactory).
                createMediaSource(MediaItem.fromUri(Uri.parse(Allurls.IMAGEURL + chapterList.get(positionChapterint).getAudio())));
        player.prepare(audioSource);
        player.setPlayWhenReady(true);

        playerControls();
        if (chapterList.get(positionChapterint).getPdf() == null || chapterList.get(positionChapterint).getPdf().isEmpty()) {
            binding.btnRead1.setVisibility(View.GONE);
        }
        binding.tvChapter.setText(chapterList.get(positionChapterint).getChapterName());
        binding.tvChapterName1.setText(chapterList.get(positionChapterint).getChapterName());
        binding.tvAuthorName.setText(otherDetail.getAuthor_name());
        if (!chapterList.get(positionChapterint).getChapterImage().isEmpty()) {
            Picasso.get().load(Allurls.IMAGEURL + chapterList.get(positionChapterint).getChapterImage()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(binding.ivChapterImage);
        }
        binding.tvBookName.setText(otherDetail.getBookName());
        binding.tvBookAuthor.setText(otherDetail.getBookName() + "," + otherDetail.getAuthor_name());
    }*/

    private void showBottomSheetSpeedDialog() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context, R.style.CustomBottomSheetDialog);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_speed_layout);

        tvs25 = bottomSheetDialog.findViewById(R.id.tvs25);
        tvs5 = bottomSheetDialog.findViewById(R.id.tvs5);
        tvs75 = bottomSheetDialog.findViewById(R.id.tvs75);
        tvNormal = bottomSheetDialog.findViewById(R.id.tvNormal);
        tv25 = bottomSheetDialog.findViewById(R.id.tv25);
        tv5 = bottomSheetDialog.findViewById(R.id.tv5);
        tv75 = bottomSheetDialog.findViewById(R.id.tv75);
        tv2 = bottomSheetDialog.findViewById(R.id.tv2);

        tvs25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (player != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "0.25X Speed";
                        player.setPlaybackSpeed((0.25f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
                }
            }
        });

        tvs5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (player != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "0.5X Speed";
                        player.setPlaybackSpeed(0.5f);
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
                }
            }
        });

        tvs75.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (player != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "0.75X Speed";
                        player.setPlaybackSpeed((0.75f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
                }
            }
        });

        tvNormal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (player != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "1X Speed";
                        player.setPlaybackSpeed((1f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
                }
            }
        });

        tv25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (player != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "1.25X Speed";
                        player.setPlaybackSpeed((1.25f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
                }
            }
        });

        tv5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (player != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "1.5X Speed";
                        player.setPlaybackSpeed((1.5f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
                }
            }
        });
        tv75.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (player != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "1.75X Speed";
                        player.setPlaybackSpeed((1.75f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
                }
            }
        });
        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (player != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        speedValue = "2X Speed";
                        player.setPlaybackSpeed((2f));
                        binding.tvSpeed.setText(speedValue);
                        bottomSheetDialog.dismiss();
                    }
                }
            }
        });
        bottomSheetDialog.show();
    }

    private void clearMediaPlayer() {
        player.stop();
        player.release();
        player = null;
    }

    public static AudiobookActivity getInstance() {
        return instance;
    }

    public int getPosition() {
        return position;
    }

    public void play() {
        if (player != null && !player.isPlaying()) {
            playin = true;
            player.play();
            binding.ivPause.setVisibility(View.GONE);
            binding.ivPlay.setVisibility(View.VISIBLE);
            binding.ivLoader.setVisibility(View.GONE);
            sendOnChannel(chapterList.get(positionChapterint).getChapterName(), otherDetail.getAuthorName(), positionChapterint);

        } else {
            pause();
        }
    }

    public void stop() {
        Log.d("TAG!!123", "stop");
        if (player != null) {
            playin = false;
            player.stop();
            player.release();
        } else {

        }
    }

    public void pause() {
        if (player != null) {
            if (player.isPlaying()) {
                playin = false;
                player.pause();
                binding.ivPause.setVisibility(View.VISIBLE);
                binding.ivPlay.setVisibility(View.GONE);
                binding.ivLoader.setVisibility(View.GONE);
                sendOnChannel(chapterList.get(positionChapterint).getChapterName(), otherDetail.getAuthorName(), positionChapterint);
            } else {
                Log.d("TAG!!", "pause..");
            }
        } else {
            Log.d("TAG!!", "pause");
        }
    }

    public void previous() {
        speedValue = "1X Speed";
        binding.tvSpeed.setText(speedValue);
        Log.d("TAG123", "_positionChapterint>>" + positionChapterint);
        positionChapterint = positionChapterint - 1;
        Log.d("TAG123", "_positionChapterint>>>" + positionChapterint);
        if (positionChapterint >= 0) {
            Log.d("TAG123", "positionChapterint>>" + positionChapterint);
            if (chapterList.get(positionChapterint).getAudio() != null || chapterList.get(positionChapterint).getUrl() != null) {
                if (!chapterList.get(positionChapterint).getAudio().isEmpty()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    clearMediaPlayer();
                    initPlayer(positionChapterint);
                    binding.ivNextGray.setVisibility(View.GONE);
                    binding.ivNext.setVisibility(View.VISIBLE);
                    Log.d("TAG123", "positionChapterint>>>" + positionChapterint);
                } else if (!chapterList.get(positionChapterint).getUrl().isEmpty()) {
                    Customprogress.showPopupProgressSpinner(context, true);
                    clearMediaPlayer();
                    initPlayer(positionChapterint);
                    binding.ivNextGray.setVisibility(View.GONE);
                    binding.ivNext.setVisibility(View.VISIBLE);
                    Log.d("TAG123", "positionChapterint>>>" + positionChapterint);
                } else {
                    positionChapterint = positionChapterint + 1;
                    binding.ivGrayPrevious.setVisibility(View.VISIBLE);
                    binding.ivPrevious.setVisibility(View.GONE);
                    Toast.makeText(context, "audio not available", Toast.LENGTH_SHORT).show();
//                    try {
//                        for(int i=positionChapterint;i<chapterList.size();i--){
//
//                            if (!chapterList.get(i).getAudio().isEmpty()) {
//                                positionChapterint = positionChapterint - 1;
//                                break;
//                            }
//
//                        }
//                    }catch (Exception e){
//                        e.printStackTrace();
//                        positionChapterint = positionChapterint + 1;
//                    binding.ivGrayPrevious.setVisibility(View.VISIBLE);
//                    binding.ivPrevious.setVisibility(View.GONE);
//                    }
//
////                    positionChapterint = positionChapterint - 1;
//                    clearMediaPlayer();
//                    initPlayer(positionChapterint);
//                    binding.ivNextGray.setVisibility(View.GONE);
//                    binding.ivNext.setVisibility(View.VISIBLE);
//                    Toast.makeText(context, "play prev", Toast.LENGTH_SHORT).show();
                }
            }

        } else {
            positionChapterint = positionChapterint + 1;
            binding.ivGrayPrevious.setVisibility(View.VISIBLE);
            binding.ivPrevious.setVisibility(View.GONE);
            Toast.makeText(context, "audio not available", Toast.LENGTH_SHORT).show();
        }
    }

    public void next() {
        speedValue = "1X Speed";
        binding.tvSpeed.setText(speedValue);
        Log.d("TAG123", "positionChapterint>>" + positionChapterint);
        positionChapterint = positionChapterint + 1;
        Log.d("TAG123", "positionChapterint>>>" + positionChapterint);
        int s = chapterList.size() - 1;
        Log.d("TAG123", "chapterList.size() - 1>>" + s);
        if (positionChapterint <= chapterList.size() - 1) {
            if (chapterList.get(positionChapterint).getAudio() != null || chapterList.get(positionChapterint).getUrl() != null) {
                if (!chapterList.get(positionChapterint).getAudio().isEmpty()) {
                    Customprogress.showPopupProgressSpinner(context, true);
                    clearMediaPlayer();
                    initPlayer(positionChapterint);
                    binding.ivGrayPrevious.setVisibility(View.GONE);
                    binding.ivPrevious.setVisibility(View.VISIBLE);
                } else if (!chapterList.get(positionChapterint).getUrl().isEmpty()) {
                    Customprogress.showPopupProgressSpinner(context, true);
                    clearMediaPlayer();
                    initPlayer(positionChapterint);
                    binding.ivGrayPrevious.setVisibility(View.GONE);
                    binding.ivPrevious.setVisibility(View.VISIBLE);
                } else {
                    positionChapterint = positionChapterint - 1;
                    binding.ivNextGray.setVisibility(View.VISIBLE);
                    binding.ivNext.setVisibility(View.GONE);
                    Toast.makeText(context, "audio not available", Toast.LENGTH_SHORT).show();
//                    try{
//                        for(int i=positionChapterint;i<chapterList.size();i++){
//                            positionChapterint = positionChapterint + 1;
//                            if (!chapterList.get(positionChapterint).getAudio().isEmpty()) {
//
//                                break;
//                            }
//
//                        }
//                    }catch (Exception e){
//                        e.printStackTrace();
//                        positionChapterint = positionChapterint - 1;
//                    binding.ivNextGray.setVisibility(View.VISIBLE);
//                    binding.ivNext.setVisibility(View.GONE);
//                    }

//                    clearMediaPlayer();
//                    initPlayer(positionChapterint);
//                    binding.ivGrayPrevious.setVisibility(View.GONE);
//                    binding.ivPrevious.setVisibility(View.VISIBLE);
//                    Toast.makeText(context, "play nxt", Toast.LENGTH_SHORT).show();

                }
            }


        } else {
            positionChapterint = positionChapterint - 1;
            binding.ivNextGray.setVisibility(View.VISIBLE);
            binding.ivNext.setVisibility(View.GONE);
            Toast.makeText(context, "audio not available", Toast.LENGTH_SHORT).show();
        }
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public void sendOnChannel(String name, String artist, int position) {
        newPosition = String.valueOf(position);
        //  Intent activityIntent = new Intent(AudiobookActivity.this, HomeActivity.class);
//        Intent activityIntent = new Intent(context, AudiobookActivity.class)
//                .putExtra("ChapterDetail", (Serializable) chapterList.get(position))
//                .putExtra("otherDetail", (Serializable) otherDetail)
//                .putExtra("chapterList", (Serializable) chapterList)
//                .putExtra("positionChapter", newPosition);
//        Log.d("TAG!!12", "positionChapter>>>" + positionChapter);
//        PendingIntent contentIntent = PendingIntent.getActivity(context,
//                0, activityIntent, PendingIntent.FLAG_IMMUTABLE);
        PendingIntent notifyPIntent =
                PendingIntent.getActivity(getApplicationContext(), 0, new Intent(), PendingIntent.FLAG_IMMUTABLE);

        int plaorpa;
        if (AudiobookActivity.playin) {
            plaorpa = R.drawable.baseline_pause_circle_outline_24;
        } else {
            plaorpa = R.drawable.baseline_play_circle_outline_24;
        }
      /*  metadataRetriever = new MediaMetadataRetriever();
        metadataRetriever.setDataSource("https://www.learningcontainer.com/wp-content/uploads/2020/02/Kalimba.mp3");*/
        //  arts= metadataRetriever.getEmbeddedPicture();
        Bitmap artwork;
        artwork = BitmapFactory.decodeResource(getResources(), R.drawable.ic_logo_blue);
//        notification = new NotificationCompat.Builder(this, channel_1_ID)
//                .setSmallIcon(R.drawable.ic_logo_blue)
//                .setContentTitle(name)
//                .setContentText(artist)
//                .setLargeIcon(artwork)
//                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
//                .setOnlyAlertOnce(true)
//                //.addAction(R.drawable.baseline_skip_previous_24, "Previous", playbackAction(3))
//                .addAction(plaorpa, playin ? "Pause" : "Play", playbackAction(1))
//                //.addAction(R.drawable.baseline_skip_next_24, "Next", playbackAction(2))
//                .setContentIntent(notifyPIntent)
//                .setStyle(new androidx.media.app.NotificationCompat.MediaStyle())
//                .setSubText(artist)
//                .setOngoing(true)
//                .setPriority(NotificationCompat.PRIORITY_MAX)
//                .build();
        notification = new NotificationCompat.Builder(this, channel_1_ID)
                .setSmallIcon(R.drawable.ic_logo_blue)
                .setContentTitle(name)
                .setContentText(artist)
                .setLargeIcon(artwork)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .addAction(R.drawable.baseline_skip_previous_24, "Previous", playbackAction(3))
                .addAction(plaorpa, playin ? "Pause" : "Play", playbackAction(1))
                .addAction(R.drawable.baseline_skip_next_24, "Next", playbackAction(2))
                .setContentIntent(notifyPIntent)
                .setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
                        .setMediaSession(mediaSession.getSessionToken()))
                .setSubText(artist)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .build();

        MediaMetadataCompat.Builder mediaMetaData_builder = new MediaMetadataCompat.Builder();

        mediaMetaData_builder.putLong(MediaMetadataCompat.METADATA_KEY_DURATION, player.getDuration());

        PlaybackStateCompat.Builder builder = new PlaybackStateCompat.Builder();
        builder.setState(AudiobookActivity.playin ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED, player.getCurrentPosition(), 1.0f);
        builder.setActions(
                PlaybackStateCompat.ACTION_PLAY |
                        PlaybackStateCompat.ACTION_STOP |
                        PlaybackStateCompat.ACTION_PAUSE |
                        PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS |
                        PlaybackStateCompat.ACTION_SKIP_TO_NEXT);
        mediaSession.setMetadata(mediaMetaData_builder.build());
        mediaSession.setPlaybackState(builder.build());
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            notificationManager.notify(1, notification);
        }else {
            notificationManager.notify(1, notification);
        }
    }

    private PendingIntent playbackAction(int actionNumber) {
        Intent playbackAction = new Intent(this, NotiService.class);
        switch (actionNumber) {
            case 1:
                // Pause
                playbackAction.setAction("com.edutech.ncert.ACTION_PAUSE_MUSIC");
                return PendingIntent.getService(this, actionNumber, playbackAction, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT);
            case 2:
                // Next track
                playbackAction.setAction("com.edutech.ncert.ACTION_NEXT_MUSIC");
                return PendingIntent.getService(this, actionNumber, playbackAction, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT);
            case 3:
                // Previous track
                playbackAction.setAction("com.edutech.ncert.ACTION_PREV_MUSIC");
                return PendingIntent.getService(this, actionNumber, playbackAction, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT);
            default:
                break;
        }
        return null;
    }

    public void initPlayer(final int p) {
        playin = true;
        player = new ExoPlayer.Builder(context).build();
        Log.d("TAG!!!!!!!", "p>>" + p);

        if (!chapterList.get(p).getAudio().isEmpty()) {
            DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(context,
                    Util.getUserAgent(context, "BookSpeak"));
            MediaSource audioSource = new ProgressiveMediaSource.Factory(dataSourceFactory).
                    createMediaSource(MediaItem.fromUri(Uri.parse(Allurls.IMAGEURL + chapterList.get(p).getAudio())));
            player.prepare(audioSource);
            player.setPlayWhenReady(false);
        } else if (!chapterList.get(p).getUrl().isEmpty()) {
            String url = "";
            if (chapterList.get(p).getUrl().contains("https://")) {
                url = chapterList.get(p).getUrl();
            } else {
                url = Allurls.IMAGEURL + chapterList.get(p).getUrl();
            }
            Log.d("TAG!!123", "url>>" + url);
            DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(context,
                    Util.getUserAgent(context, "BookSpeak"));
            MediaSource audioSource = new ProgressiveMediaSource.Factory(dataSourceFactory).
                    createMediaSource(MediaItem.fromUri(Uri.parse(url)));
            player.prepare(audioSource);
            player.setPlayWhenReady(false);
        }
        binding.ivPause.setVisibility(View.GONE);
        binding.ivPlay.setVisibility(View.GONE);
        binding.ivLoader.setVisibility(View.VISIBLE);
        playerControls();

        if (chapterList.get(p).getPdf() == null || chapterList.get(p).getPdf().isEmpty()) {
            if (chapterList.get(p).getPdfUrl() == null || chapterList.get(p).getPdfUrl().isEmpty()) {
                binding.btnRead1.setVisibility(View.GONE);
            }else{
                binding.btnRead1.setVisibility(View.VISIBLE);
            }

        }else {
            binding.btnRead1.setVisibility(View.VISIBLE);
        }
        binding.tvChapter.setText(chapterList.get(p).getChapterName());
        binding.tvChapterName1.setText(chapterList.get(p).getChapterName());
        binding.tvAuthorName.setText(otherDetail.getAuthorName());
        if (chapterList.get(p).getChapterImage() != null) {
            if (!chapterList.get(p).getChapterImage().isEmpty()) {
                Picasso.get().load(Allurls.IMAGEURL + chapterList.get(p).getChapterImage()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(binding.ivChapterImage);
            }
        }
        binding.tvBookName.setText(otherDetail.getBookName());
        binding.tvBookAuthor.setText(otherDetail.getBookName() + "," + otherDetail.getAuthorName());
        handler.postDelayed(new Runnable() {
            public void run() {
                // yourMethod();
                sendOnChannel(chapterList.get(p).getChapterName(), otherDetail.getAuthorName(), p);
            }
        }, 2000);
//        sendOnChannel(chapterList.get(p).getChapterName(), otherDetail.getAuthorName(), p);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        /*if (stayedLongEnough) {
            AdManager.getInstance().loadInterstitialAd(this);
            super.onBackPressed();
//            Toast.makeText(this, "You stayed for 2 minutes!", Toast.LENGTH_SHORT).show();
        } else {
            super.onBackPressed(); // Go back if the condition is not met
        }*/
        if (player != null && player.isPlaying()) {
            Log.d("TAG!!!!!", "onBack >>player != null && player.isPlaying()");
            player.seekTo(0);
            player.setPlayWhenReady(false);

        }

//        onButtonClick();
        notificationManager.cancel(1);
        handler.removeCallbacksAndMessages(null);
        if (player!=null) {
            player.stop();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        /*if (player!=null){
            player.play();
        }*/
    }

    @Override
    protected void onStop() {
        super.onStop();
//        if (player!=null){
//            player.release();
//        }
    }

    @Override
    protected void onPause() {
        super.onPause();
//        if (player!=null){
//            player.pause();
//        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player!=null){
            player.release();

        }
        interstitialHandler.removeCallbacks(runnable);

    }
}

package com.edutech.ncert.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ListItemClassBinding;
import com.edutech.ncert.model.MediumModel.Medium;

import java.util.List;

public class MediumListAdapter extends RecyclerView.Adapter<MediumListAdapter.RecyclerViewHolder> {
    Context context;
    List<Medium> list;
    int selectPosition = -1;
    ItemClick itemClick;

    public MediumListAdapter(Context context, List<Medium> list, ItemClick itemClick) {
        this.context = context;
        this.list = list;
        this.itemClick = itemClick;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item_class, parent, false);
        RecyclerViewHolder recyclerViewHolder = new RecyclerViewHolder(view);
        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Medium medium = list.get(position);

        holder.binding.tvTitle.setText(medium.getMedium());

        // Load the image using Glide
        Glide.with(context)
                .load(medium.getImage() != null ? "https://ncert.schooltopper.in/public/"+medium.getImage() : "https://ncert.schooltopper.in/public/uploads/book/ic_launcher.png")
                .placeholder(R.drawable.ic_splash_logo) // Optional placeholder
                .error(R.drawable.ic_splash_logo) // Optional error placeholder
                .into(holder.binding.ivClassImage); // Assuming you have an ImageView with id `ivImage`

//        if (selectPosition == position) {
//            holder.binding.llMain.setBackgroundResource(R.drawable.bg_gradient_card);
//            holder.binding.ivArrow.setColorFilter(context.getResources().getColor(R.color.white));
//            holder.binding.tvTitle.setTextColor(context.getResources().getColor(R.color.white));
//        } else {
//            int[] backgrounds = new int[]{R.drawable.bg_gradient_1, R.drawable.bg_gradient_2, R.drawable.bg_gradient_3, R.drawable.bg_gradient_4, R.drawable.bg_gradient_5};
//            int background = backgrounds[position % backgrounds.length];
//            holder.binding.llMain.setBackgroundResource(background);
//
//            holder.binding.ivArrow.setColorFilter(context.getResources().getColor(R.color.txt_blue));
//            holder.binding.tvTitle.setTextColor(context.getResources().getColor(R.color.black));
//        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectPosition = position;
                itemClick.onItemClick(position, "_Medium");
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private final ListItemClassBinding binding;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ListItemClassBinding.bind(itemView);
        }
    }
}

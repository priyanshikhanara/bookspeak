package com.edutech.ncert.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.adapter.BookListAdapter;
import com.edutech.ncert.adapter.BookListGridAdapter;
import com.edutech.ncert.databinding.ActivityChooseBookBinding;
import com.edutech.ncert.model.BookModel.BookParaRes;
import com.edutech.ncert.model.BookModel.BookRes;
import com.edutech.ncert.model.BookModel.Datum;
import com.edutech.ncert.model.LikeModel.LikeParaRes;
import com.edutech.ncert.model.LikeModel.LikeRes;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChooseBookActivity extends AppCompatActivity implements View.OnClickListener{
    Context context;
    private ActivityChooseBookBinding binding;
    String subject,class_id,medium_id,subject_id,subject_name,medium,class_name;
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private MySharedPref mySharedPref;
    boolean isGrid = false;
    List<Datum> bookListResponse;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChooseBookBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
    }

    private void changeStatusBarColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(context, R.color.txt_blue));
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        init();
        onclicks();
    }

    public void init() {
        context = ChooseBookActivity.this;
        mySharedPref = new MySharedPref(context);
        changeStatusBarColor();
        jsonPlaceHolderApi = ApiUtils.getAPIService();

//        binding.ivGridView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                isGrid = true;
//                binding.ivGridView.setVisibility(View.GONE);
//                binding.ivListView.setVisibility(View.VISIBLE);
//                try {
//                    setBookData(bookListResponse);
//                }catch (Exception e){
//                    e.printStackTrace();
//                }
//
//            }
//        });
//        binding.ivListView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                isGrid = false;
//                binding.ivGridView.setVisibility(View.VISIBLE);
//                binding.ivListView.setVisibility(View.GONE);
//                try {
//                    setBookData(bookListResponse);
//                }catch (Exception e){
//                    e.printStackTrace();
//                }
//
//            }
//        });

        MobileAds.initialize(context, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        binding.adView.loadAd(adRequest);
        if(mySharedPref.getSavedBannerAddsStatus().equals("Yes")){
            binding.btnAdsShow.setVisibility(View.VISIBLE);
        }else{
            binding.btnAdsShow.setVisibility(View.GONE);
        }

        Intent intent = getIntent();
        if (intent != null) {
            subject = intent.getStringExtra("title");
            class_id = intent.getStringExtra("class_id");
            medium_id = intent.getStringExtra("medium_id");
            subject_id = intent.getStringExtra("subject_id");
            Log.d("TAG", subject);
        }
        binding.tvSubjectName.setText(subject);

        if (Constants.isInternetConnected(context)) {
            GetBookAPI();
        } else {
            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
        }
    }

    public void onclicks() {
        binding.llBack.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llBack:
                onBackPressed();
                break;
        }
    }

    public void GetBookAPI() {
        Customprogress.showPopupProgressSpinner(context, false);
        BookParaRes bookParaRes = new BookParaRes();
        bookParaRes.setUserId(mySharedPref.getSavedUserid());
        bookParaRes.setClassId(class_id);
        bookParaRes.setMediumId(medium_id);
        bookParaRes.setSubjectId(subject_id);

        jsonPlaceHolderApi.GetBookAPI("application/json", "application/json", bookParaRes).enqueue(new Callback<BookRes>() {
            @Override
            public void onResponse(Call<BookRes> call, Response<BookRes> response) {
                if (response.isSuccessful()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {
                        // Dynamically set class name, subject name, and medium
                        class_name = response.body().getOtherDetail().getClassName();
                        subject_name = response.body().getOtherDetail().getSubjectName();
                        medium = response.body().getOtherDetail().getMediumName();

                        // Set the class, subject, and medium names to their respective TextViews
                        binding.tvClassName.setText(class_name);  // Set class name dynamically
                        binding.tvSubjectName.setText(subject_name);  // Set subject name dynamically
                        binding.tvMedium.setText(medium);  // Set medium dynamically

                        bookListResponse = response.body().getData();
                        setBookData(response.body().getData());
                    } else {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        binding.rvBook.setVisibility(View.GONE);
                        binding.llNoData.setVisibility(View.VISIBLE);
                    }
                } else {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Log.d("TAG", ">>" + response.message());
                    binding.rvBook.setVisibility(View.GONE);
                    binding.llNoData.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<BookRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
                binding.rvBook.setVisibility(View.GONE);
                binding.llNoData.setVisibility(View.VISIBLE);
            }
        });
    }


    private void setBookData(List<Datum> bookList) {
        if (bookList.size() != 0) {
            binding.rvBook.setVisibility(View.VISIBLE);
            binding.llNoData.setVisibility(View.GONE);


            if(isGrid){

                BookListGridAdapter adapter = new BookListGridAdapter(context, bookList, new ItemClick() {
                    @Override
                    public void onItemClick(int position, String type) {
                        if(type.equals("likeUnlike")){
                            if (Constants.isInternetConnected(context)) {
                                LikeAPI(bookList.get(position).getId().toString());
                            } else {
                                Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                            }
                        }else{
                            startActivity(new Intent(context, ChooseChapterActivity.class)
                                    .putExtra("title",bookList.get(position).getName())
                                    .putExtra("class_id",class_id)
                                    .putExtra("book_id",bookList.get(position).getId().toString())
                                    .putExtra("subject_name",subject_name)
                                    .putExtra("medium",medium)
                                    .putExtra("class_name",class_name)
                            );
                        }
                    }
                });

                binding.rvBook.setHasFixedSize(true);
                binding.rvBook.setLayoutManager(new GridLayoutManager(context,2));
                binding.rvBook.setAdapter(adapter);
            }else{

                BookListAdapter adapter = new BookListAdapter(context, bookList, new ItemClick() {
                    @Override
                    public void onItemClick(int position, String type) {
                        if(type.equals("likeUnlike")){
                            if (Constants.isInternetConnected(context)) {
                                LikeAPI(bookList.get(position).getId().toString());
                            } else {
                                Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                            }
                        }else{
                            startActivity(new Intent(context, ChooseChapterActivity.class)
                                    .putExtra("title",bookList.get(position).getName())
                                    .putExtra("class_id",class_id)
                                    .putExtra("book_id",bookList.get(position).getId().toString())
                                    .putExtra("subject_name",subject_name)
                                    .putExtra("medium",medium)
                                    .putExtra("class_name",class_name)
                            );
                        }
                    }
                });

                binding.rvBook.setHasFixedSize(true);
                binding.rvBook.setLayoutManager(new LinearLayoutManager(context));
                binding.rvBook.setAdapter(adapter);
                binding.rvBook.setLayoutAnimation(AnimationUtils.loadLayoutAnimation(context, R.anim.layout_animation_fall_down));

            }

        } else {
            binding.rvBook.setVisibility(View.GONE);
            binding.llNoData.setVisibility(View.VISIBLE);
        }
    }

    public void LikeAPI(String bookId) {
        Customprogress.showPopupProgressSpinner(context, false);
        LikeParaRes likeParaRes = new LikeParaRes();
        likeParaRes.setBookId(bookId);
        jsonPlaceHolderApi.LikeAPI("application/json", "application/json", "Bearer " + mySharedPref.getSavedAccessToken(),likeParaRes).enqueue(new Callback<LikeRes>() {
            @Override
            public void onResponse(Call<LikeRes> call, Response<LikeRes> response) {

                if (response.isSuccessful()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {
                        if (Constants.isInternetConnected(context)) {
                            GetBookAPI();
                        } else {
                            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                        }
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    } else {
                        if (Constants.isInternetConnected(context)) {
                            GetBookAPI();
                        } else {
                            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                        }
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<LikeRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
            }
        });
    }
}
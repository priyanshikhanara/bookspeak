
package com.edutech.ncert.model.MediumModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MediumParaRes {

    @SerializedName("user_id")
    @Expose
    private String userId;

    @SerializedName("class_id")
    @Expose
    private String classId;

    @SerializedName("fcm_token")
    @Expose
    private String fcmToken;

    @SerializedName("device_id")
    @Expose
    private String deviceId;

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
    public String getFcmToken() {
        return fcmToken;
    }

    public void setFcmToken(String fcmToken) {
        this.fcmToken = fcmToken;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

}

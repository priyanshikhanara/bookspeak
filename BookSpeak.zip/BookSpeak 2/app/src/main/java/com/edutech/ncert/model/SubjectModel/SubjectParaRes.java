
package com.edutech.ncert.model.SubjectModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SubjectParaRes {

    @SerializedName("class_id")
    @Expose
    private String classId;
    @SerializedName("medium_id")
    @Expose
    private String mediumId;

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public String getMediumId() {
        return mediumId;
    }

    public void setMediumId(String mediumId) {
        this.mediumId = mediumId;
    }

}

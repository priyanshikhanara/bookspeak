package com.edutech.ncert.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.server.Allurls;

import java.util.List;

public class Sliding_adapter extends PagerAdapter {
    private final LayoutInflater inflater;
    Context context;
    ViewPager viewPager;
    List<String> imageList;
    ItemClick itemClick;

    public Sliding_adapter(Context context, ViewPager viewPager, List<String> imageList,ItemClick itemClick) {
        this.context = context;
        this.viewPager = viewPager;
        this.imageList = imageList;
        this.itemClick = itemClick;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        if(imageList.size() >= 5){
            return 5;
        }else{
            return imageList.size();
        }
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @SuppressLint("ResourceType")
    @NonNull
    @Override
    public Object instantiateItem(@NonNull final ViewGroup container, int position) {
        View imageLayout = inflater.inflate(R.layout.dialog_slider_list, container, false);

        if (imageLayout != null)
        {
            AppCompatImageView imageView = imageLayout.findViewById(R.id.img_banner);
//            Picasso.get().load(Allurls.IMAGEURL+imageList.get(position)).error(R.drawable.default_banner).placeholder(R.drawable.default_banner).into(imageView);

//            Glide.with(context).load(Allurls.IMAGEURL+imageList.get(position)).error(R.drawable.default_banner).placeholder(R.drawable.default_banner).into(imageView);
            Glide.with(context)
                    .load(Allurls.IMAGEURL + imageList.get(position))
                    .centerCrop()
                    .placeholder(R.drawable.default_banner)
                    .error(R.drawable.default_banner)
                    .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.AUTOMATIC)
                    .into(imageView);


          //  imageView.setImageResource(R.drawable.slider1);
            container.addView(imageLayout, 0);

            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    itemClick.onItemClick(position,"url");
                }
            });
        }

        return imageLayout;
    }


    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view.equals(object);
    }
}

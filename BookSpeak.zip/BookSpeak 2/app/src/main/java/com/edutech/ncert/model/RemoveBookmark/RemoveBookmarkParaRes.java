package com.edutech.ncert.model.RemoveBookmark;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RemoveBookmarkParaRes {

    @SerializedName("bookmark_id")
    @Expose
    private String bookmarkId;

    public String getBookmarkId() {
        return bookmarkId;
    }

    public void setBookmarkId(String bookmarkId) {
        this.bookmarkId = bookmarkId;
    }

}

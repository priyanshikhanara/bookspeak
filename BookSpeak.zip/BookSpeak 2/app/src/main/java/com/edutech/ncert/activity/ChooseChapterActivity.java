package com.edutech.ncert.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.adapter.ChapterListAdapter;
import com.edutech.ncert.databinding.ActivityChooseChapterBinding;
import com.edutech.ncert.model.AddBookmark.AddBookmarkParaRes;
import com.edutech.ncert.model.AddBookmark.AddBookmarkRes;
import com.edutech.ncert.model.ChapterModel.ChapterParaRes;
import com.edutech.ncert.model.ChapterModel.ChapterRes;
import com.edutech.ncert.model.ChapterModel.Datum;
import com.edutech.ncert.model.ChapterModel.OtherDetail;
import com.edutech.ncert.model.RemoveBookmark.RemoveBookmarkParaRes;
import com.edutech.ncert.model.RemoveBookmark.RemoveBookmarkRes;
import com.edutech.ncert.server.Allurls;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.AdManager;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.squareup.picasso.Picasso;

import java.io.Serializable;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class ChooseChapterActivity extends AppCompatActivity implements View.OnClickListener {
    final int PERMISSION_REQUEST_CODE = 112;
    Context context;
    AdManager adManager;
    private ActivityChooseChapterBinding binding;
    String book, class_id, book_id, subject_name, medium, class_name;
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private MySharedPref mySharedPref;
    InterstitialAd interstitial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChooseChapterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
    }

    private void changeStatusBarColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(context, R.color.txt_blue));
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        init();
        onclicks();
    }

    /*    public void getNotificationPermission() {
            try {
                if (Build.VERSION.SDK_INT > 32) {
                    ActivityCompat.requestPermissions(this,
                            new String[]{Manifest.permission.POST_NOTIFICATIONS},
                            PERMISSION_REQUEST_CODE);
                } else {

                }
            } catch (Exception e) {

            }
        }

        @Override
        public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            switch (requestCode) {
                case PERMISSION_REQUEST_CODE:
                    // If request is cancelled, the result arrays are empty.
                    if (grantResults.length > 0 &&
                            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    } else {
                        //deny
                        getNotificationPermission();
                    }
                    return;
            }
        }*/
    public void init() {
        adManager = AdManager.getInstance();
        adManager.loadInterstitial(this);

        context = ChooseChapterActivity.this;
        //  getNotificationPermission();
        changeStatusBarColor();
        jsonPlaceHolderApi = ApiUtils.getAPIService();
        mySharedPref = new MySharedPref(context);
//        AdManager.getInstance().loadInterstitialAd(ChooseChapterActivity.this);
//        loadInterstitialAds();
        MobileAds.initialize(context, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        binding.adView.loadAd(adRequest);
        if(mySharedPref.getSavedBannerAddsStatus().equals("Yes")){
            binding.btnAdsShow.setVisibility(View.VISIBLE);
        }else{
            binding.btnAdsShow.setVisibility(View.GONE);
        }

        Intent intent = getIntent();
        if (intent != null) {
            book = intent.getStringExtra("title");
            class_id = intent.getStringExtra("class_id");
            book_id = intent.getStringExtra("book_id");
            subject_name = intent.getStringExtra("subject_name");
            medium = intent.getStringExtra("medium");
            class_name = intent.getStringExtra("class_name");
            Log.d("TAG", book);
            binding.tvClassName.setText(class_name);
        }

        binding.tvBookName.setText(book);

        if (Constants.isInternetConnected(context)) {
            GetChapterAPI();
        } else {
            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
        }
    }


    public void onclicks() {
        binding.llBack.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llBack:
                onBackPressed();
                break;
        }
    }

    public void GetChapterAPI() {
        Customprogress.showPopupProgressSpinner(context, false);
        ChapterParaRes chapterParaRes = new ChapterParaRes();
        chapterParaRes.setUserId(mySharedPref.getSavedUserid());
        chapterParaRes.setClassId(class_id);
        chapterParaRes.setBookId(book_id);

        jsonPlaceHolderApi.GetChapterAPI("application/json", "application/json", chapterParaRes).enqueue(new Callback<ChapterRes>() {
            @Override
            public void onResponse(Call<ChapterRes> call, Response<ChapterRes> response) {
                if (response.isSuccessful()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {
                        if (!response.body().getOtherDetail().getBookImage().equals("")) {
                            Picasso.get().load(Allurls.IMAGEURL + response.body().getOtherDetail().getBookImage()).error(R.drawable.default_img).placeholder(R.drawable.default_img).into(binding.ivBookImage);
                        }
                        binding.tvBookName.setText(response.body().getOtherDetail().getBookName());
                        binding.tvSubjectName.setText(subject_name);
                        binding.tvMedium.setText(medium);
                        setChapterData(response.body().getData(), response.body().getOtherDetail());
                    } else {
                        binding.rvChapter.setVisibility(View.GONE);
                        binding.llNoData.setVisibility(View.VISIBLE);
                        //  Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Log.d("TAG", ">>" + response.message());
                    binding.llNoData.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<ChapterRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
                binding.llNoData.setVisibility(View.VISIBLE);
            }
        });
    }

//    void  loadInterstitialAds(){
//        Customprogress.showPopupProgressSpinner(context,true);
//
//        AdRequest adRequest = new AdRequest.Builder().build();
//
//        interstitial = new InterstitialAd(context);
//
//        // Set the Ad Unit ID
//        interstitial.setAdUnitId(getString(R.string.admob_interstitial_id));
//
//        // Load the Interstitial Ad
//        interstitial.loadAd(adRequest);
//
//        // Prepare an Interstitial Ad Listener
//        interstitial.setAdListener(new AdListener() {
//            @Override
//            public void onAdLoaded() {
//                // Call displayInterstitial() function when the Ad loads
////                if (interstitial.isLoaded()) {
////
////                        interstitial.show();
////
////
////                }
//                Customprogress.showPopupProgressSpinner(context,false);
//            }
//        });
//
//    }

    private void setChapterData(List<Datum> chapterList, OtherDetail otherDetail) {
        if (chapterList.size() != 0) {
            binding.rvChapter.setVisibility(View.VISIBLE);
            binding.llNoData.setVisibility(View.GONE);
            ChapterListAdapter adapter = new ChapterListAdapter(context, chapterList, new ItemClick() {
                @Override
                public void onItemClick(int position, String type) {
                    if (type.equals("addbookmark")) {
                        if (Constants.isInternetConnected(context)) {
                            AddBookmarkAPI(chapterList.get(position).getId().toString());
                        } else {
                            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                        }
                    } else if (type.equals("removebookmark")) {
                        if (Constants.isInternetConnected(context)) {
                            RemoveBookmarkAPI(chapterList.get(position).getBookmark_id());
                        } else {
                            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                        }
                    } else {
//                        if(mySharedPref.getSavedInterstitialAddsStatus().equals("Yes")){
//                            if (interstitial.isLoaded()) {
//
//                                Customprogress.showPopupProgressSpinner(context,true);
//                                interstitial.show();
//
//                                interstitial.setAdListener(new AdListener() {
//
//                                    @Override
//                                    public void onAdClosed() {
//                                        super.onAdClosed();
//                                        Customprogress.showPopupProgressSpinner(context,false);
//                                        startActivity(new Intent(context, ChapterDetailActivity.class)
//                                                .putExtra("ChapterDetail", (Serializable) chapterList.get(position))
//                                                .putExtra("otherDetail", (Serializable) otherDetail)
//                                                .putExtra("chapterList", (Serializable) chapterList)
//                                                .putExtra("positionChapter", String.valueOf(position))
//                                        );
//                                    }
//                                });
//                            }
//                        }else{
//                            startActivity(new Intent(context, ChapterDetailActivity.class)
//                                    .putExtra("ChapterDetail", (Serializable) chapterList.get(position))
//                                    .putExtra("otherDetail", (Serializable) otherDetail)
//                                    .putExtra("chapterList", (Serializable) chapterList)
//                                    .putExtra("positionChapter", String.valueOf(position))
//                            );
//                        }
                        Log.e("strrrr",""+chapterList.get(position).getAudio());
                        Log.e("strrrr",""+chapterList.get(position).getPdf());
                        Log.e("strrrr",""+chapterList.get(position).getPdfCount());
                        Log.e("strrrr",""+chapterList.get(position).getPdfUrl());
                        Log.e("strrrr",""+chapterList.get(position).getUrl());
                        if(chapterList.get(position).getUrl().isEmpty()) {
                            startActivity(new Intent(context, EbookActivity.class)
                                    .putExtra("ChapterDetail", chapterList.get(position))
                                    .putExtra("otherDetail", otherDetail)
                                    .putExtra("chapterList", (Serializable) chapterList)
                                    .putExtra("positionChapter", String.valueOf(position))
                                    .putExtra("FROM", "ChapterDetailActivity")

                            );
                        }else {
                            startActivity(new Intent(context, ChapterDetailActivity.class)
                                    .putExtra("ChapterDetail", chapterList.get(position))
                                    .putExtra("otherDetail", otherDetail)
                                    .putExtra("chapterList", (Serializable) chapterList)
                                    .putExtra("positionChapter", String.valueOf(position))
                            );
                        }
                    }
                }
            }, adManager);
            binding.rvChapter.setHasFixedSize(true);
            binding.rvChapter.setLayoutManager(new LinearLayoutManager(context));
            binding.rvChapter.setAdapter(adapter);
        } else {
            binding.rvChapter.setVisibility(View.GONE);
            binding.llNoData.setVisibility(View.VISIBLE);
        }
    }

    public void AddBookmarkAPI(String chapterId) {
        Customprogress.showPopupProgressSpinner(context, false);
        AddBookmarkParaRes addBookmarkParaRes = new AddBookmarkParaRes();
        addBookmarkParaRes.setChapterId(chapterId);
        jsonPlaceHolderApi.AddBookmarkAPI("application/json", "application/json", "Bearer " + mySharedPref.getSavedAccessToken(), addBookmarkParaRes).enqueue(new Callback<AddBookmarkRes>() {
            @Override
            public void onResponse(Call<AddBookmarkRes> call, Response<AddBookmarkRes> response) {

                if (response.isSuccessful()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {
                        if (Constants.isInternetConnected(context)) {
                            GetChapterAPI();
                        } else {
                            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                        }
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<AddBookmarkRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
            }
        });
    }
    public void RemoveBookmarkAPI(String bookmarkId) {
        Customprogress.showPopupProgressSpinner(context, false);
        RemoveBookmarkParaRes removeBookmarkParaRes = new RemoveBookmarkParaRes();
        removeBookmarkParaRes.setBookmarkId(bookmarkId);
        jsonPlaceHolderApi.RemoveBookmarkAPI("application/json", "application/json", "Bearer " + mySharedPref.getSavedAccessToken(), removeBookmarkParaRes).enqueue(new Callback<RemoveBookmarkRes>() {
            @Override
            public void onResponse(Call<RemoveBookmarkRes> call, Response<RemoveBookmarkRes> response) {
                if (response.isSuccessful()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {
                        if (Constants.isInternetConnected(context)) {
                            GetChapterAPI();
                        } else {
                            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                        }
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<RemoveBookmarkRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
            }
        });
    }
}

package com.edutech.ncert.model.MaintenanceModel;
import com.google.gson.annotations.SerializedName;

@SuppressWarnings("unused")
public class Data {


    @SerializedName("verson")
    private String verson;
    @SerializedName("maintenance")
    private String maintenance;
    @SerializedName("interstitial_status")
    private String interstitialStatus;
    @SerializedName("banner_status")
    private String bannerStatus;
    @SerializedName("reward_status")
    private String rewardStatus;

    public String getVerson() {
        return verson;
    }

    public void setVerson(String verson) {
        this.verson = verson;
    }

    public String getMaintenance() {
        return maintenance;
    }

    public void setMaintenance(String maintenance) {
        this.maintenance = maintenance;
    }

    public String getInterstitialStatus() {
        return interstitialStatus;
    }

    public void setInterstitialStatus(String interstitialStatus) {
        this.interstitialStatus = interstitialStatus;
    }

    public String getBannerStatus() {
        return bannerStatus;
    }

    public void setBannerStatus(String bannerStatus) {
        this.bannerStatus = bannerStatus;
    }

    public String getRewardStatus() {
        return rewardStatus;
    }

    public void setRewardStatus(String rewardStatus) {
        this.rewardStatus = rewardStatus;
    }

}

package com.edutech.ncert.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.edutech.ncert.Interface.ItemClick;
import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ListItemSubjectBinding;
import com.edutech.ncert.model.SubjectModel.Subject;

import java.util.List;

public class SubjectListAdapter extends RecyclerView.Adapter<SubjectListAdapter.RecyclerViewHolder> {
    Context context;
    List<Subject> list;
    int selectPosition = -1;
    ItemClick itemClick;

    public SubjectListAdapter(Context context,List<Subject>  list,ItemClick itemClick) {
        this.context = context;
        this.list = list;
        this.itemClick = itemClick;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item_subject, parent, false);
        RecyclerViewHolder recyclerViewHolder = new RecyclerViewHolder(view);
        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.binding.tvTitle.setText(list.get(position).getSubject());
       // holder.binding.tvDescription.setText(list.get(position).getSubject());
        Glide.with(context)
                .load(list.get(position).getImage() != null ? "https://ncert.schooltopper.in/"+list.get(position).getImage() : "https://ncert.schooltopper.in/public/uploads/book/ic_launcher.png")
                .placeholder(R.drawable.ic_splash_logo) // Optional placeholder
                .error(R.drawable.ic_splash_logo) // Optional error placeholder
                .into(holder.binding.ivClassImage); // Assuming you have an ImageView with id `ivImage`

//        if (selectPosition == position){
//            holder.binding.llMain.setBackgroundResource(R.drawable.bg_gradient_card);
//            holder.binding.ivArrow.setColorFilter(context.getResources().getColor(R.color.white));
//            holder.binding.tvTitle.setTextColor(context.getResources().getColor(R.color.white));
//            holder.binding.tvDescription.setTextColor(context.getResources().getColor(R.color.white));
//        }
//        else{
////            holder.binding.llMain.setBackgroundResource(R.drawable.bg_gradient_border);
//            int[] backgrounds = new int[]{R.drawable.bg_gradient_1, R.drawable.bg_gradient_2, R.drawable.bg_gradient_3, R.drawable.bg_gradient_4, R.drawable.bg_gradient_5};
//            int background = backgrounds[position % backgrounds.length];
//            holder.binding.llMain.setBackgroundResource(background);
//            holder.binding.ivArrow.setColorFilter(context.getResources().getColor(R.color.txt_blue));
//            holder.binding.tvTitle.setTextColor(context.getResources().getColor(R.color.black));
//            holder.binding.tvDescription.setTextColor(context.getResources().getColor(R.color.black));
//        }
        holder.binding.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectPosition = position;
                itemClick.onItemClick(position,"_Medium");
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private final ListItemSubjectBinding binding;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ListItemSubjectBinding.bind(itemView);

        }
    }
}

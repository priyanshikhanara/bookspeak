package com.edutech.ncert.fragment;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.edutech.ncert.R;
import com.edutech.ncert.activity.HomeActivity;
import com.edutech.ncert.adapter.ViewPagerAdapter;
import com.edutech.ncert.databinding.FragmentBookmarkBinding;
import com.edutech.ncert.server.MySharedPref;
import com.google.android.material.tabs.TabLayout;

public class BookmarkFragment extends Fragment {
    Context context;
    private FragmentBookmarkBinding binding;
    private MySharedPref mySharedPref;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Set current bottom nav selection
        HomeActivity.chipNavigationBar.setItemSelected(R.id.menu_bookmark, true);

        binding = FragmentBookmarkBinding.inflate(inflater, container, false);
        init();
        return binding.getRoot();
    }

    public void init() {
        context = binding.getRoot().getContext();
        mySharedPref = new MySharedPref(context);

        // Set up tabs
        binding.tablayout1.addTab(binding.tablayout1.newTab().setText("Bookmarks"));
        binding.tablayout1.addTab(binding.tablayout1.newTab().setText("Likes"));
        binding.tablayout1.setTabGravity(TabLayout.GRAVITY_FILL);

        // Set up ViewPager
        ViewPagerAdapter adapter = new ViewPagerAdapter(getChildFragmentManager());
        binding.viewpager1.setAdapter(adapter);
        binding.viewpager1.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(binding.tablayout1));

        // Handle tab clicks
        binding.tablayout1.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                binding.viewpager1.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }
}

package com.edutech.ncert.server;

import android.content.Context;
import android.content.SharedPreferences;

import com.edutech.ncert.model.ClassModel.ClassRes;
import com.google.common.base.Charsets;
import com.google.gson.Gson;


public class MySharedPref {
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor myEdit;
    Gson gson;

    private static final String KEY_USERID = "user_id";
    private static final String KEY_ACCESS_TOKEN = "accessToken";
    private static final String KEY_FCM_TOKEN = "fcm_token";
    private static final String KEY_PDF = "pdfSaved";
    private static final String KEY_INTERSTITIAL_ADDS_STATUS = "interstitial_adds_status";
    private static final String KEY_BANNER_ADDS_STATUS = "banner_adds_status";
    private static final String KEY_REWARDED_ADDS_STATUS = "rewarded_adds_status";
    private static final String KEY_FIRST_PLAY = "first_play";

    private static final String FILTER_DATE = "date";
    private static final String FILTER_DATE_FOR_API = "date_for_api";
    private static final String FILTER_START_FIXED_PRICE = "start_fixed_price";
    private static final String FILTER_END_FIXED_PRICE = "end_fixed_price";
    private static final String FILTER_START_HOURLY_PRICE = "start_hourly_price";
    private static final String FILTER_END_HOURLY_PRICE = "end_hourly_price";
    private static final String FILTER_DISTANCE = "filter_distance";
    private static final String LAUNCH_COUNT = "LAUNCH_COUNT";
    private static final String IS_REIEW_DONE = "IS_REIEW_DONE";


    public MySharedPref(Context context){
        sharedPreferences = context.getSharedPreferences("VivDateSF",0);
        myEdit = sharedPreferences.edit();
        gson = new Gson();
    }


    public int getLauchCount(){
        int launchCount=sharedPreferences.getInt(LAUNCH_COUNT,0);
        return launchCount;
    }
    public void setLauchCount(int count){
        myEdit.putInt(LAUNCH_COUNT,count).commit();
    }
    public boolean getIsReviewDone(){
        return sharedPreferences.getBoolean(IS_REIEW_DONE,false);
    }

    public void setIsReviewDone(boolean isDone){
        myEdit.putBoolean(IS_REIEW_DONE,isDone).commit();
    }
    //Save latitude..
    public void setLatitude(String latitude) {
        myEdit.putString("latitude",latitude );
        myEdit.commit();
        myEdit.apply();
    }
    public void saveClassData(ClassRes data) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        editor.putString("class_data", gson.toJson(data));
        editor.apply();
    }
    public void setCachedClassData(ClassRes data) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String json = new Gson().toJson(data);
        editor.putString("cached_class_data", json);
        editor.apply();
    }

    public ClassRes getCachedClassData1() {
        String json = sharedPreferences.getString("cached_class_data", null);
        return json != null ? new Gson().fromJson(json, ClassRes.class) : null;
    }

    public ClassRes getCachedClassData() {
        String json = sharedPreferences.getString("class_data", "");
        if (!json.isEmpty()) {
            try {
                return new Gson().fromJson(json, ClassRes.class);
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }


    //Save is user login..
    public void saveLogin(boolean str){
        myEdit.putBoolean("is_login", str);
        myEdit.commit();
    }
    public boolean isLogin(){
        return sharedPreferences.getBoolean("is_login", false);
    }


    //Save is user notification..
    public void saveNotificationPermission(boolean str){
        myEdit.putBoolean("is_notification_permission", str);
        myEdit.commit();
    }
    public boolean isNotificationPermission(){
        return sharedPreferences.getBoolean("is_notification_permission", false);
    }


    public void setSavedPdf(String savedPdf) {
        myEdit.putString(KEY_PDF, savedPdf);
        myEdit.commit();
    }


    public String getSavedPdf() {
        return sharedPreferences.getString(KEY_PDF, "");
    }


    public void setSavedInterstitialAddsStatus(String interstitialAddsStatus) {
        myEdit.putString(KEY_INTERSTITIAL_ADDS_STATUS, interstitialAddsStatus);
        myEdit.commit();
    }


    public String getSavedInterstitialAddsStatus() {
        return sharedPreferences.getString(KEY_INTERSTITIAL_ADDS_STATUS, "");
    }


    public void setSavedBannerAddsStatus(String bannerAddsStatus) {
        myEdit.putString(KEY_BANNER_ADDS_STATUS, bannerAddsStatus);
        myEdit.commit();
    }


    public String getSavedBannerAddsStatus() {
        return sharedPreferences.getString(KEY_BANNER_ADDS_STATUS, "");
    }


    public void setSavedRewardedAddsStatus(String rewardedAddsStatus) {
        myEdit.putString(KEY_REWARDED_ADDS_STATUS, rewardedAddsStatus);
        myEdit.commit();
    }

    public String getSavedRewardedAddsStatus() {
        return sharedPreferences.getString(KEY_REWARDED_ADDS_STATUS, "");
    }


    public void setSavedFirstPlay(String firstPlay) {
        myEdit.putString(KEY_FIRST_PLAY, firstPlay);
        myEdit.commit();
    }


    public String getSavedFirstPlay() {
        return sharedPreferences.getString(KEY_FIRST_PLAY, "");
    }


    public byte[] getBytes(Context ctx,String BYTE_KEY_PDF) {
        String str = sharedPreferences.getString(BYTE_KEY_PDF, null);
        if (str != null) {
            return str.getBytes(Charsets.ISO_8859_1);
        }
        return null;
    }

    public void setBytes(Context ctx, byte[] bytes,String BYTE_KEY_PDF) {
        myEdit.putString(BYTE_KEY_PDF, new String(bytes, Charsets.ISO_8859_1));
        myEdit.commit();
    }


    public void saveFcmToken(String str){
        myEdit.putString("fcm_token", str);
        myEdit.commit();
        myEdit.apply();
    }

    public String getFcmToken(){
        return sharedPreferences.getString("fcm_token", "");
    }


    public void setSavedUserid(String userid) {
        myEdit.putString(KEY_USERID, userid);
        myEdit.commit();
    }
    public String getSavedUserid() {
        return sharedPreferences.getString(KEY_USERID,"");
    }



    public void setSavedAccessToken(String accessToken) {
        myEdit.putString(KEY_ACCESS_TOKEN, accessToken);
        myEdit.commit();
    }
    public String getSavedAccessToken() {
        return sharedPreferences.getString(KEY_ACCESS_TOKEN,"");
    }



    public void setSavedFcmToken(String fcmToken) {
        myEdit.putString(KEY_FCM_TOKEN, fcmToken);
        myEdit.commit();
    }
    public String getSavedFcmToken() {
        return sharedPreferences.getString(KEY_FCM_TOKEN,"");
    }

    //***************************SAVE FILTER DATE************************************
    public void setFilterDate(String date) {
        myEdit.putString(FILTER_DATE, date);
        myEdit.commit();
    }
    public String getFilterDate() {
        return sharedPreferences.getString(FILTER_DATE, "");
    }

    //***************************SAVE FILTER DATE FOR API************************************
    public void setFilterDateForAPI(String date) {
        myEdit.putString(FILTER_DATE_FOR_API, date);
        myEdit.commit();
    }
    public String getFilterDateForAPI() {
        return sharedPreferences.getString(FILTER_DATE_FOR_API, "");
    }

    //*****************************Start_fixed_price*********************************
    public void setStartFixedPrice(String start_fixed_price) {
        myEdit.putString(FILTER_START_FIXED_PRICE, start_fixed_price);
        myEdit.commit();
    }
    public String getStartFixedPrice() {
        return sharedPreferences.getString(FILTER_START_FIXED_PRICE, "");
    }

    //*****************************End_fixed_price*********************************
    public void setEndFixedPrice(String end_fixed_price) {
        myEdit.putString(FILTER_END_FIXED_PRICE, end_fixed_price);
        myEdit.commit();
    }
    public String getEndFixedPrice() {
        return sharedPreferences.getString(FILTER_END_FIXED_PRICE, "");
    }


    //*****************************Start_hourly_price*********************************
    public void setStartHourlyPrice(String start_hourly_price) {
        myEdit.putString(FILTER_START_HOURLY_PRICE, start_hourly_price);
        myEdit.commit();
    }
    public String getStartHourlyPrice() {
        return sharedPreferences.getString(FILTER_START_HOURLY_PRICE, "");
    }

    //*****************************End_hourly_price*********************************
    public void setEndHourlyPrice(String end_hourly_price) {
        myEdit.putString(FILTER_END_HOURLY_PRICE, end_hourly_price);
        myEdit.commit();
    }
    public String getEndHourlyPrice() {
        return sharedPreferences.getString(FILTER_END_HOURLY_PRICE, "");
    }



    //*****************************filter_distance*********************************
    public void setDistance(String distance) {
        myEdit.putString(FILTER_DISTANCE, distance);
        myEdit.commit();
    }
    public String getDistance() {
        return sharedPreferences.getString(FILTER_DISTANCE, "");
    }
}

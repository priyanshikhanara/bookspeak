package com.edutech.ncert.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.text.HtmlCompat;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ActivityHeaderLayoutBinding;
import com.edutech.ncert.databinding.ActivityLoginBinding;
import com.edutech.ncert.databinding.ActivityTermsAndConditionBinding;
import com.edutech.ncert.model.Terms.TermsRes;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TermsAndConditionActivity extends AppCompatActivity implements View.OnClickListener{
    Context context;
    private ActivityTermsAndConditionBinding binding;
    private ActivityHeaderLayoutBinding headerBinding;
    private JsonPlaceHolderApi jsonPlaceHolderApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTermsAndConditionBinding.inflate(getLayoutInflater());
        headerBinding = binding.bindingHeader;
        setContentView(binding.getRoot());
        init();
        onclicks();
    }

    public void init() {
        context = TermsAndConditionActivity.this;
        headerBinding.llEdit.setVisibility(View.GONE);
        headerBinding.tvTitle.setText(R.string.terms_condition);
        jsonPlaceHolderApi = ApiUtils.getAPIService();

        if (Constants.isInternetConnected(context)) {
            GetTermsAPI();
        } else {
            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
        }
    }

    public void onclicks() {
        headerBinding.llBack.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llBack:
                onBackPressed();
                break;
        }
    }

    public void GetTermsAPI() {
        Customprogress.showPopupProgressSpinner(context, false);

        jsonPlaceHolderApi.GetTermsAPI("application/json", "application/json").enqueue(new Callback<TermsRes>() {
            @Override
            public void onResponse(Call<TermsRes> call, Response<TermsRes> response) {
                if (response.isSuccessful()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {
                        binding.tvTerms.setText(HtmlCompat.fromHtml(response.body().getData().getTerms(), 0));
                    } else {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<TermsRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
            }
        });
    }

}
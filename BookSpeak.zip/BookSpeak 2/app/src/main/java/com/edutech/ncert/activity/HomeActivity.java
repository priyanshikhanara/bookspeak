package com.edutech.ncert.activity;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ActivityHomeBinding;
import com.edutech.ncert.fragment.BookmarkFragment;
import com.edutech.ncert.fragment.HomeFragment;
import com.edutech.ncert.fragment.NewsFragment;
import com.edutech.ncert.fragment.ProfileFragment;
import com.edutech.ncert.model.LogoutModel.LogoutParaRes;
import com.edutech.ncert.model.ResponseStatusMsg;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.AdManager;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;
import com.edutech.ncert.utils.OpenLoginDialogClass;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallState;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.ismaeldivita.chipnavigation.ChipNavigationBar;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class HomeActivity extends AppCompatActivity {

    String TAG="HomeActivityTAG";
    public static ChipNavigationBar chipNavigationBar;
    Context context;
    private ActivityHomeBinding binding;
    NavigationView nav;
    ActionBarDrawerToggle toggle;
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private MySharedPref mySharedPref;
    private String device_id = "";
    private ReviewManager reviewManager;
    private ReviewInfo reviewInfo;
    private static final int MY_REQUEST_CODE = 1000;
    private static final int LAUNCH_COUNT = 5;
    private AppUpdateManager appUpdateManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        reviewManager = ReviewManagerFactory.create(this);
        appUpdateManager = AppUpdateManagerFactory.create(this);
        appUpdateManager.registerListener(installStateUpdatedListener);

        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();
    }

    public void init() {
        context = HomeActivity.this;
        jsonPlaceHolderApi = ApiUtils.getAPIService();
        mySharedPref = new MySharedPref(context);
        if(!mySharedPref.getIsReviewDone()){
            int lauchCount= mySharedPref.getLauchCount()+1;
            mySharedPref.setLauchCount(lauchCount);
            if(lauchCount>LAUNCH_COUNT){
                requestInAppReview();
            }
        }
        device_id = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
//        if (!NotificationManagerCompat.from(this).areNotificationsEnabled() && !mySharedPref.isNotificationPermission()) {
//        } else {
//        }
//        Log.d("TAG!!", "Token>>" + mySharedPref.getSavedFcmToken());
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        nav = findViewById(R.id.navmenu);
        drawerLayout = findViewById(R.id.drawer);
        toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
        toggle.setDrawerIndicatorEnabled(false);

        toggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        toggle.setHomeAsUpIndicator(R.drawable.ic_toolbar);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        chipNavigationBar = findViewById(R.id.chipNavigationBar);
        chipNavigationBar.setItemSelected(R.id.menu_home,
                true);
//        getSupportFragmentManager().beginTransaction()
//                .replace(R.id.frameContainer,
//                        new HomeFragment()).commit();
        HomeFragment homeFragment = new HomeFragment();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frameContainer, homeFragment)
                .commitAllowingStateLoss(); // prevent crash if state already saved

        bottomMenu();
        Menu nav_Menu = nav.getMenu();
        if (mySharedPref.isLogin()) {
            nav_Menu.findItem(R.id.nav_logout).setVisible(true);
            nav_Menu.findItem(R.id.nav_login).setVisible(false);
            nav_Menu.findItem(R.id.nav_delete_account).setVisible(true);
        } else {
            nav_Menu.findItem(R.id.nav_logout).setVisible(false);
            nav_Menu.findItem(R.id.nav_login).setVisible(true);
            nav_Menu.findItem(R.id.nav_delete_account).setVisible(false);
        }

        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                switch (menuItem.getItemId()) {
                    case R.id.nav_home:
                        drawerLayout.closeDrawer(GravityCompat.START);
                        startActivity(new Intent(context, HomeActivity.class));
                        finish();
                        break;

                    case R.id.menu_questions:
                        drawerLayout.closeDrawer(GravityCompat.START);
                        if (!mySharedPref.isLogin()) {
                            OpenLoginDialogClass.openLoginDialog(context);
                        } else {
                            Intent intent = new Intent(context, MyQuestionsActivity.class);
                            context.startActivity(intent);
                        }
                        break;


                    case R.id.nav_bookmarks:
                        drawerLayout.closeDrawer(GravityCompat.START);
                        if (!mySharedPref.isLogin()) {
                            OpenLoginDialogClass.openLoginDialog(context);
                        } else {
                            getSupportFragmentManager().beginTransaction().replace(R.id.frameContainer, new BookmarkFragment()).commit();

                        }
                        break;



                    case R.id.nav_terms_condition:
                        drawerLayout.closeDrawer(GravityCompat.START);
                        startActivity(new Intent(context, TermsAndConditionActivity.class));
                        break;

                    case R.id.nav_privacy:
                        drawerLayout.closeDrawer(GravityCompat.START);
                        startActivity(new Intent(context, PrivacyPolicyActivity.class));
                        break;

                    case R.id.nav_rate_now:
                        drawerLayout.closeDrawer(GravityCompat.START);
                        rateApp();
                        break;

                    case R.id.nav_share:
                        drawerLayout.closeDrawer(GravityCompat.START);
                        shareApp();
                        break;

                    case R.id.nav_more_apps:
                        drawerLayout.closeDrawer(GravityCompat.START);
                        try {
                            Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/dev?id=4725576691027898381"));
                            startActivity(myIntent);
                        } catch (ActivityNotFoundException e) {
                            Toast.makeText(context, "No application can handle this request."
                                    + " Please install a webbrowser",  Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                        break;

                    case R.id.nav_contact_developer:
                        drawerLayout.closeDrawer(GravityCompat.START);
                        String url = "https://api.whatsapp.com/send?phone="+"7891025567";
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(url));
                        startActivity(i);
                        break;

                    case R.id.nav_delete_account:
                        drawerLayout.closeDrawer(GravityCompat.START);
                        openDeleteAccountDialog();
                        break;

                    case R.id.nav_logout:
                        drawerLayout.closeDrawer(GravityCompat.START);
                        openLogoutDialog();
                        break;

                    case R.id.nav_login:
                        drawerLayout.closeDrawer(GravityCompat.START);
                        OpenLoginDialogClass.openLoginDialog(context);

                        break;
                }
                return true;
            }
        });
    }
    private void checkForUpdates() {
        // Create a listener to track updates request.
        Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();

        appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {

            /*if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                    && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)) {
                // Request the update.
                requestUpdate(appUpdateInfo);
            } else*/ if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                    && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                // Request the immediate update.
                startImmediateUpdate(appUpdateInfo);
            }
        });
    }

    private void startImmediateUpdate(AppUpdateInfo appUpdateInfo) {
        try {
            appUpdateManager.startUpdateFlowForResult(
                    appUpdateInfo,
                    AppUpdateType.IMMEDIATE,
                    this,
                    MY_REQUEST_CODE);
        } catch (Exception e) {
            Log.e(TAG, "Error starting immediate update: " + e.getMessage());
        }
    }

    private final InstallStateUpdatedListener installStateUpdatedListener = new InstallStateUpdatedListener() {
        @Override
        public void onStateUpdate(InstallState state) {
            if (state.installStatus() == InstallStatus.DOWNLOADED) {
                // Update downloaded and ready to install
                showInstallSnackbar();
            } else if (state.installStatus() == InstallStatus.INSTALLED) {
                // App installed, you can optionally perform further actions here
            } else if (state.installStatus() == InstallStatus.CANCELED) {
                appUpdateManager.unregisterListener(installStateUpdatedListener);
                // App installed, you can optionally perform further actions here
            } else {
//                appUpdateManager.unregisterListener(installStateUpdatedListener);
                Log.d(TAG, "InstallStateUpdatedListener: Install Status: " + state.installStatus());
            }
        }
    };

    private void showInstallSnackbar() {
        // Display a snackbar to notify the user that the update is ready to be installed.
        // You can customize this based on your UI/UX design.
        Toast.makeText(this, "Update downloaded. Ready to install.", Toast.LENGTH_LONG).show();
    }
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == MY_REQUEST_CODE) {
            if (resultCode != RESULT_OK) {
                // Handle the case where the user cancels the update process
                Log.d(TAG, "Update flow failed with result code: " + resultCode);
                // You may want to show a message to the user or take appropriate action
                finish();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Resume the update check when the activity is resumed.
        checkForUpdates();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Unregister the listener when the activity is destroyed.
        appUpdateManager.unregisterListener(installStateUpdatedListener);
    }

    private void bottomMenu() {
        chipNavigationBar.setOnItemSelectedListener(new ChipNavigationBar.OnItemSelectedListener() {
            int currentItem = -1; // Track current tab

            @Override
            public void onItemSelected(int i) {
                Fragment fragment = null;

                // If re-clicked same tab, force refresh
                if (currentItem == i) {
                    if (i == R.id.menu_home) {
                        Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.frameContainer);
                        if (currentFragment instanceof HomeFragment) {
                            ((HomeFragment) currentFragment).refreshContent(); // ✅ already in your fragment
                        }
                        return; // Don't reassign fragment
                    } else if (i == R.id.menu_questions) {
                        startActivity(new Intent(HomeActivity.this, MyQuestionsActivity.class));
                        return;
                    }
                    // You can add more re-click handlers for other tabs if needed
                }

                currentItem = i;

                switch (i) {
                    case R.id.menu_home:
                        fragment = new HomeFragment();
                        break;
                    case R.id.menu_bookmark:
                        if (!mySharedPref.isLogin()) {
                            fragment = new HomeFragment();
                            OpenLoginDialogClass.openLoginDialog(context);
                        } else {
                            fragment = new BookmarkFragment();
                        }
                        break;

                    case R.id.menu_questions:
                        startActivity(new Intent(HomeActivity.this, MyQuestionsActivity.class));
                        return;
                    case R.id.menu_profile:
                        if (!mySharedPref.isLogin()) {
                            fragment = new HomeFragment();
                            OpenLoginDialogClass.openLoginDialog(context);
                        } else {
                            fragment = new ProfileFragment();
                        }
                        break;
                    case R.id.menu_news:
                        fragment = new NewsFragment();
                        break;
                }

                if (fragment != null) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.frameContainer, fragment)
                            .commit();
                }
            }
        });
    }

    void shareApp(){
        // Check if the Play Store app is installed
        if (isPlayStoreInstalled()) {
            // Create an intent to open the app in the Play Store
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, "Check out this app: https://play.google.com/store/apps/details?id=" + "com.edutech.ncert");

            // Create a chooser dialog
            Intent chooser = Intent.createChooser(shareIntent, "Share via");

            // Verify if there are apps available to handle the intent
            if (shareIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(chooser);
            } else {
                // Handle the case where no apps can handle the share Intent
                Toast.makeText(this, "No apps can handle this share request", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Play Store is not installed, handle the situation accordingly
            Toast.makeText(this, "Google Play Store is not installed", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestInAppReview() {
        Task<ReviewInfo> request = reviewManager.requestReviewFlow();
        request.addOnCompleteListener(new OnCompleteListener<ReviewInfo>() {
            @Override
            public void onComplete(Task<ReviewInfo> task) {
                if (task.isSuccessful()) {
                    // We can get the ReviewInfo object
                    reviewInfo = task.getResult();

                    // Launch the in-app review flow
                    launchInAppReviewFlow();
                } else {
                    // There was an error, handle it accordingly
                    Log.d(TAG, "Error requesting in-app review: " + task.getException().getMessage());
                }
            }
        });
    }

    private void launchInAppReviewFlow() {
        Task<Void> flow = reviewManager.launchReviewFlow(this, reviewInfo);
        flow.addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(Task<Void> task) {
                // The in-app review flow has finished.
                if (task.isSuccessful()) {
                    Log.d(TAG, "In-app review successful");
                    mySharedPref.setIsReviewDone(true);
//                    Toast.makeText(context, getResources().getString(R.string.app_name)+" is Rated Successfully!", Toast.LENGTH_SHORT).show();
                    // You can track or log the success if needed
                } else {
                    // There was an error, handle it accordingly
                    Log.d(TAG, "Error launching in-app review flow: " + task.getException().getMessage());
                }
            }
        });
    }

    void rateApp(){
        try {
            // Open the app's Play Store page
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + "com.edutech.ncert"));
            startActivity(intent);
        } catch (android.content.ActivityNotFoundException e) {
            // Handle the case where the Play Store app is not installed
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + "com.edutech.ncert"));
            startActivity(intent);
        }
    }
    // Check if the Play Store app is installed
    private boolean isPlayStoreInstalled() {
        PackageManager packageManager = getPackageManager();
        Intent playStoreIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.gms"));
        List<ResolveInfo> list = packageManager.queryIntentActivities(playStoreIntent, PackageManager.MATCH_DEFAULT_ONLY);
        return list.size() > 0;
    }

    private void openLogoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(getResources().getString(R.string.do_you_want_to_logout));
        builder.setCancelable(true);
        builder.setNegativeButton(getResources().getString(R.string.YES), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (Constants.isInternetConnected(context)) {
                    LogoutAPI();
                } else {
                    Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                }
                dialog.cancel();
            }
        });
        builder.setPositiveButton(getResources().getString(R.string.NO), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


    private void openDeleteAccountDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(getResources().getString(R.string.do_you_want_to_delete_account));
        builder.setCancelable(true);
        builder.setNegativeButton(getResources().getString(R.string.DELETE), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (Constants.isInternetConnected(context)) {
                    DeleteAccountAPI();
                } else {
                    Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                }
                dialog.cancel();
            }
        });
        builder.setPositiveButton(getResources().getString(R.string.CANCEL), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public void DeleteAccountAPI() {
        Customprogress.showPopupProgressSpinner(context, false);

        jsonPlaceHolderApi.DeleteAccountAPI("application/json", "application/json","Bearer " + mySharedPref.getSavedAccessToken()).enqueue(new Callback<ResponseStatusMsg>() {
            @Override
            public void onResponse(Call<ResponseStatusMsg> call, Response<ResponseStatusMsg> response) {
                if (response.isSuccessful()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {
                        startActivity(new Intent(context, SignupActivity.class));
                        mySharedPref.saveLogin(false);
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Customprogress.showPopupProgressSpinner(context, false);
                    Toast.makeText(context, "server error", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<ResponseStatusMsg> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);

                Log.e("TAG!!!", t.getMessage());
                //  Toast.makeText(context,t.getMessage().toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void LogoutAPI() {
        Customprogress.showPopupProgressSpinner(context, true);
        LogoutParaRes logoutParaRes =  new LogoutParaRes();
        logoutParaRes.setDeviceId(device_id);
        jsonPlaceHolderApi.LogoutAPI("application/json", "application/json", "Bearer " + mySharedPref.getSavedAccessToken(),logoutParaRes).enqueue(new Callback<ResponseStatusMsg>() {
            @Override
            public void onResponse(Call<ResponseStatusMsg> call, Response<ResponseStatusMsg> response) {
                if (response.isSuccessful()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        mySharedPref.saveLogin(false);
                        mySharedPref.setSavedAccessToken("");
                        mySharedPref.setSavedUserid("");
                        Intent intent = new Intent(context, LoginMainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    } else {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseStatusMsg> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }




}
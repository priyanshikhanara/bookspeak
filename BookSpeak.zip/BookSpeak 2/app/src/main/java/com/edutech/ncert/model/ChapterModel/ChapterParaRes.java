
package com.edutech.ncert.model.ChapterModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class ChapterParaRes implements Serializable {

    @SerializedName("user_id")
    @Expose
    private String userId;
    @SerializedName("class_id")
    @Expose
    private String classId;
    @SerializedName("book_id")
    @Expose
    private String bookId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

}

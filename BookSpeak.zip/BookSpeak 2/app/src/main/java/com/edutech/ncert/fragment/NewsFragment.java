package com.edutech.ncert.fragment;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.edutech.ncert.R;
import com.edutech.ncert.activity.HomeActivity;
import com.edutech.ncert.databinding.FragmentNewsBinding;
import com.edutech.ncert.model.NewsModel.NewsRes;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;
import com.edutech.ncert.utils.OpenLoginDialogClass;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class NewsFragment extends Fragment{
    Context context;
    private final int REQUEST_CAMERA = 0;
    private final int SELECT_FILE = 1;
    private FragmentNewsBinding binding;
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private MySharedPref mySharedPref;
    String selectedPath = "";

    String path = "";

    private String userChoosenTask;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity();
        HomeActivity.chipNavigationBar.setItemSelected(R.id.menu_news, true);
        binding = FragmentNewsBinding.inflate(inflater, container, false);
        init();
        return binding.getRoot();
    }

    public void init() {
        context = binding.getRoot().getContext();
        jsonPlaceHolderApi = ApiUtils.getAPIService();
        mySharedPref = new MySharedPref(context);

        if (Constants.isInternetConnected(context)) {
            GetNewsAPI();

        } else {
            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
        }


    }

    public void GetNewsAPI() {
        Customprogress.showPopupProgressSpinner(context, false);

        jsonPlaceHolderApi.GetNewsAPI("application/json", "application/json","Bearer " + mySharedPref.getSavedAccessToken()).enqueue(new Callback<NewsRes>() {
            @Override
            public void onResponse(Call<NewsRes> call, Response<NewsRes> response) {
                if (response.isSuccessful()) {
                    Boolean status = response.body().getStatus();
                    if (status) {
                        binding.webView.loadUrl(response.body().getData());
                        // this will enable the javascript.
                        binding.webView.getSettings().setJavaScriptEnabled(true);
                        // WebViewClient allows you to handle
                        // onPageFinished and override Url loading.

                        binding.webView.setWebViewClient(new WebViewClient(){
                            @Override
                            public void onPageFinished(WebView view, String url) {
                                super.onPageFinished(view, url);
                                Customprogress.showPopupProgressSpinner(context, false);
                            }
                        });
                    } else {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        if(response.body().getMessage().equals("Your account has been blocked by admin.")){
                            OpenLoginDialogClass.openBlockDeleteDialog(context,response.body().getMessage());
                        }
                    }

                }else{
                    Customprogress.showPopupProgressSpinner(context, false);
                    Toast.makeText(context, "server error", Toast.LENGTH_SHORT).show();
                    if(response.code()==401){
                        OpenLoginDialogClass.openBlockDeleteDialog(context,"User not found");
                    }
                }
            }
            @Override
            public void onFailure(Call<NewsRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG!!!", t.getMessage());
                //  Toast.makeText(context,t.getMessage().toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
package com.edutech.ncert.notification;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.edutech.ncert.activity.AudiobookActivity;

public class NotiService extends Service {
    public static String my_service = "ACTION_STOP_FOREGROUND_SERVICE";
    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String input = intent.getStringExtra("inputExtra");
//        Intent notificationIntent = new Intent(this, AudiobookActivity.class);

        handleIncomingActions(intent);

        return START_NOT_STICKY;
    }
    private void handleIncomingActions(Intent playbackAction) {
        if (playbackAction == null || playbackAction.getAction() == null) return;
        int pos= AudiobookActivity.getInstance().getPosition();

        if(pos >= 0){
            String actionString = playbackAction.getAction();
            Log.d("TAG1","actionString>>"+actionString);

            if (actionString.equalsIgnoreCase("com.edutech.ncert.ACTION_PAUSE_MUSIC")) {
                if( AudiobookActivity.playin){
                    Log.d("TAG1","pause");
                    AudiobookActivity.getInstance().pause();
                }
                else{
                    AudiobookActivity.getInstance().play();
                    Log.d("TAG1","play");
                }
            } else if (actionString.equalsIgnoreCase("com.edutech.ncert.ACTION_NEXT_MUSIC")) {
                AudiobookActivity.getInstance().next();
                Log.d("TAG1","next");
            } else if (actionString.equalsIgnoreCase("com.edutech.ncert.ACTION_PREV_MUSIC")) {
                AudiobookActivity.getInstance().previous();
                Log.d("TAG1","previous");
            }else{
                Toast.makeText(this, "BookSpeak....", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(this, "xyz", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        stopSelf();
       AudiobookActivity.getInstance().stop();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public boolean stopService(Intent name) {
        stopSelf();
        return super.stopService(name);
    }
}
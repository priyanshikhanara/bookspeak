
package com.edutech.ncert.model.BookModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BookParaRes {

    @SerializedName("user_id")
    @Expose
    private String userId;
    @SerializedName("class_id")
    @Expose
    private String classId;
    @SerializedName("medium_id")
    @Expose
    private String mediumId;
    @SerializedName("subject_id")
    @Expose
    private String subjectId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public String getMediumId() {
        return mediumId;
    }

    public void setMediumId(String mediumId) {
        this.mediumId = mediumId;
    }

    public String getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(String subjectId) {
        this.subjectId = subjectId;
    }

}

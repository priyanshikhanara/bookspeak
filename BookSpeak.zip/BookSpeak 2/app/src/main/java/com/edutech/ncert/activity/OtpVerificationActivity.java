package com.edutech.ncert.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ActivityOtpVerificationBinding;
import com.edutech.ncert.model.Verify.VerifyOtpRes;
import com.edutech.ncert.model.Verify.VeriyOtpParaRes;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.server.MySharedPref;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OtpVerificationActivity extends AppCompatActivity implements View.OnClickListener {
    private boolean isOtpSent = false;
    Context context;
    private ActivityOtpVerificationBinding binding;
    String phone,countryCode;
    private String fcm_token = "test";
    private String device_id = "";
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private MySharedPref mySharedPref;
    private String verificationId;
    private FirebaseAuth mAuth;
    boolean isresend = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOtpVerificationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();
        onclicks();
    }

    public void init() {
        context = OtpVerificationActivity.this;
        mAuth = FirebaseAuth.getInstance();
        jsonPlaceHolderApi = ApiUtils.getAPIService();
        mySharedPref = new MySharedPref(context);
        fcm_token = mySharedPref.getSavedFcmToken();
        device_id = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);

        Intent intent = getIntent();
        if (intent != null) {
            binding.pinView.setEnabled(false);
            binding.btnVerify.setEnabled(false);

//            name = intent.getStringExtra("name");
            phone = intent.getStringExtra("phone");
            countryCode = intent.getStringExtra("countryCode");
            sendVerificationCode("+"+countryCode+phone);
//            Log.d("TAG!!!", "name =" + name);
            Log.d("TAG!!!", "phone =" + phone);
            Log.d("TAG!!!", "countryCode =" + countryCode);

        }

        binding.pinView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!charSequence.equals("")) {
                    // binding.pinView.setLineColor(getResources().getColor(R.color.txt_blue));
                    Log.d("TAG", "charSequence>>" + charSequence);
                    Log.d("TAG", "i>>" + i);
                    Log.d("TAG", "i1>>" + i1);
                    Log.d("TAG", "i2>>" + i2);
                }
                if (charSequence.length() == 6) {
                    binding.btnVerify.setBackgroundResource(R.drawable.bg_button_dark);
                    binding.tvVerify.setTextColor(getResources().getColor(R.color.white));
                } else if (charSequence.length() < 6) {
                    binding.btnVerify.setBackgroundResource(R.drawable.bg_button_grey);
                    binding.tvVerify.setTextColor(getResources().getColor(R.color.black));
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    public void resendTimer(){
        new CountDownTimer(30000, 1000) {

            public void onTick(long millisUntilFinished) {
                binding.tvResend.setText("Resend in " + millisUntilFinished / 1000);
                binding.tvResend.setEnabled(false);
                // logic to set the EditText could go here
            }

            public void onFinish() {
                binding.tvResend.setText("Resend");
                binding.tvResend.setEnabled(true);
            }

        }.start();
    }

    public void onclicks() {
        binding.btnVerify.setOnClickListener(this);
        binding.tvChangeNumber.setOnClickListener(this);
        binding.tvResend.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnVerify:
                if (binding.pinView.getText().toString().isEmpty()) {
                    Toast.makeText(context, getResources().getString(R.string.please_enter_the_6_digits_otp), Toast.LENGTH_SHORT).show();
                } else {
                    if (Constants.isInternetConnected(context)) {
//                        verifyOTPAPI();
                        verifyCode(binding.pinView.getText().toString());
                    } else {
                        Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                    }
                }
                break;
            case R.id.tvChangeNumber:
                startActivity(new Intent(context, SignupActivity.class)
                        .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                finish();
                break;
            case R.id.tvResend:
                isresend = true;
                sendVerificationCode("+"+countryCode+phone);

                break;
        }
    }

    public void verifyOTPAPI() {
        Customprogress.showPopupProgressSpinner(context, false);
        VeriyOtpParaRes veriyOtpParaRes = new VeriyOtpParaRes();
        veriyOtpParaRes.setPhone(phone);
        veriyOtpParaRes.setCountryCode(countryCode);
        veriyOtpParaRes.setOtp(binding.pinView.getText().toString());
        veriyOtpParaRes.setFcmToken(fcm_token);
        veriyOtpParaRes.setDeviceId(device_id);
        veriyOtpParaRes.setDevice(Constants.DEVICE_TYPE);

        jsonPlaceHolderApi.verifyOTPAPI("application/json", "application/json", veriyOtpParaRes).enqueue(new Callback<VerifyOtpRes>() {
            @Override
            public void onResponse(Call<VerifyOtpRes> call, Response<VerifyOtpRes> response) {
                if (response.isSuccessful()) {
                    Boolean status = response.body().getStatus();
                    Customprogress.showPopupProgressSpinner(context, false);
                    if (status) {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        mySharedPref.saveLogin(true);
                        mySharedPref.setSavedAccessToken(String.valueOf(response.body().getData().getAccessToken()));
                        mySharedPref.setSavedUserid(String.valueOf(response.body().getData().getUserId()));
                        Intent i = new Intent(context, HomeActivity.class);
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finish();
                    } else {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<VerifyOtpRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
            }
        });
    }

    private void verifyCode(String code) {
        if (!isOtpSent) {
            Toast.makeText(this, "Please wait until OTP is sent.", Toast.LENGTH_SHORT).show();
            return;
        }
        Customprogress.showPopupProgressSpinner(context, false);
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
        signInWithCredential(credential);
    }

    private void signInWithCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(OtpVerificationActivity.this, "OTP Verify Successfully", Toast.LENGTH_LONG).show();
//                            Intent intent = new Intent(OtpVerificationActivity.this, ProfileActivity.class);
//                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//
//                            startActivity(intent);
                            Customprogress.showPopupProgressSpinner(context, false);
                            mySharedPref.saveLogin(true);
                            Intent i = new Intent(context, HomeActivity.class);
                            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(i);
                            finish();

                        } else {
                            Customprogress.showPopupProgressSpinner(context, false);
//                            Toast.makeText(OtpVerificationActivity.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                            Toast.makeText(OtpVerificationActivity.this, "Invalid OTP", Toast.LENGTH_LONG).show();

                        }
                    }
                });
    }

    private void sendVerificationCode(String number) {
//        Customprogress.showPopupProgressSpinner(context, true);
        Customprogress.showPopupProgressSpinner(context, true);
        Toast.makeText(context, "Sending Verification code...", Toast.LENGTH_SHORT).show();
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                number,
                60,
                TimeUnit.SECONDS,
                OtpVerificationActivity.this,
                mCallBack
        );

    }

    private final PhoneAuthProvider.OnVerificationStateChangedCallbacks
            mCallBack = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            Customprogress.showPopupProgressSpinner(context, false);
            verificationId = s;
            isOtpSent = true;
            binding.pinView.setEnabled(true);
            binding.btnVerify.setEnabled(true);
            if(isresend){
                Toast.makeText(OtpVerificationActivity.this, "OTP resend successfully", Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(OtpVerificationActivity.this, "OTP has been sent to your mobile number.", Toast.LENGTH_LONG).show();
            }
            resendTimer();
        }

        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            String code = phoneAuthCredential.getSmsCode();
            Customprogress.showPopupProgressSpinner(context, false);
            if (code != null) {
                verifyCode(code);
            }
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Customprogress.showPopupProgressSpinner(context, false);
            Toast.makeText(OtpVerificationActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    };
}
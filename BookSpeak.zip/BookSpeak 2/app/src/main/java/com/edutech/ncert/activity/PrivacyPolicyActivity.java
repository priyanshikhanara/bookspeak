package com.edutech.ncert.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.text.HtmlCompat;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.edutech.ncert.R;
import com.edutech.ncert.databinding.ActivityHeaderLayoutBinding;
import com.edutech.ncert.databinding.ActivityLoginBinding;
import com.edutech.ncert.databinding.ActivityPrivacyPolicyBinding;
import com.edutech.ncert.model.PrivacyPolicy.PrivacyRes;
import com.edutech.ncert.server.ApiUtils;
import com.edutech.ncert.server.JsonPlaceHolderApi;
import com.edutech.ncert.utils.Constants;
import com.edutech.ncert.utils.Customprogress;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PrivacyPolicyActivity extends AppCompatActivity implements View.OnClickListener{
    Context context;
    private ActivityPrivacyPolicyBinding binding;
    private ActivityHeaderLayoutBinding headerBinding;
    private JsonPlaceHolderApi jsonPlaceHolderApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPrivacyPolicyBinding.inflate(getLayoutInflater());
        headerBinding = binding.bindingHeader;
        setContentView(binding.getRoot());
        init();
        onclicks();
    }
    public void init() {
        context = PrivacyPolicyActivity.this;
        headerBinding.llEdit.setVisibility(View.GONE);
        headerBinding.tvTitle.setText(R.string.privacy_policy);

        jsonPlaceHolderApi = ApiUtils.getAPIService();

        if (Constants.isInternetConnected(context)) {
            GetPrivacyAPI();
        } else {
            Toast.makeText(context, getResources().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
        }
    }

    public void onclicks() {
        headerBinding.llBack.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llBack:
                onBackPressed();
                break;
        }
    }

    public void GetPrivacyAPI() {
        Customprogress.showPopupProgressSpinner(context, false);

        jsonPlaceHolderApi.GetPrivacyAPI("application/json", "application/json").enqueue(new Callback<PrivacyRes>() {
            @Override
            public void onResponse(Call<PrivacyRes> call, Response<PrivacyRes> response) {
                if (response.isSuccessful()) {
                    Customprogress.showPopupProgressSpinner(context, false);
                    Boolean status = response.body().getStatus();
                    if (status) {
                        binding.tvPrivacy.setText(HtmlCompat.fromHtml(response.body().getData().getPrivacyPolicy(), 0));
                    } else {
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<PrivacyRes> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", t.getMessage());
            }
        });
    }

}
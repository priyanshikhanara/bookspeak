
package com.edutech.ncert.model.ClassModel;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Data {

    @SerializedName("class")
    @Expose
    private List<Clas> _class;
    @SerializedName("classbanner")
    @Expose
    private List<Classbanner> classbanner;

    public List<Clas> getClass_() {
        return _class;
    }

    public void setClass_(List<Clas> _class) {
        this._class = _class;
    }

    public List<Classbanner> getClassbanner() {
        return classbanner;
    }

    public void setClassbanner(List<Classbanner> classbanner) {
        this.classbanner = classbanner;
    }

}
